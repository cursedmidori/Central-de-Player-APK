# Central do Player — Flutter

Este ZIP é um projeto Flutter pronto para virar APK.

## Como gerar APK pelo GitHub Actions

1. Crie um repositório no GitHub.
2. Envie todos os arquivos deste ZIP para a raiz do repositório.
3. Abra a aba **Actions**.
4. Rode **Gerar APK Flutter**.
5. Baixe o artefato `central-player-debug-apk`.

## Como testar no PC

```bash
flutter pub get
flutter run
```

## O que já vem incluído

- Ficha editável.
- PV, PE, PD, SAN, Defesa, RD, DT, carga.
- Cálculos automáticos básicos.
- Atributos, perícias e rolagens no estilo Ordem Paranormal.
- Ataques, rituais, poderes, inventário, proteções, condições e buffs.
- Regras opcionais: NEX & Nível, contador de munição, Alterações de NEX, Jogando sem Sanidade, Combate Narrativo e Conjuração Complexa.
- Preparar Ação, investigação, missão, relações, evolução, marcas, traumas, votos, backups, importação/exportação JSON.
