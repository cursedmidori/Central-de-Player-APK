import 'dart:convert';
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';

const saveKey = 'central_player_flutter_v1';

const attrs = ['Força', 'Agilidade', 'Intelecto', 'Presença', 'Vigor'];
const skills = [
  'Acrobacia','Adestramento','Artes','Atletismo','Atualidades','Ciências','Crime','Diplomacia',
  'Enganação','Fortitude','Furtividade','Iniciativa','Intimidação','Intuição','Investigação',
  'Luta','Medicina','Ocultismo','Percepção','Pilotagem','Pontaria','Profissão','Reflexos',
  'Religião','Sobrevivência','Tática','Tecnologia','Vontade'
];

const tabs = [
  ['painel','Painel'], ['ficha','Ficha'], ['calculos','Cálculos'], ['regras','Regras Opcionais'],
  ['criacao','Criação'], ['origem','Origem'], ['classe','Classe/Trilha'], ['evolucao','Evolução'],
  ['ataques','Ataques'], ['rituais','Rituais'], ['poderes','Poderes'], ['preparar','Preparar Ação'],
  ['pericias','Perícias'], ['dano','Dano'], ['defesas','Defesas'], ['efeitos','Condições'],
  ['inventario','Inventário'], ['investigacao','Investigação'], ['missao','Missão'], ['relacoes','Relações'],
  ['historia','História'], ['cena','Cena'], ['backups','Backups'], ['relatorio','Relatório'],
  ['historico','Histórico'], ['config','Config']
];

void main() => runApp(const CentralPlayerApp());

class CentralPlayerApp extends StatefulWidget {
  const CentralPlayerApp({super.key});
  @override
  State<CentralPlayerApp> createState() => _CentralPlayerAppState();
}

class _CentralPlayerAppState extends State<CentralPlayerApp> {
  Map<String, dynamic> c = fresh();
  String screen = 'painel';
  final undo = <Map<String, dynamic>>[];
  final rand = Random();

  @override
  void initState() {
    super.initState();
    load();
  }

  ThemeData theme() {
    return ThemeData(
      brightness: Brightness.dark,
      scaffoldBackgroundColor: const Color(0xFF050202),
      colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFFE43642), brightness: Brightness.dark),
      useMaterial3: true,
      appBarTheme: const AppBarTheme(backgroundColor: Color(0xFF050202), foregroundColor: Color(0xFFFFF3EA)),
      drawerTheme: const DrawerThemeData(backgroundColor: Color(0xFF050202)),
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: const Color(0xFF0D0606),
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(14)),
      ),
      outlinedButtonTheme: OutlinedButtonThemeData(
        style: OutlinedButton.styleFrom(
          foregroundColor: const Color(0xFFFFF3EA),
          side: const BorderSide(color: Color(0xFF522629)),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        ),
      ),
      filledButtonTheme: FilledButtonThemeData(
        style: FilledButton.styleFrom(
          backgroundColor: const Color(0xFFE43642),
          foregroundColor: const Color(0xFFFFF3EA),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    applyRules();
    final d = derived();
    final wide = MediaQuery.of(context).size.width > 900;
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: theme(),
      home: Scaffold(
        appBar: AppBar(
          title: Text(str(c['name'])),
          actions: [
            IconButton(onPressed: undoLast, icon: const Icon(Icons.undo)),
            IconButton(onPressed: () => save(show: true), icon: const Icon(Icons.save)),
          ],
        ),
        drawer: wide ? null : Drawer(child: nav()),
        body: SafeArea(
          child: Row(
            children: [
              if (wide) SizedBox(width: 280, child: nav()),
              Expanded(
                child: ListView(
                  padding: const EdgeInsets.all(12),
                  children: [
                    header(d),
                    const SizedBox(height: 12),
                    current(),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget nav() {
    final visible = boolv('playerMode')
      ? tabs.where((t) => ['painel','ficha','ataques','rituais','poderes','preparar','pericias','inventario','investigacao','historico','config'].contains(t[0])).toList()
      : tabs;
    return ListView(
      padding: const EdgeInsets.all(12),
      children: [
        const SizedBox(height: 18),
        const Text('CENTRAL DO PLAYER', style: TextStyle(fontSize: 19, fontWeight: FontWeight.w900)),
        const SizedBox(height: 12),
        ...visible.map((t) => Padding(
          padding: const EdgeInsets.only(bottom: 7),
          child: OutlinedButton(
            style: OutlinedButton.styleFrom(
              alignment: Alignment.centerLeft,
              backgroundColor: screen == t[0] ? const Color(0xFFE43642).withOpacity(.20) : Colors.transparent,
            ),
            onPressed: () {
              setState(() => screen = t[0]);
              if (Navigator.canPop(context)) Navigator.pop(context);
            },
            child: Text(t[1]!),
          ),
        )),
      ],
    );
  }

  Widget header(Map<String, dynamic> d) {
    final s = mapi(d['stats']);
    return card(null, Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Wrap(
          spacing: 12,
          runSpacing: 12,
          crossAxisAlignment: WrapCrossAlignment.center,
          children: [
            CircleAvatar(radius: 35, backgroundColor: const Color(0xFFE43642).withOpacity(.25), child: Text(initials(str(c['name'])), style: const TextStyle(fontSize: 24, fontWeight: FontWeight.w900))),
            Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(str(c['name']).toUpperCase(), style: const TextStyle(fontSize: 28, fontWeight: FontWeight.w900)),
              Wrap(spacing: 8, runSpacing: 8, children: [
                pill('${str(c['class'])} • ${str(c['trail'])}', Colors.lightBlueAccent),
                pill('NEX ${intv(c['nex'])}% • Nível ${intv(c['level'])}', Colors.amberAccent),
                pill(boolv('playerMode') ? 'Modo Player' : 'Modo Mesa', Colors.lightGreenAccent),
              ]),
            ]),
          ],
        ),
        const SizedBox(height: 12),
        grid([
          stat('PV', s['pv']!, s['pvMax']!, Colors.redAccent),
          if (rule('semSanidade'))
            stat('PD', s['pd']!, s['pdMax']!, Colors.lightBlueAccent)
          else ...[
            stat('PE', s['pe']!, s['peMax']!, Colors.lightBlueAccent),
            stat('SAN', s['san']!, s['sanMax']!, Colors.lightGreenAccent),
          ],
          card(null, Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('DEFESA / RD', style: TextStyle(fontWeight: FontWeight.w900)),
            Text('${s['def']}/${s['rd']}', style: const TextStyle(fontSize: 28, fontWeight: FontWeight.w900)),
            Text('Mov. ${s['move']}m • DT ${s['dt']} • PE/turno ${s['peTurn']}', style: const TextStyle(color: Color(0xFFBDA69D))),
          ])),
        ], maxCols: 4, ratio: 2.3),
      ],
    ));
  }

  Widget current() {
    switch(screen) {
      case 'ficha': return ficha();
      case 'calculos': return calculos();
      case 'regras': return regras();
      case 'criacao': return criacao();
      case 'origem': return origem();
      case 'classe': return classe();
      case 'evolucao': return evolucao();
      case 'ataques': return listScreen('Ataques e Armas','attacks', attackTile, addAttack);
      case 'rituais': return listScreen('Rituais','rituals', ritualTile, addRitual);
      case 'poderes': return listScreen('Poderes e Habilidades','powers', powerTile, addPower);
      case 'preparar': return preparar();
      case 'pericias': return pericias();
      case 'dano': return dano();
      case 'defesas': return defesas();
      case 'efeitos': return efeitos();
      case 'inventario': return listScreen('Inventário','items', itemTile, addItem, extra: OutlinedButton(onPressed: calcLoad, child: const Text('Calcular carga')));
      case 'investigacao': return notesPage('Investigação', ['clues','investigation','theories','documents','symbols']);
      case 'missao': return notesPage('Missão', ['mission','sideObjectives','missionThreat','missionRewards']);
      case 'relacoes': return listScreen('Relações','relations', (x)=>genericTile('relations',x,['name','type','trust','notes']), addRelation);
      case 'historia': return notesPage('História e personagem', ['appearance','personality','trauma','history']);
      case 'cena': return cena();
      case 'backups': return backups();
      case 'relatorio': return relatorio();
      case 'historico': return historico();
      case 'config': return config();
      default: return painel();
    }
  }

  Widget painel() {
    final d = derived();
    final alerts = List<String>.from(d['alerts']);
    final favs = [
      ...list('attacks').where((x) => x['fav'] == true || x['equipped'] == true).map(attackTile),
      ...list('rituals').where((x) => x['fav'] == true).map(ritualTile),
      ...list('powers').where((x) => x['fav'] == true).map(powerTile),
      ...list('items').where((x) => x['fav'] == true).map(itemTile),
      ...list('buffs').where((x) => x['fav'] == true).map(buffTile),
    ];
    return Column(children: [
      card('Ações rápidas', Wrap(spacing: 8, runSpacing: 8, children: [
        FilledButton(onPressed: startTurn, child: const Text('Início do turno')),
        OutlinedButton(onPressed: endTurn, child: const Text('Fim do turno')),
        OutlinedButton(onPressed: () => roll('1d20','d20',test:true), child: const Text('Rolar d20')),
        OutlinedButton(onPressed: () => setState(() => screen='preparar'), child: const Text('Preparar ação')),
        OutlinedButton(onPressed: undoLast, child: const Text('Desfazer')),
      ])),
      card('Alertas', alerts.isEmpty ? empty('Tudo limpo.') : Wrap(spacing: 8, runSpacing: 8, children: alerts.map((x)=>pill(x, Colors.amberAccent)).toList())),
      card('Favoritos', favs.isEmpty ? empty('Nenhum favorito.') : Column(children: favs.toList())),
      textArea('Ordem de ação / plano', note('order'), (v)=>setNote('order',v)),
    ]);
  }

  Widget ficha() => Column(children: [
    card('Identidade', Column(children: [
      txt('Nome', str(c['name']), (v)=>setv('name',v)),
      dropdown('Classe', str(c['class']), ['Sobrevivente','Combatente','Especialista','Ocultista'], (v){ setv('class',v); applyClassPreset(v); }),
      txt('Trilha', str(c['trail']), (v)=>setv('trail',v)),
      txt('Origem', str(c['origin']), (v)=>setv('origin',v)),
      txt('Afinidade', str(c['affinity']), (v)=>setv('affinity',v)),
      grid([numField('NEX', intv(c['nex']), (v)=>setv('nex',v)), numField('Nível', intv(c['level']), (v)=>setv('level',v))], maxCols: 2),
    ])),
    card('Status', grid([
      for(final k in ['pv','pvMax','pe','peMax','pd','pdMax','san','sanMax','def','rd','move','dt','peTurn','load','loadMax'])
        numField(k.toUpperCase(), statv(k), (v)=>setStat(k,v)),
    ], maxCols: 4)),
    card('Atributos', grid([for(final a in attrs) numField(a, attrv(a), (v)=>setAttr(a,v))], maxCols: 5)),
  ]);

  Widget calculos() {
    final a = autoValues();
    return Column(children: [
      card('Controle', Column(children: [
        SwitchListTile(value: calcBool('auto'), title: const Text('Recalcular máximos automaticamente'), onChanged: (v)=>setCalc('auto',v)),
        dropdown('Progressão', str(calc()['mode']), ['level','nex'], (v)=>setCalc('mode',v)),
        Wrap(spacing: 8, children: [
          FilledButton(onPressed: () { mutate((x){ applyAuto(fill:true); }); }, child: const Text('Aplicar e encher')),
          OutlinedButton(onPressed: () { mutate((x){ applyAuto(fill:false); }); }, child: const Text('Recalcular')),
        ]),
      ])),
      card('Resultado previsto', Text('PV ${a['pvMax']} • PE ${a['peMax']} • PD ${a['pdMax']} • SAN ${a['sanMax']} • DEF ${a['def']} • DT ${a['dt']} • Carga ${a['loadMax']}')),
      card('Fórmulas', grid([
        for(final k in ['pvBase','pvLevel','peBase','peLevel','pdBase','pdLevel','sanBase','sanLevel','defBase','dtBase','loadBase','loadPerForca'])
          numField(k, intv(calc()[k]), (v)=>setCalc(k,v)),
      ], maxCols: 4)),
    ]);
  }

  Widget regras() => Column(children: [
    card('Regras opcionais', Column(children: [
      for(final e in {
        'nexNivel':'NEX & Nível',
        'municao':'Contador de Munição',
        'alteracoesNex':'Alterações de NEX',
        'semSanidade':'Jogando sem Sanidade',
        'combateNarrativo':'Combate Narrativo',
        'conjuracaoComplexa':'Conjuração Complexa',
        'limiteCombinado':'Limite PE+PD combinado',
      }.entries)
        SwitchListTile(value: rule(e.key), title: Text(e.value), onChanged: (v)=>setRule(e.key,v)),
    ])),
    card('Alterações de NEX', Column(children: [
      Wrap(spacing: 8, children: [
        OutlinedButton(onPressed: addNexAlteration, child: const Text('+ Alteração')),
        OutlinedButton(onPressed: addNexPreset, child: const Text('Preset')),
      ]),
      ...list('nexAlterations').map((x)=>genericTile('nexAlterations', x, ['name','nex','skill','skillMod','notes'])),
    ])),
    if(rule('combateNarrativo')) textArea('Combate narrativo', note('narrative'), (v)=>setNote('narrative',v)),
  ]);

  Widget criacao() => Column(children: [
    card('Checklist de criação', Column(children: [
      for(final e in {
        'concept':'Conceito do personagem',
        'origin':'Origem definida',
        'class':'Classe e trilha definidas',
        'attrs':'Atributos distribuídos',
        'skills':'Perícias treinadas',
        'powers':'Poderes iniciais',
        'items':'Equipamentos iniciais',
        'review':'Revisão final',
      }.entries)
        CheckboxListTile(value: note('check_${e.key}')=='true', title: Text(e.value), onChanged: (v)=>setNote('check_${e.key}', (v==true).toString())),
    ])),
    textArea('Conceito geral', note('history'), (v)=>setNote('history',v)),
  ]);

  Widget origem() => Column(children: [
    card('Origem', Column(children: [
      txt('Origem', str(c['origin']), (v)=>setv('origin',v)),
      textArea('Poder de origem', note('originPower'), (v)=>setNote('originPower',v)),
      textArea('Perícias da origem', note('originSkills'), (v)=>setNote('originSkills',v)),
      textArea('Contato/recurso/consequência da origem', note('originResource'), (v)=>setNote('originResource',v)),
    ])),
  ]);

  Widget classe() => Column(children: [
    card('Classe e Trilha', Column(children: [
      dropdown('Classe', str(c['class']), ['Sobrevivente','Combatente','Especialista','Ocultista'], (v){ setv('class',v); applyClassPreset(v); }),
      txt('Trilha', str(c['trail']), (v)=>setv('trail',v)),
      textArea('Habilidade base da classe', note('classAbility'), (v)=>setNote('classAbility',v)),
      textArea('Habilidades de trilha', note('trailAbilities'), (v)=>setNote('trailAbilities',v)),
      textArea('Observações da build', note('build'), (v)=>setNote('build',v)),
    ])),
  ]);

  Widget evolucao() => Column(children: [
    listScreen('Evolução','evolution', (x)=>genericTile('evolution', x, ['title','nex','level','power','notes']), addEvolution),
    textArea('Ferimentos / Sequelas', note('wounds'), (v)=>setNote('wounds',v)),
    textArea('Marcas da Sobrevivência', note('marks'), (v)=>setNote('marks',v)),
    textArea('Votos / Abstinências', note('vows'), (v)=>setNote('vows',v)),
    textArea('Afinidade Manifestada', note('manifestedAffinity'), (v)=>setNote('manifestedAffinity',v)),
  ]);

  Widget preparar() {
    final p = map('prepare');
    return Column(children: [
      card('Preparar Ação 2.0', Column(children: [
        txt('Nome do plano', str(p['title']), (v)=>setPrepare('title',v)),
        dropdown('Tipo', str(p['type'], 'Ataque'), ['Ataque','Ritual','Habilidade','Item','Outro'], (v)=>setPrepare('type',v)),
        txt('Vou usar', str(p['use']), (v)=>setPrepare('use',v)),
        txt('Alvo', str(p['target']), (v)=>setPrepare('target',v)),
        grid([
          numField('PE', intv(p['pe']), (v)=>setPrepare('pe',v)),
          numField('PD', intv(p['pd']), (v)=>setPrepare('pd',v)),
          numField('PV', intv(p['pv']), (v)=>setPrepare('pv',v)),
          numField('SAN', intv(p['san']), (v)=>setPrepare('san',v)),
        ], maxCols: 4),
        txt('Testes separados por ;', str(p['tests']), (v)=>setPrepare('tests',v)),
        txt('Dano / rolagem', str(p['damage']), (v)=>setPrepare('damage',v)),
        if(rule('conjuracaoComplexa')) ...[
          txt('Componentes', str(p['components']), (v)=>setPrepare('components',v)),
          txt('DT', str(p['dt']), (v)=>setPrepare('dt',v)),
          txt('Tempo', str(p['time']), (v)=>setPrepare('time',v)),
          txt('Falha', str(p['fail']), (v)=>setPrepare('fail',v)),
          txt('Sucesso', str(p['success']), (v)=>setPrepare('success',v)),
        ],
        textArea('Observações', str(p['notes']), (v)=>setPrepare('notes',v)),
        Wrap(spacing: 8, runSpacing: 8, children: [
          FilledButton(onPressed: executePrepared, child: const Text('Executar')),
          OutlinedButton(onPressed: copyPrepared, child: const Text('Copiar')),
          OutlinedButton(onPressed: savePlan, child: const Text('Salvar plano')),
          OutlinedButton(onPressed: clearPlan, child: const Text('Limpar')),
        ]),
      ])),
      card('Planos salvos', Column(children: [
        for(final x in listFrom(p['saved']))
          ListTile(title: Text(str(x['title'], 'Plano')), subtitle: Text(str(x['use'])), onTap: ()=>mutate((_) { c['prepare'] = {...map('prepare'), ...x}; })),
      ])),
    ]);
  }

  Widget pericias() {
    final d = derived();
    final sv = Map<String,dynamic>.from(d['skills']);
    return card('Perícias', Column(children: [
      for(final s in skills)
        ListTile(
          title: Text(s),
          subtitle: Text('${skill(s)['attr']} • treino ${skill(s)['train']} • bônus ${skill(s)['bonus']} • temp ${skill(s)['temp']} • dados ${skill(s)['dice']}'),
          trailing: Text('${intv(sv[s]) >= 0 ? '+' : ''}${intv(sv[s])}'),
          leading: IconButton(icon: const Icon(Icons.casino), onPressed: ()=>rollSkill(s)),
          onTap: ()=>editSkill(s),
        )
    ]));
  }

  Widget dano() => card('Dano avançado', Column(children: [
    txt('Alvo', note('damageTarget','Alvo'), (v)=>setNote('damageTarget',v)),
    txt('Expressão de dano', note('damageExp','2d6+3'), (v)=>setNote('damageExp',v)),
    dropdown('Tipo', note('damageType','Impacto'), ['Impacto','Corte','Perfuração','Balístico','Sangue','Morte','Conhecimento','Energia','Medo','Fogo','Frio','Químico'], (v)=>setNote('damageType',v)),
    numField('RD do alvo', int.tryParse(note('damageRd','0')) ?? 0, (v)=>setNote('damageRd','$v')),
    FilledButton(onPressed: calcDamage, child: const Text('Calcular dano')),
  ]));

  Widget defesas() => Column(children: [
    listScreen('Proteções','defenses', defenseTile, addDefense),
    listScreen('Resistências','resistances', (x)=>genericTile('resistances', x, ['type','mode','value','notes']), addResistance),
  ]);

  Widget efeitos() => Column(children: [
    card('Condições', Column(children: [
      Wrap(spacing: 8, children: [
        OutlinedButton(onPressed: addCondition, child: const Text('+ Condição')),
        OutlinedButton(onPressed: addOfficialCondition, child: const Text('Biblioteca oficial')),
        OutlinedButton(onPressed: tickEffects, child: const Text('Passar rodada')),
      ]),
      ...list('conditions').map(conditionTile),
    ])),
    listScreen('Buffs e Debuffs','buffs', buffTile, addBuff),
  ]);

  Widget notesPage(String title, List<String> keys) => Column(children: [
    for(final k in keys) textArea(label(k), note(k), (v)=>setNote(k,v)),
  ]);

  Widget cena() => Column(children: [
    card('Controle de cena', Wrap(spacing: 8, runSpacing: 8, children: [
      pill('Cena ${map('turn')['scene']}', Colors.amberAccent),
      pill('Rodada ${map('turn')['round']}', Colors.lightBlueAccent),
      OutlinedButton(onPressed: nextRound, child: const Text('Próxima rodada')),
      OutlinedButton(onPressed: nextScene, child: const Text('Nova cena')),
      OutlinedButton(onPressed: addSceneEffect, child: const Text('+ Efeito de cena')),
    ])),
    listScreen('Efeitos de cena','sceneEffects', (x)=>genericTile('sceneEffects', x, ['name','duration','left','notes']), addSceneEffect),
  ]);

  Widget backups() => card('Backups e JSON', Column(children: [
    Wrap(spacing: 8, runSpacing: 8, children: [
      FilledButton(onPressed: ()=>createBackup('manual'), child: const Text('Backup manual')),
      OutlinedButton(onPressed: exportJson, child: const Text('Copiar JSON')),
      OutlinedButton(onPressed: importJson, child: const Text('Importar JSON')),
    ]),
    ...list('backups').map((x)=>ListTile(
      title: Text(str(x['label'], 'backup')),
      subtitle: Text(str(x['time'])),
      onTap: ()=>restoreBackup(x),
      trailing: IconButton(icon: const Icon(Icons.delete), onPressed: ()=>removeItem('backups', x)),
    )),
  ]));

  Widget relatorio() => Column(children: [
    card('Relatório da sessão', grid([
      for(final k in ['damageDealt','damageTaken','peSpent','pdSpent','rituals','attacks'])
        numField(label(k), intv(map('report')[k]), (v)=>setReport(k,v)),
    ], maxCols: 3)),
    textArea('Notas do relatório', str(map('report')['notes']), (v)=>setReport('notes',v)),
    card('Resumo para o mestre', Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      OutlinedButton(onPressed: copySummary, child: const Text('Copiar resumo')),
      const SizedBox(height: 8),
      Text(summary()),
    ])),
  ]);

  Widget historico() => card('Histórico', Column(children: [
    Wrap(spacing: 8, children: [
      OutlinedButton(onPressed: ()=>roll('1d20','d20',test:true), child: const Text('d20')),
      OutlinedButton(onPressed: copyHistory, child: const Text('Copiar histórico')),
      OutlinedButton(onPressed: ()=>mutate((_)=>list('rolls').clear()), child: const Text('Limpar')),
    ]),
    for(final r in list('rolls').reversed)
      ListTile(title: Text(str(r['title'], 'Rolagem')), subtitle: Text('${r['text']}\n${r['time']}')),
  ]));

  Widget config() => card('Configurações', Column(children: [
    SwitchListTile(value: boolv('autoSave'), title: const Text('Auto-salvar'), onChanged: (v)=>setv('autoSave',v, snapshot:false)),
    SwitchListTile(value: boolv('playerMode'), title: const Text('Modo Player'), onChanged: (v)=>setv('playerMode',v, snapshot:false)),
    dropdown('Tema visual', str(c['theme']), ['sangue','morte','conhecimento','energia'], (v)=>setv('theme',v)),
    Wrap(spacing: 8, children: [
      FilledButton(onPressed: ()=>save(show:true), child: const Text('Salvar')),
      OutlinedButton(onPressed: resetAll, child: const Text('Resetar')),
    ]),
  ]));

  Widget listScreen(String title, String key, Widget Function(Map<String,dynamic>) builder, VoidCallback add, {Widget? extra}) {
    final items = list(key);
    return card(title, Column(children: [
      Wrap(spacing: 8, runSpacing: 8, children: [
        OutlinedButton(onPressed: add, child: const Text('+ Adicionar')),
        if(extra != null) extra,
      ]),
      const SizedBox(height: 8),
      if(items.isEmpty) empty('Nenhum item.')
      else ...items.map(builder),
    ]));
  }

  Widget attackTile(Map<String,dynamic> x) {
    final d = derived();
    final atkDice = intv(d['atkDice']);
    final atkBonus = intv(d['atkBonus']);
    final attack = addD20Dice(str(x['test'], '1d20'), atkDice) + (atkBonus == 0 ? '' : '+$atkBonus');
    final extras = List<String>.from(d['dmgExtras']);
    final damage = [str(x['damage'], '1d6'), ...extras].where((a)=>a.trim().isNotEmpty).join('+');
    return ListTile(
      title: Text(str(x['name'], 'Ataque')),
      subtitle: Text('$attack • $damage • ${x['crit']} • ${x['type']} • Munição ${x['ammo']}/${x['ammoMax']}'),
      leading: IconButton(icon: const Icon(Icons.casino), onPressed: ()=>roll(attack, 'Ataque: ${x['name']}', test:true)),
      onTap: ()=>editAttack(x),
      trailing: PopupMenuButton<String>(
        onSelected: (v) {
          if(v=='dmg') roll(damage, 'Dano: ${x['name']}', test:false);
          if(v=='crit') roll(critExpr(damage, str(x['crit'], 'x2')), 'Crítico: ${x['name']}', test:false);
          if(v=='ammo') mutate((_){ x['ammo'] = (intv(x['ammo']) - 1).clamp(0,999); });
          if(v=='fav') mutate((_){ x['fav'] = x['fav'] != true; });
          if(v=='edit') editAttack(x);
          if(v=='del') removeItem('attacks', x);
        },
        itemBuilder: (_) => menu(['dmg','crit','ammo','fav','edit','del']),
      ),
    );
  }

  Widget ritualTile(Map<String,dynamic> x) => ListTile(
    title: Text(str(x['name'], 'Ritual')),
    subtitle: Text('${x['element']} • ${x['circle']}º • custo ${x['cost']} • sustentar ${x['sustainCost']}'),
    leading: IconButton(icon: const Icon(Icons.auto_awesome), onPressed: ()=>castRitual(x)),
    onTap: ()=>editRitual(x),
    trailing: PopupMenuButton<String>(
      onSelected: (v) {
        if(v=='dmg') roll(str(x['damage'], detect(str(x['effect'])) ?? '1d6'), 'Dano ritual: ${x['name']}', test:false);
        if(v=='sustain') mutate((_){ x['sustain'] = x['sustain'] != true; });
        if(v=='fav') mutate((_){ x['fav'] = x['fav'] != true; });
        if(v=='edit') editRitual(x);
        if(v=='del') removeItem('rituals', x);
      },
      itemBuilder: (_) => menu(['dmg','sustain','fav','edit','del']),
    ),
  );

  Widget powerTile(Map<String,dynamic> x) => ListTile(
    title: Text(str(x['name'], 'Poder')),
    subtitle: Text('${x['type']} • custo ${x['cost']} • ação ${x['action']}'),
    onTap: ()=>editPower(x),
    trailing: PopupMenuButton<String>(
      onSelected: (v) {
        if(v=='use') log('Poder', '${x['name']} usado.');
        if(v=='fav') mutate((_){ x['fav'] = x['fav'] != true; });
        if(v=='edit') editPower(x);
        if(v=='del') removeItem('powers', x);
      },
      itemBuilder: (_) => menu(['use','fav','edit','del']),
    ),
  );

  Widget itemTile(Map<String,dynamic> x) => ListTile(
    title: Text(str(x['name'], 'Item')),
    subtitle: Text('${x['category']} • qtd ${x['qty']} • carga ${x['load']} • usos ${x['uses']}/${x['usesMax']}'),
    onTap: ()=>editItem(x),
    trailing: PopupMenuButton<String>(
      onSelected: (v) {
        if(v=='use') useItem(x);
        if(v=='fav') mutate((_){ x['fav'] = x['fav'] != true; });
        if(v=='edit') editItem(x);
        if(v=='del') removeItem('items', x);
      },
      itemBuilder: (_) => menu(['use','fav','edit','del']),
    ),
  );

  Widget defenseTile(Map<String,dynamic> x) => ListTile(
    title: Text(str(x['name'], 'Proteção')),
    subtitle: Text('${x['category']} • DEF +${x['def']} • RD +${x['rd']} • Mov ${x['move']}'),
    leading: Switch(value: x['equipped'] == true, onChanged: (v)=>mutate((_){ x['equipped'] = v; })),
    onTap: ()=>editDefense(x),
    trailing: IconButton(icon: const Icon(Icons.delete), onPressed: ()=>removeItem('defenses', x)),
  );

  Widget conditionTile(Map<String,dynamic> x) => ListTile(
    title: Text(str(x['name'], 'Condição')),
    subtitle: Text('${x['duration']} • restante ${x['left']} • DEF ${x['def']} • ${x['effect']}'),
    onTap: ()=>editCondition(x),
    trailing: IconButton(icon: const Icon(Icons.delete), onPressed: ()=>removeItem('conditions', x)),
  );

  Widget buffTile(Map<String,dynamic> x) => ListTile(
    title: Text(str(x['name'], 'Buff')),
    subtitle: Text('${x['active']==true?'ativo':'off'} • duração ${x['duration']} • atk +${x['atkBonus']} • def +${x['def']}'),
    leading: Switch(value: x['active'] == true, onChanged: (v)=>mutate((_){ x['active'] = v; })),
    onTap: ()=>editBuff(x),
    trailing: IconButton(icon: const Icon(Icons.delete), onPressed: ()=>removeItem('buffs', x)),
  );

  Widget genericTile(String key, Map<String,dynamic> x, List<String> fields) => ListTile(
    title: Text(str(x[fields.first], 'Item')),
    subtitle: Text(fields.skip(1).map((f)=>'${label(f)}: ${x[f] ?? ''}').join(' • ')),
    onTap: ()=>editGeneric(key, x, fields),
    trailing: IconButton(icon: const Icon(Icons.delete), onPressed: ()=>removeItem(key, x)),
  );

  List<PopupMenuEntry<String>> menu(List<String> values) => values.map((v)=>PopupMenuItem(value: v, child: Text(label(v)))).toList();

  Widget card(String? title, Widget child) => Container(
    width: double.infinity,
    margin: const EdgeInsets.only(bottom: 12),
    padding: const EdgeInsets.all(14),
    decoration: BoxDecoration(
      color: const Color(0xFF140807),
      borderRadius: BorderRadius.circular(18),
      border: Border.all(color: const Color(0xFF522629)),
      boxShadow: [BoxShadow(color: Colors.black.withOpacity(.35), blurRadius: 24, offset: const Offset(0,12))],
    ),
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      if(title != null) ...[
        Row(children: [
          Container(width: 24, height: 3, color: const Color(0xFFE43642)),
          const SizedBox(width: 8),
          Expanded(child: Text(title.toUpperCase(), style: const TextStyle(fontWeight: FontWeight.w900, letterSpacing: 1.2))),
        ]),
        const SizedBox(height: 12),
      ],
      child,
    ]),
  );

  Widget pill(String text, Color color) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
    decoration: BoxDecoration(border: Border.all(color: color.withOpacity(.75)), borderRadius: BorderRadius.circular(999), color: Colors.black.withOpacity(.25)),
    child: Text(text.toUpperCase(), style: TextStyle(color: color, fontWeight: FontWeight.w900, fontSize: 11)),
  );

  Widget empty(String text) => Padding(padding: const EdgeInsets.all(8), child: Text(text, style: const TextStyle(color: Color(0xFFBDA69D))));

  Widget stat(String label, int cur, int max, Color color) {
    final pct = max <= 0 ? 0.0 : (cur / max).clamp(0.0, 1.0);
    final key = label.toLowerCase();
    return card(null, Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Row(children: [Expanded(child: Text(label, style: const TextStyle(fontWeight: FontWeight.w900))), Text('$cur/$max', style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w900))]),
      const SizedBox(height: 8),
      LinearProgressIndicator(value: pct, minHeight: 10, color: color, backgroundColor: Colors.black45),
      const SizedBox(height: 8),
      Row(children: [
        Expanded(child: OutlinedButton(onPressed: ()=>adjust(key,-1), child: const Text('-1'))),
        const SizedBox(width: 8),
        Expanded(child: OutlinedButton(onPressed: ()=>adjust(key,1), child: const Text('+1'))),
      ]),
    ]));
  }

  Widget grid(List<Widget> children, {int maxCols = 3, double ratio = 3.0}) => LayoutBuilder(builder: (context, box) {
    final w = box.maxWidth;
    final cols = min(maxCols, w > 1050 ? 4 : w > 760 ? 3 : w > 480 ? 2 : 1);
    return GridView.count(physics: const NeverScrollableScrollPhysics(), shrinkWrap: true, crossAxisCount: cols, childAspectRatio: ratio, crossAxisSpacing: 10, mainAxisSpacing: 10, children: children);
  });

  InputDecoration deco(String label) => InputDecoration(labelText: label, filled: true, fillColor: const Color(0xFF0D0606), border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)));

  Widget txt(String label, String value, ValueChanged<String> onChanged) => Padding(
    padding: const EdgeInsets.only(bottom: 10),
    child: TextFormField(initialValue: value, decoration: deco(label), onChanged: onChanged),
  );

  Widget numField(String label, int value, ValueChanged<int> onChanged) => Padding(
    padding: const EdgeInsets.only(bottom: 10),
    child: TextFormField(initialValue: '$value', keyboardType: TextInputType.number, decoration: deco(label), onChanged: (v)=>onChanged(int.tryParse(v) ?? 0)),
  );

  Widget textArea(String label, String value, ValueChanged<String> onChanged) => card(label, TextFormField(initialValue: value, minLines: 4, maxLines: null, decoration: deco(label), onChanged: onChanged));

  Widget dropdown(String label, String value, List<String> values, ValueChanged<String> onChanged) {
    final list = values.contains(value) ? values : [...values, value];
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: DropdownButtonFormField<String>(
        value: value,
        decoration: deco(label),
        items: list.map((v)=>DropdownMenuItem(value:v, child: Text(v))).toList(),
        onChanged: (v){ if(v != null) onChanged(v); },
      ),
    );
  }

  Future<bool> editDialog(String title, Map<String,dynamic> data, List<Field> fields) async {
    final ctrls = {for(final f in fields) f.key: TextEditingController(text: str(data[f.key]))};
    final ok = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: Text(title),
        content: SizedBox(
          width: 430,
          child: ListView(shrinkWrap: true, children: [
            for(final f in fields)
              Padding(
                padding: const EdgeInsets.only(bottom: 8),
                child: TextField(controller: ctrls[f.key], decoration: deco(f.label), keyboardType: f.number ? TextInputType.number : TextInputType.text, maxLines: f.multi ? 4 : 1),
              )
          ]),
        ),
        actions: [
          TextButton(onPressed: ()=>Navigator.pop(context,false), child: const Text('Cancelar')),
          FilledButton(onPressed: ()=>Navigator.pop(context,true), child: const Text('Salvar')),
        ],
      ),
    );
    if(ok == true) {
      for(final f in fields) {
        final v = ctrls[f.key]!.text;
        data[f.key] = f.number ? int.tryParse(v) ?? 0 : v;
      }
      return true;
    }
    return false;
  }

  Future<void> editListItem(String key, Map<String,dynamic> item, List<Field> fields, {bool add = false}) async {
    final edited = {...item};
    if(!await editDialog(label(key), edited, fields)) return;
    mutate((_) {
      if(add) list(key).add(edited);
      else {
        final idx = list(key).indexWhere((x)=>x['id'] == item['id']);
        if(idx >= 0) list(key)[idx] = edited;
      }
    });
  }

  Future<void> editGeneric(String key, Map<String,dynamic> item, List<String> fields) => editListItem(key, item, fields.map((f)=>Field(f,label(f), number: ['nex','level','left','value','skillMod'].contains(f))).toList());

  void addAttack() => editAttack({'id':uid(),'name':'Novo Ataque','skill':'Luta','attr':'Força','test':'1d20+0','damage':'1d6','crit':'20/x2','type':'Impacto','range':'Corpo a corpo','ammo':0,'ammoMax':0,'equipped':true,'fav':false,'notes':''}, add:true);
  Future<void> editAttack(Map<String,dynamic> item, {bool add=false}) => editListItem('attacks', item, [Field('name','Nome'),Field('skill','Perícia'),Field('attr','Atributo'),Field('test','Teste'),Field('damage','Dano'),Field('crit','Crítico'),Field('type','Tipo'),Field('range','Alcance'),Field('ammo','Munição',number:true),Field('ammoMax','Munição máxima',number:true),Field('notes','Notas',multi:true)], add:add);

  void addRitual() => editRitual({'id':uid(),'name':'Novo Ritual','element':'Sangue','circle':1,'execution':'Padrão','range':'Curto','target':'Alvo','duration':'Instantânea','resistance':'Nenhuma','cost':'1 PE','sustainCost':1,'effect':'','discente':'','verdadeiro':'','damage':'','components':'','sustain':false,'fav':false}, add:true);
  Future<void> editRitual(Map<String,dynamic> item, {bool add=false}) => editListItem('rituals', item, [Field('name','Nome'),Field('element','Elemento'),Field('circle','Círculo',number:true),Field('execution','Execução'),Field('range','Alcance'),Field('target','Alvo/Área'),Field('duration','Duração'),Field('resistance','Resistência'),Field('cost','Custo'),Field('sustainCost','Custo sustentado',number:true),Field('damage','Dano'),Field('components','Componentes'),Field('effect','Efeito',multi:true),Field('discente','Discente',multi:true),Field('verdadeiro','Verdadeiro',multi:true)], add:add);

  void addPower() => editPower({'id':uid(),'name':'Novo Poder','type':'Classe','cost':'','action':'','prereq':'','effect':'','fav':false}, add:true);
  Future<void> editPower(Map<String,dynamic> item, {bool add=false}) => editListItem('powers', item, [Field('name','Nome'),Field('type','Tipo'),Field('cost','Custo'),Field('action','Ação'),Field('prereq','Pré-requisito'),Field('effect','Efeito',multi:true)], add:add);

  void addItem() => editItem({'id':uid(),'name':'Novo Item','category':'Equipamento','qty':1,'load':0,'uses':0,'usesMax':0,'patent':'','fav':false,'desc':''}, add:true);
  Future<void> editItem(Map<String,dynamic> item, {bool add=false}) => editListItem('items', item, [Field('name','Nome'),Field('category','Categoria'),Field('qty','Quantidade',number:true),Field('load','Carga',number:true),Field('uses','Usos',number:true),Field('usesMax','Usos máximos',number:true),Field('patent','Patente'),Field('desc','Descrição',multi:true)], add:add);

  void addDefense() => editDefense({'id':uid(),'name':'Proteção','category':'Leve','def':0,'rd':0,'move':0,'penalty':'','equipped':false,'notes':''}, add:true);
  Future<void> editDefense(Map<String,dynamic> item, {bool add=false}) => editListItem('defenses', item, [Field('name','Nome'),Field('category','Categoria'),Field('def','Defesa',number:true),Field('rd','RD',number:true),Field('move','Movimento',number:true),Field('penalty','Penalidade'),Field('notes','Notas',multi:true)], add:add);

  void addBuff() => editBuff({'id':uid(),'name':'Novo Buff','active':true,'duration':'3 rodadas','atkBonus':0,'atkDice':0,'damageExtra':'','def':0,'rd':0,'skill':'','skillBonus':0,'fav':false}, add:true);
  Future<void> editBuff(Map<String,dynamic> item, {bool add=false}) => editListItem('buffs', item, [Field('name','Nome'),Field('duration','Duração'),Field('atkBonus','Bônus ataque',number:true),Field('atkDice','Dados d20 extras',number:true),Field('damageExtra','Dano extra'),Field('def','Defesa',number:true),Field('rd','RD',number:true),Field('skill','Perícia'),Field('skillBonus','Bônus perícia',number:true)], add:add);

  void addCondition() => editCondition({'id':uid(),'name':'Condição','duration':'manual','left':0,'effect':'','def':0,'rd':0,'skill':'','skillMod':0,'active':true}, add:true);
  Future<void> editCondition(Map<String,dynamic> item, {bool add=false}) => editListItem('conditions', item, [Field('name','Nome'),Field('duration','Duração'),Field('left','Restante',number:true),Field('effect','Efeito',multi:true),Field('def','Defesa',number:true),Field('rd','RD',number:true),Field('skill','Perícia'),Field('skillMod','Mod perícia',number:true)], add:add);

  void addNexAlteration() => editGeneric('nexAlterations', {'id':uid(),'on':true,'nex':65,'name':'Alteração personalizada','skill':'','skillMod':0,'notes':''}, ['name','nex','skill','skillMod','notes']);
  void addNexPreset() => mutate((_)=>list('nexAlterations').add({'id':uid(),'on':true,'nex':50,'name':'Preset de Alteração','skill':'Ocultismo','skillMod':2,'notes':'Edite conforme a mesa.'}));
  void addEvolution() => mutate((_)=>list('evolution').add({'id':uid(),'title':'Novo avanço','nex':intv(c['nex']),'level':intv(c['level']),'power':'','notes':''}));
  void addRelation() => mutate((_)=>list('relations').add({'id':uid(),'name':'NPC / Relação','type':'Aliado','trust':'0','notes':''}));
  void addResistance() => mutate((_)=>list('resistances').add({'id':uid(),'type':'Impacto','mode':'Resistência','value':5,'notes':''}));
  void addSceneEffect() => mutate((_)=>list('sceneEffects').add({'id':uid(),'name':'Efeito de cena','duration':'3 rodadas','left':3,'notes':''}));
  void addOfficialCondition() => mutate((_)=>list('conditions').add({'id':uid(),'name':'Sangrando','duration':'3 rodadas','left':3,'effect':'Edite conforme a mesa.','def':0,'rd':0,'skill':'','skillMod':0,'active':true}));

  void castRitual(Map<String,dynamic> r) {
    final amount = int.tryParse(RegExp(r'\d+').firstMatch(str(r['cost']))?.group(0) ?? '0') ?? 0;
    spend(rule('semSanidade') ? 'pd' : 'pe', amount);
    addReport('rituals', 1);
    log('Ritual', '${r['name']} conjurado. Custo ${r['cost']}.');
  }

  void maintainAll() {
    final cost = list('rituals').where((r)=>r['sustain']==true).fold<int>(0, (a,b)=>a+intv(b['sustainCost']));
    if(cost > 0) spend(rule('semSanidade') ? 'pd' : 'pe', cost);
    log('Sustentação', 'Custo total: $cost.');
  }

  void useItem(Map<String,dynamic> x) {
    final maxUses = intv(x['usesMax']);
    if(maxUses > 0 && intv(x['uses']) <= 0) {
      toast('Sem usos restantes.');
      return;
    }
    mutate((_) {
      if(maxUses > 0) x['uses'] = (intv(x['uses']) - 1).clamp(0,999);
    });
    log('Item', '${x['name']} usado.');
  }

  void executePrepared() {
    final p = map('prepare');
    for(final k in ['pe','pd','pv','san']) {
      final amount = intv(p[k]);
      if(amount > 0) spend(k, amount);
    }
    for(final t in str(p['tests']).split(';').map((x)=>x.trim()).where((x)=>x.isNotEmpty)) {
      roll(t, 'Teste preparado', test:true);
    }
    if(str(p['damage']).trim().isNotEmpty) roll(str(p['damage']), 'Dano preparado', test:false);
    log('Ação preparada', '${p['type']}: ${p['use']}');
  }

  void copyPrepared() {
    final p = map('prepare');
    final text = 'Plano: ${p['title']}\nTipo: ${p['type']}\nUsar: ${p['use']}\nAlvo: ${p['target']}\nCustos: PE ${p['pe']} | PD ${p['pd']} | PV ${p['pv']} | SAN ${p['san']}\nTestes: ${p['tests']}\nDano: ${p['damage']}\nComponentes: ${p['components']}\nDT: ${p['dt']}\nFalha: ${p['fail']}\nSucesso: ${p['success']}\nNotas: ${p['notes']}';
    Clipboard.setData(ClipboardData(text: text));
    toast('Plano copiado.');
  }

  void savePlan() => mutate((_) {
    final p = {...map('prepare')};
    p.remove('saved');
    listFrom(map('prepare')['saved']).add(p);
    map('prepare')['saved'] = listFrom(map('prepare')['saved']);
  });

  void clearPlan() => mutate((_) {
    final saved = map('prepare')['saved'];
    c['prepare'] = fresh()['prepare'];
    map('prepare')['saved'] = saved;
  });

  void spend(String key, int amount) {
    if(amount <= 0) return;
    mutate((_) {
      statMap()[key] = (statv(key) - amount).clamp(0, 999999);
      if(key == 'pe') { map('turn')['peSpent'] = intv(map('turn')['peSpent']) + amount; addReport('peSpent', amount, doSet:false); }
      if(key == 'pd') { map('turn')['pdSpent'] = intv(map('turn')['pdSpent']) + amount; addReport('pdSpent', amount, doSet:false); }
    });
    final pe = intv(map('turn')['peSpent']);
    final pd = intv(map('turn')['pdSpent']);
    final over = rule('limiteCombinado') ? pe + pd > peLimit() : pe > peLimit() || pd > peLimit();
    if(over) toast('Limite de PE/PD ultrapassado.');
  }

  void startTurn() {
    mutate((_) {
      map('turn')['round'] = intv(map('turn')['round']) + 1;
      map('turn')['peSpent'] = 0;
      map('turn')['pdSpent'] = 0;
      tickEffectsRaw();
    });
    log('Turno', 'Início do turno.');
  }

  void endTurn() => log('Turno', 'Fim do turno.');
  void nextRound() => mutate((_) { map('turn')['round'] = intv(map('turn')['round']) + 1; tickEffectsRaw(); });
  void nextScene() => mutate((_) { map('turn')['scene'] = intv(map('turn')['scene']) + 1; map('turn')['round'] = 1; list('rituals').forEach((r)=>r['sustain']=false); list('conditions').removeWhere((x)=>str(x['duration']).toLowerCase().contains('cena')); list('sceneEffects').removeWhere((x)=>str(x['duration']).toLowerCase().contains('cena')); });
  void tickEffects() => mutate((_)=>tickEffectsRaw());
  void tickEffectsRaw() {
    for(final key in ['conditions','sceneEffects']) {
      for(final x in list(key)) {
        if(str(x['duration']).toLowerCase().contains('rodada')) x['left'] = (intv(x['left']) - 1).clamp(0,999);
      }
      list(key).removeWhere((x)=>str(x['duration']).toLowerCase().contains('rodada') && intv(x['left']) <= 0);
    }
  }

  void calcDamage() {
    final exp = note('damageExp','2d6+3');
    final type = note('damageType','Impacto');
    final rd = int.tryParse(note('damageRd','0')) ?? 0;
    final r = rollExp(exp, test:false);
    var damage = (r.total - rd).clamp(0, 999999);
    for(final res in list('resistances').where((x)=>x['type']==type)) {
      final mode = str(res['mode']).toLowerCase();
      final value = intv(res['value']);
      if(mode.contains('imune')) damage = 0;
      else if(mode.contains('vulner')) damage *= value <= 1 ? 2 : value;
      else damage = (damage - value).clamp(0,999999);
    }
    addReport('damageDealt', damage);
    log('Dano avançado', '$type: $damage.');
    toast('Dano final: $damage');
  }

  void rollSkill(String sk) {
    final data = skill(sk);
    final dice = max(1, attrv(str(data['attr'])) + intv(data['dice']));
    final bonus = intv(data['train']) + intv(data['bonus']) + intv(data['temp']);
    roll('${dice}d20+$bonus', 'Teste de $sk', test:true);
  }

  void roll(String exp, String title, {required bool test}) {
    final r = rollExp(exp, test:test);
    log(title, '$exp = ${r.total} (${r.detail})');
    toast('$title: ${r.total}');
  }

  Roll rollExp(String exp, {required bool test}) {
    var clean = exp.toLowerCase().replaceAll(' ', '').replaceAll('−','-').replaceAll('ó','6');
    final parts = RegExp(r'[+-]?[^+-]+').allMatches(clean).map((m)=>m.group(0)!).toList();
    int total = 0;
    final detail = <String>[];
    for(var part in parts.isEmpty ? ['0'] : parts) {
      var sign = 1;
      if(part.startsWith('+')) part = part.substring(1);
      if(part.startsWith('-')) { sign = -1; part = part.substring(1); }
      final m = RegExp(r'^(\d*)d(\d+)$').firstMatch(part);
      if(m != null) {
        final q = int.tryParse(m.group(1)!.isEmpty ? '1' : m.group(1)!) ?? 1;
        final f = int.tryParse(m.group(2)!) ?? 20;
        final rolls = List.generate(q, (_)=>1+rand.nextInt(f));
        if(test && f == 20) {
          final chosen = rolls.reduce(max);
          total += sign * chosen;
          detail.add('${sign<0?'-':''}${q}d$f[${rolls.join(',')}] maior=$chosen');
        } else {
          final sum = rolls.fold<int>(0, (a,b)=>a+b);
          total += sign * sum;
          detail.add('${sign<0?'-':''}${q}d$f[${rolls.join(',')}]');
        }
      } else {
        final v = int.tryParse(part) ?? 0;
        total += sign * v;
        detail.add('${sign<0?'-':''}$v');
      }
    }
    return Roll(total, detail.join(' + ').replaceAll('+ -','- '));
  }

  void editSkill(String sk) async {
    final data = {...skill(sk)};
    if(!await editDialog(sk, data, [Field('attr','Atributo'),Field('train','Treino',number:true),Field('bonus','Bônus',number:true),Field('temp','Temp',number:true),Field('dice','Dados +/-',number:true)])) return;
    mutate((_)=>skillsMap()[sk]=data);
  }

  void applyRules() {
    if(rule('nexNivel')) {
      c['level'] = peLimit();
      statMap()['peTurn'] = peLimit();
    }
    if(calcBool('auto')) applyAuto();
  }

  Map<String,dynamic> derived() {
    final s = {...statMap()};
    final skillValues = <String,int>{};
    skillsMap().forEach((k,v)=>skillValues[k] = intv(v['train']) + intv(v['bonus']) + intv(v['temp']));
    int atkBonus = 0;
    int atkDice = 0;
    final dmgExtras = <String>[];

    for(final d in list('defenses').where((x)=>x['equipped']==true)) {
      s['def'] = intv(s['def']) + intv(d['def']);
      s['rd'] = intv(s['rd']) + intv(d['rd']);
      s['move'] = intv(s['move']) + intv(d['move']);
    }
    for(final b in list('buffs').where((x)=>x['active']==true)) {
      atkBonus += intv(b['atkBonus']);
      atkDice += intv(b['atkDice']);
      if(str(b['damageExtra']).trim().isNotEmpty) dmgExtras.add(str(b['damageExtra']));
      s['def'] = intv(s['def']) + intv(b['def']);
      s['rd'] = intv(s['rd']) + intv(b['rd']);
      if(skillValues.containsKey(b['skill'])) skillValues[str(b['skill'])] = skillValues[str(b['skill'])]! + intv(b['skillBonus']);
    }
    for(final cond in list('conditions').where((x)=>x['active']!=false)) {
      s['def'] = intv(s['def']) + intv(cond['def']);
      s['rd'] = intv(s['rd']) + intv(cond['rd']);
      if(skillValues.containsKey(cond['skill'])) skillValues[str(cond['skill'])] = skillValues[str(cond['skill'])]! + intv(cond['skillMod']);
    }
    if(rule('alteracoesNex')) {
      for(final a in list('nexAlterations').where((x)=>x['on']!=false && intv(c['nex']) >= intv(x['nex']))) {
        for(final k in ['pvMax','peMax','pdMax','sanMax','def','rd','move','dt']) {
          s[k] = intv(s[k]) + intv(a[k]);
        }
        if(skillValues.containsKey(a['skill'])) skillValues[str(a['skill'])] = skillValues[str(a['skill'])]! + intv(a['skillMod']);
      }
    }
    final alerts = <String>[];
    if(intv(s['pv']) <= 0) alerts.add('PV zerado');
    else if(intv(s['pv']) <= intv(s['pvMax'])/2) alerts.add('PV baixo');
    if(!rule('semSanidade') && intv(s['san']) <= intv(s['sanMax'])/3) alerts.add('SAN crítica');
    if(list('attacks').any((a)=>intv(a['ammoMax'])>0 && intv(a['ammo'])<=2)) alerts.add('Munição baixa');
    if(validate().isNotEmpty) alerts.add('${validate().length} aviso(s)');
    return {'stats':s,'skills':skillValues,'atkBonus':atkBonus,'atkDice':atkDice,'dmgExtras':dmgExtras,'alerts':alerts};
  }

  List<String> validate() {
    final out = <String>[];
    for(final k in ['pv','pe','pd','san']) {
      if(statv(k) > statv('${k}Max')) out.add('${k.toUpperCase()} acima do máximo.');
    }
    if(statv('load') > statv('loadMax')) out.add('Carga acima do limite.');
    for(final a in list('attacks')) {
      if(intv(a['ammoMax']) > 0 && intv(a['ammo']) > intv(a['ammoMax'])) out.add('Munição acima do máximo em ${a['name']}.');
    }
    return out;
  }

  Map<String,int> autoValues() {
    final lv = str(calc()['mode']) == 'nex' ? peLimit() : max(1,intv(c['level']));
    final after = max(0, lv - intv(calc()['baseLevel']));
    final pvMax = intv(calc()['pvBase']) + after*intv(calc()['pvLevel']) + (calcBool('pvVigor') ? attrv('Vigor')*lv : 0);
    final peMax = intv(calc()['peBase']) + after*intv(calc()['peLevel']);
    final pdMax = intv(calc()['pdBase']) + after*intv(calc()['pdLevel']);
    final sanMax = intv(calc()['sanBase']) + after*intv(calc()['sanLevel']) + (calcBool('sanPresenca') ? attrv('Presença')*lv : 0);
    final def = intv(calc()['defBase']) + (calcBool('defAgi') ? attrv('Agilidade') : 0);
    final dt = intv(calc()['dtBase']) + attrv(str(calc()['dtAttr'], 'Presença')) + (calcBool('dtNex') ? peLimit() : 0);
    final loadMax = intv(calc()['loadBase']) + attrv('Força')*intv(calc()['loadPerForca']);
    return {'pvMax':pvMax,'peMax':peMax,'pdMax':pdMax,'sanMax':sanMax,'def':def,'dt':dt,'peTurn':peLimit(),'loadMax':loadMax};
  }

  void applyAuto({bool fill=false}) {
    final a = autoValues();
    statMap().addAll(a);
    if(fill) {
      for(final k in ['pv','pe','pd','san']) {
        statMap()[k] = statv('${k}Max');
      }
    }
    for(final k in ['pv','pe','pd','san']) {
      statMap()[k] = statv(k).clamp(0, statv('${k}Max'));
    }
  }

  void calcLoad() => mutate((_)=>statMap()['load'] = list('items').fold<int>(0, (t,i)=>t+intv(i['load'])*max(1,intv(i['qty']))));
  void addReport(String key, int value, {bool doSet=true}) { map('report')[key] = intv(map('report')[key]) + value; if(doSet) setState((){}); }
  void setReport(String key, dynamic value) => mutate((_)=>map('report')[key]=value);
  void adjust(String key, int value) => mutate((_) { statMap()[key] = (statv(key)+value).clamp(0, statv('${key}Max') == 0 ? 999999 : statv('${key}Max')); });
  void removeItem(String key, Map<String,dynamic> item) => mutate((_)=>list(key).removeWhere((x)=>x['id']==item['id']));
  void setPrepare(String key, dynamic value) => mutate((_)=>map('prepare')[key]=value);
  void setNote(String key, String value) => mutate((_)=>map('notes')[key]=value);
  String note(String key, [String fallback='']) => str(map('notes')[key], fallback);
  void setStat(String key, int value) => mutate((_)=>statMap()[key]=value);
  void setAttr(String key, int value) => mutate((_)=>attrsMap()[key]=value);
  void setCalc(String key, dynamic value) => mutate((_)=>calc()[key]=value);
  void setRule(String key, bool value) => mutate((_)=>rules()[key]=value);
  void setv(String key, dynamic value, {bool snapshot=true}) => mutate((_)=>c[key]=value, snapshot:snapshot);
  void applyClassPreset(String cls) => mutate((_)=>calc().addAll(classPreset(cls)), snapshot:false);

  void mutate(void Function(Map<String,dynamic>) fn, {bool snapshot=true}) {
    if(snapshot) {
      undo.add(jsonDecode(jsonEncode(c)) as Map<String,dynamic>);
      if(undo.length > 25) undo.removeAt(0);
    }
    setState(() { fn(c); });
    if(boolv('autoSave')) save();
  }

  void undoLast() {
    if(undo.isEmpty) {
      toast('Nada para desfazer.');
      return;
    }
    setState(()=>c = undo.removeLast());
    save();
  }

  void log(String title, String text) => mutate((_) {
    list('rolls').add({'id':uid(),'title':title,'text':text,'time':DateTime.now().toString().substring(0,19)});
    if(list('rolls').length > 250) list('rolls').removeAt(0);
  }, snapshot:false);

  void createBackup(String labelText) => mutate((_) {
    list('backups').add({'id':uid(),'label':labelText,'time':DateTime.now().toString().substring(0,19),'data':jsonEncode(c)});
  });

  void restoreBackup(Map<String,dynamic> backup) {
    final raw = str(backup['data']);
    if(raw.isEmpty) return;
    mutate((_)=>c = jsonDecode(raw) as Map<String,dynamic>);
  }

  Future<void> exportJson() async {
    await Clipboard.setData(ClipboardData(text: jsonEncode(c)));
    toast('JSON copiado.');
  }

  Future<void> importJson() async {
    final ctrl = TextEditingController();
    final ok = await showDialog<bool>(context: context, builder: (_) => AlertDialog(
      title: const Text('Importar JSON'),
      content: TextField(controller: ctrl, minLines: 8, maxLines: 12, decoration: deco('Cole o JSON aqui')),
      actions: [TextButton(onPressed: ()=>Navigator.pop(context,false), child: const Text('Cancelar')), FilledButton(onPressed: ()=>Navigator.pop(context,true), child: const Text('Importar'))],
    ));
    if(ok == true) {
      try { mutate((_)=>c=jsonDecode(ctrl.text) as Map<String,dynamic>); toast('Importado.'); } catch(_) { toast('JSON inválido.'); }
    }
  }

  String summary() {
    final d = derived();
    final s = Map<String,dynamic>.from(d['stats']);
    final conds = list('conditions').map((x)=>x['name']).join(', ');
    final buffs = list('buffs').where((x)=>x['active']==true).map((x)=>x['name']).join(', ');
    final low = list('attacks').where((a)=>intv(a['ammoMax'])>0 && intv(a['ammo'])<=2).map((a)=>'${a['name']} ${a['ammo']}/${a['ammoMax']}').join(', ');
    return '${c['name']}\nPV ${s['pv']}/${s['pvMax']} | PE ${s['pe']}/${s['peMax']} | PD ${s['pd']}/${s['pdMax']}${rule('semSanidade')?'':' | SAN ${s['san']}/${s['sanMax']}'}\nDefesa ${s['def']} | RD ${s['rd']} | DT ${s['dt']}\nNEX ${c['nex']}% | Nível ${c['level']}\nCondições: ${conds.isEmpty?'nenhuma':conds}\nBuffs: ${buffs.isEmpty?'nenhum':buffs}\nMunição baixa: ${low.isEmpty?'nenhuma':low}\nAção preparada: ${map('prepare')['title'] ?? 'nenhuma'}';
  }

  Future<void> copySummary() async { await Clipboard.setData(ClipboardData(text: summary())); toast('Resumo copiado.'); }
  Future<void> copyHistory() async { await Clipboard.setData(ClipboardData(text: list('rolls').map((r)=>'[${r['time']}] ${r['title']}: ${r['text']}').join('\n'))); toast('Histórico copiado.'); }

  Future<void> save({bool show=false}) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(saveKey, jsonEncode(c));
    if(show) toast('Salvo.');
  }

  Future<void> load() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString(saveKey);
    if(raw != null) {
      setState(()=>c = merge(fresh(), jsonDecode(raw) as Map<String,dynamic>));
    }
  }

  Future<void> resetAll() async {
    final ok = await showDialog<bool>(context: context, builder: (_) => AlertDialog(
      title: const Text('Resetar ficha?'),
      content: const Text('Isso apaga o save local.'),
      actions: [TextButton(onPressed: ()=>Navigator.pop(context,false), child: const Text('Cancelar')), FilledButton(onPressed: ()=>Navigator.pop(context,true), child: const Text('Resetar'))],
    ));
    if(ok == true) {
      final prefs = await SharedPreferences.getInstance();
      await prefs.remove(saveKey);
      setState(()=>c=fresh());
    }
  }

  Map<String,dynamic> map(String key) => Map<String,dynamic>.from(c[key] as Map? ?? {});
  Map<String,dynamic> statMap() => c['stats'] as Map<String,dynamic>;
  Map<String,dynamic> attrsMap() => c['attrs'] as Map<String,dynamic>;
  Map<String,dynamic> skillsMap() => c['skills'] as Map<String,dynamic>;
  Map<String,dynamic> rules() => c['rules'] as Map<String,dynamic>;
  Map<String,dynamic> calc() => c['calc'] as Map<String,dynamic>;
  List<Map<String,dynamic>> list(String key) => (c[key] as List).cast<Map>().map((x)=>x.cast<String,dynamic>()).toList();
  List<Map<String,dynamic>> listFrom(dynamic v) => (v is List ? v : []).cast<Map>().map((x)=>x.cast<String,dynamic>()).toList();
  Map<String,dynamic> skill(String name) => Map<String,dynamic>.from(skillsMap()[name] as Map? ?? {});
  int statv(String k) => intv(statMap()[k]);
  int attrv(String k) => intv(attrsMap()[k]);
  bool rule(String k) => rules()[k] == true;
  bool boolv(String k) => c[k] == true;
  bool calcBool(String k) => calc()[k] == true;
  int peLimit() => max(1, (intv(c['nex']) / 5).ceil());
  int intv(dynamic v) => v is int ? v : (v is num ? v.round() : int.tryParse(v?.toString() ?? '') ?? 0);
  String str(dynamic v, [String fallback='']) => v?.toString() ?? fallback;
  String uid() => DateTime.now().millisecondsSinceEpoch.toString() + rand.nextInt(9999).toString();
  void toast(String msg) => ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg)));
  String label(String key) => {
    'use':'Usar','dmg':'Dano','crit':'Crítico','ammo':'Munição','fav':'Favoritar','edit':'Editar','del':'Excluir','sustain':'Sustentar',
    'name':'Nome','title':'Título','type':'Tipo','notes':'Notas','nex':'NEX','level':'Nível','power':'Poder','duration':'Duração',
    'left':'Restante','value':'Valor','mode':'Modo','damageDealt':'Dano causado','damageTaken':'Dano recebido','peSpent':'PE gasto',
    'pdSpent':'PD gasto','rituals':'Rituais','attacks':'Ataques','clues':'Pistas','investigation':'Investigação','theories':'Teorias',
    'documents':'Documentos','symbols':'Símbolos','mission':'Missão','sideObjectives':'Objetivos secundários','missionThreat':'Ameaça',
    'missionRewards':'Recompensas','appearance':'Aparência','personality':'Personalidade','trauma':'Traumas','history':'História'
  }[key] ?? key;

  String addD20Dice(String exp, int extra) {
    if(extra == 0) return exp;
    return exp.replaceFirstMapped(RegExp(r'(\d*)d20'), (m) {
      final q = int.tryParse(m.group(1)!.isEmpty ? '1' : m.group(1)!) ?? 1;
      return '${q+extra}d20';
    });
  }

  String critExpr(String damage, String crit) {
    final mult = int.tryParse(RegExp(r'x(\d+)').firstMatch(crit.toLowerCase())?.group(1) ?? '2') ?? 2;
    return damage.replaceAllMapped(RegExp(r'(\d*)d(\d+)'), (m) {
      final q = int.tryParse(m.group(1)!.isEmpty ? '1' : m.group(1)!) ?? 1;
      return '${q*mult}d${m.group(2)}';
    });
  }

  String? detect(String text) => RegExp(r'\d+d\d+(?:[+-]\d+)?', caseSensitive:false).firstMatch(text.replaceAll('ó','6'))?.group(0);
  String initials(String s) => s.split(RegExp(r'\s+')).where((x)=>x.isNotEmpty).map((x)=>x[0]).take(2).join().toUpperCase();

  Map<String,int> classPreset(String cls) {
    if(cls == 'Combatente') return {'pvBase':20,'pvLevel':5,'peBase':2,'peLevel':2,'pdBase':0,'pdLevel':0,'sanBase':12,'sanLevel':3};
    if(cls == 'Especialista') return {'pvBase':16,'pvLevel':4,'peBase':3,'peLevel':3,'pdBase':0,'pdLevel':0,'sanBase':16,'sanLevel':4};
    if(cls == 'Ocultista') return {'pvBase':12,'pvLevel':3,'peBase':4,'peLevel':4,'pdBase':0,'pdLevel':0,'sanBase':20,'sanLevel':5};
    return {'pvBase':16,'pvLevel':4,'peBase':2,'peLevel':1,'pdBase':0,'pdLevel':0,'sanBase':16,'sanLevel':4};
  }
}

class Field {
  final String key;
  final String label;
  final bool number;
  final bool multi;
  Field(this.key, this.label, {this.number=false, this.multi=false});
}

class Roll {
  final int total;
  final String detail;
  Roll(this.total, this.detail);
}

Map<String,dynamic> fresh() {
  final skillAttrs = <String,String>{
    for(final s in skills) s: defaultSkillAttr(s)
  };
  return {
    'name':'Agente Sem Nome','class':'Sobrevivente','trail':'—','origin':'—','affinity':'','theme':'sangue','nex':5,'level':1,'autoSave':true,'playerMode':false,
    'stats': {'pv':20,'pvMax':20,'pe':4,'peMax':4,'pd':0,'pdMax':0,'san':20,'sanMax':20,'def':10,'rd':0,'move':9,'dt':0,'peTurn':1,'load':0,'loadMax':10},
    'attrs': {for(final a in attrs) a:1},
    'skills': {for(final s in skills) s:{'attr':skillAttrs[s],'train':0,'bonus':0,'temp':0,'dice':0}},
    'rules': {'nexNivel':false,'municao':true,'alteracoesNex':false,'semSanidade':false,'combateNarrativo':false,'conjuracaoComplexa':false,'limiteCombinado':false},
    'calc': {'auto':false,'mode':'level','baseLevel':1,'pvBase':16,'pvLevel':4,'peBase':2,'peLevel':1,'pdBase':0,'pdLevel':0,'sanBase':16,'sanLevel':4,'pvVigor':true,'sanPresenca':true,'defBase':10,'defAgi':true,'dtBase':10,'dtAttr':'Presença','dtNex':true,'loadBase':5,'loadPerForca':5},
    'notes': {'order':'','session':'','clues':'','secret':'','investigation':'','mission':'','history':'','trauma':'','appearance':'','personality':'','relationships':'','narrative':''},
    'turn': {'scene':1,'round':1,'peSpent':0,'pdSpent':0},
    'report': {'damageDealt':0,'damageTaken':0,'peSpent':0,'pdSpent':0,'rituals':0,'attacks':0,'notes':''},
    'prepare': {'title':'','type':'Ataque','use':'','target':'','pe':0,'pd':0,'pv':0,'san':0,'tests':'','damage':'','components':'','dt':'','time':'','fail':'','success':'','notes':'','saved':[]},
    'attacks': [{'id':'atk1','name':'Ataque Improvisado','skill':'Luta','attr':'Força','test':'1d20+0','damage':'1d6','crit':'20/x2','type':'Impacto','range':'Corpo a corpo','ammo':0,'ammoMax':0,'equipped':true,'fav':true,'notes':''}],
    'rituals': [], 'powers': [], 'items': [], 'defenses': [], 'buffs': [], 'conditions': [], 'resistances': [],
    'nexAlterations': [{'id':'nex25','on':true,'nex':25,'name':'Alteração 25%','skill':'Ocultismo','skillMod':2,'notes':'Exemplo editável.'}],
    'sceneEffects': [], 'evolution': [], 'relations': [], 'backups': [], 'rolls': []
  };
}

String defaultSkillAttr(String s) {
  const agi = ['Acrobacia','Crime','Furtividade','Iniciativa','Pilotagem','Pontaria','Reflexos'];
  const str = ['Atletismo','Luta'];
  const vig = ['Fortitude'];
  const pre = ['Adestramento','Artes','Diplomacia','Enganação','Intimidação','Intuição','Percepção','Vontade'];
  if(agi.contains(s)) return 'Agilidade';
  if(str.contains(s)) return 'Força';
  if(vig.contains(s)) return 'Vigor';
  if(pre.contains(s)) return 'Presença';
  return 'Intelecto';
}

Map<String,dynamic> merge(Map<String,dynamic> base, Map<String,dynamic> raw) {
  final out = {...base, ...raw};
  for(final k in ['stats','attrs','skills','rules','calc','notes','turn','report','prepare']) {
    if(base[k] is Map) out[k] = {...Map<String,dynamic>.from(base[k]), ...Map<String,dynamic>.from(raw[k] ?? {})};
  }
  for(final k in ['attacks','rituals','powers','items','defenses','buffs','conditions','resistances','nexAlterations','sceneEffects','evolution','relations','backups','rolls']) {
    if(raw[k] is! List) out[k] = base[k];
  }
  return out;
}
