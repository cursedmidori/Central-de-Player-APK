
import 'dart:math';

int toInt(dynamic v) {
  if (v is int) return v;
  if (v is double) return v.round();
  return int.tryParse('$v') ?? 0;
}

double toDouble(dynamic v) {
  if (v is num) return v.toDouble();
  return double.tryParse('$v') ?? 0;
}

String newId([String prefix = 'id']) => '$prefix${DateTime.now().millisecondsSinceEpoch}${Random().nextInt(999999)}';

String initials(String value) {
  final clean = value.trim();
  if (clean.isEmpty) return 'A';
  final parts = clean.split(RegExp(r'\s+')).where((p) => p.isNotEmpty).toList();
  final letters = parts.map((p) => p.substring(0, 1)).join();
  if (letters.isEmpty) return 'A';
  return letters.length >= 2 ? letters.substring(0, 2).toUpperCase() : letters.toUpperCase();
}

Map<String, dynamic> asMap(dynamic value) {
  if (value is Map) return Map<String, dynamic>.from(value);
  return <String, dynamic>{};
}

List<Map<String, dynamic>> asListOfMaps(dynamic value) {
  if (value is! List) return <Map<String, dynamic>>[];
  return value.whereType<Map>().map((e) => Map<String, dynamic>.from(e)).toList();
}

String cleanText(dynamic value) => value == null ? '' : '$value';

String firstValue(Map<String, dynamic> m, List<String> keys, [String fallback = '']) {
  for (final k in keys) {
    final v = m[k];
    if (v != null && '$v'.trim().isNotEmpty) return '$v';
  }
  return fallback;
}

int firstInt(Map<String, dynamic> m, List<String> keys, [int fallback = 0]) {
  for (final k in keys) {
    final v = m[k];
    if (v != null && '$v'.trim().isNotEmpty) return toInt(v);
  }
  return fallback;
}
