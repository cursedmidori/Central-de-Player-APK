# Central Player Flutter V5 Definitiva

Esta versão é uma central maior para jogador de Ordem Paranormal.

## Inclui

- Modo Sessão / Modo Edição.
- Ficha completa.
- Origem, classe, trilha e conceito.
- Perícias editáveis e rolagem no padrão Ordem Paranormal.
- Armas avançadas.
- Rituais avançados.
- Poderes e habilidades completos.
- Inventário e equipamentos.
- Proteções e buffs defensivos.
- Condições oficiais e personalizadas.
- Ferimentos, traumas, Marcas da Sobrevivência e Alterações de NEX.
- Investigação, missão, NPCs, pistas, teorias e relações.
- Descanso e interlúdio.
- Evolução.
- Preparar Ação 2.0 e Combos.
- Validador avançado.
- Resumo para o mestre.
- Backups.
- Importar JSON e Exportar JSON por área de transferência.

## Importar JSON

Abra a aba **Importar/Exportar** e use:

- **Colar JSON**: cola manualmente uma ficha.
- **Importar da área de transferência**: copia o JSON antes e aperta o botão.

O importador tenta reconhecer chaves como:

- nome/name
- classe/class
- trilha/trail
- origem/origin
- nex/NEX
- atributos/attrs
- pericias/skills
- armas/ataques/weapons/attacks
- rituais/rituals
- poderes/habilidades/powers
- inventario/itens/items

## Gerar APK

Envie todos os arquivos para o GitHub e rode:

Actions > Gerar APK Flutter > Run workflow

O APK sai no artefato `central-player-v5-debug-apk`.


## V5.1

Correções de build:
- Corrigido parêntese faltando em `sessionScreen` / `BloodCard` de Alertas.
- Removido uso de `String.characters` sem dependência/import, usando `substring(0, 1)`.


## V5.2 — Importar e Exportar arquivo JSON direto

Mudanças:
- Adicionado botão **Selecionar arquivo JSON** na aba Importar/Exportar.
- Adicionado botão **Exportar arquivo JSON**.
- O app agora gera um arquivo `.json` e abre a tela de compartilhamento/salvar do Android.
- Ainda mantive as opções de colar/copiar JSON como alternativa.
