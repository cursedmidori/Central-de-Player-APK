
import 'dart:convert';
import 'dart:math';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'app_state.dart';
import 'data.dart';
import 'dice.dart';
import 'utils.dart';
import 'widgets.dart';

const saveKey = 'central_player_flutter_v5_definitiva';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const CentralPlayerApp());
}

class CentralPlayerApp extends StatelessWidget {
  const CentralPlayerApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Central do Player',
      debugShowCheckedModeBanner: false,
      theme: ThemeData.dark(useMaterial3: true).copyWith(
        scaffoldBackgroundColor: bg,
        colorScheme: const ColorScheme.dark(primary: red, secondary: gold, surface: panel),
        snackBarTheme: const SnackBarThemeData(
          behavior: SnackBarBehavior.floating,
          backgroundColor: Color(0xFF160707),
          contentTextStyle: TextStyle(color: text, fontWeight: FontWeight.w800),
        ),
      ),
      home: const PlayerHome(),
    );
  }
}

class PlayerHome extends StatefulWidget {
  const PlayerHome({super.key});

  @override
  State<PlayerHome> createState() => _PlayerHomeState();
}

class _PlayerHomeState extends State<PlayerHome> {
  AppState state = AppState();
  int tab = 0;
  bool sessionMode = true;

  final tabs = const [
    'Sessão',
    'Ficha',
    'Origem/Classe',
    'Perícias',
    'Armas',
    'Rituais',
    'Poderes',
    'Inventário',
    'Defesa',
    'Condições',
    'Ferimentos/Marcas',
    'Investigação',
    'Descanso',
    'Evolução',
    'Preparar/Combos',
    'Validador',
    'Backups',
    'Importar/Exportar',
    'Config',
  ];

  @override
  void initState() {
    super.initState();
    load();
  }

  Future<void> save({bool notify = false}) async {
    final sp = await SharedPreferences.getInstance();
    await sp.setString(saveKey, jsonEncode(state.toJson()));
    if (notify) toast('Ficha salva.');
  }

  Future<void> load() async {
    final sp = await SharedPreferences.getInstance();
    final raw = sp.getString(saveKey);
    if (raw != null) {
      try {
        setState(() => state = AppState.fromJson(jsonDecode(raw) as Map<String, dynamic>));
      } catch (_) {
        toast('Não consegui carregar o save antigo.');
      }
    }
  }

  void applyRules() {
    if (state.optional['nexNivel'] == true) {
      state.p['level'] = peLimit;
      state.stats['peTurn'] = peLimit;
    }
  }

  int get peLimit => max(1, ((toInt(state.p['nex']) + 4) / 5).floor());

  Map<String, dynamic> derivedStats() {
    final s = Map<String, dynamic>.from(state.stats);
    for (final p in state.protections.where((p) => p['equipped'] == true || p['eq'] == true)) {
      s['def'] = toInt(s['def']) + toInt(p['def']);
      s['rd'] = toInt(s['rd']) + toInt(p['rd']);
    }
    for (final b in state.buffs.where((b) => b['active'] == true)) {
      s['def'] = toInt(s['def']) + toInt(b['def']);
      s['rd'] = toInt(s['rd']) + toInt(b['rd']);
      s['dt'] = toInt(s['dt']) + toInt(b['dt']);
    }
    return s;
  }

  void log(String title, String textValue) {
    state.logs.add({
      'title': title,
      'text': textValue,
      'time': DateTime.now().toString().substring(0, 19),
    });
    if (state.logs.length > 150) state.logs.removeAt(0);
  }

  void toast(String msg) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).clearSnackBars();
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg)));
  }

  Future<void> roll(String exp, String title, {bool damage = false}) async {
    final result = damage ? DiceService.damage(exp) : DiceService.test(exp);
    setState(() {
      log(title, '$exp = ${result.total} — ${result.detail}');
    });
    await showRollDialog(title, exp, result);
    toast('$title: ${result.total}');
    save();
  }

  Future<void> showRollDialog(String title, String exp, RollResult r) async {
    if (!mounted) return;
    await showGeneralDialog(
      context: context,
      barrierDismissible: true,
      barrierLabel: 'Rolagem',
      transitionDuration: const Duration(milliseconds: 170),
      pageBuilder: (_, __, ___) => Align(
        alignment: Alignment.topCenter,
        child: Material(
          color: Colors.transparent,
          child: Container(
            width: min(MediaQuery.of(context).size.width - 24, 520.0),
            margin: const EdgeInsets.only(top: 28),
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: const Color(0xFF100707),
              borderRadius: BorderRadius.circular(18),
              border: Border.all(color: red),
              boxShadow: const [BoxShadow(blurRadius: 32, color: Colors.black87)],
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title.toUpperCase(), style: const TextStyle(fontWeight: FontWeight.w900, letterSpacing: 1.2)),
                const SizedBox(height: 8),
                Text('${r.total}', style: const TextStyle(fontSize: 48, color: gold, fontWeight: FontWeight.w900)),
                Text('$exp • ${r.mode}', style: const TextStyle(color: muted)),
                const SizedBox(height: 8),
                Text(r.detail, style: const TextStyle(color: text)),
                const SizedBox(height: 12),
                Align(
                  alignment: Alignment.centerRight,
                  child: FilledButton(onPressed: () => Navigator.pop(context), child: const Text('Fechar')),
                )
              ],
            ),
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    applyRules();
    final wide = MediaQuery.of(context).size.width > 920;
    final visibleTabs = sessionMode ? [0, 3, 4, 5, 6, 9, 14, 11, 17, 18] : List<int>.generate(tabs.length, (i) => i);
    if (!visibleTabs.contains(tab)) tab = visibleTabs.first;

    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: RadialGradient(
            center: Alignment(-0.8, -1),
            radius: 1.2,
            colors: [Color(0x55361113), bg],
          ),
        ),
        child: SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(10),
            child: wide
                ? Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      SizedBox(width: 286, child: sideBar(visibleTabs)),
                      const SizedBox(width: 10),
                      Expanded(child: mainContent()),
                    ],
                  )
                : Column(
                    children: [
                      mobileTabs(visibleTabs),
                      const SizedBox(height: 8),
                      Expanded(child: mainContent()),
                    ],
                  ),
          ),
        ),
      ),
    );
  }

  Widget sideBar(List<int> visibleTabs) {
    return BloodPanel(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          headerMini(),
          const SizedBox(height: 12),
          Row(
            children: [
              Expanded(child: AppButton(sessionMode ? 'Modo Sessão' : 'Modo Edição', () => setState(() => sessionMode = !sessionMode), kind: sessionMode ? BadgeKind.green : BadgeKind.gold)),
            ],
          ),
          const SizedBox(height: 14),
          const SectionTitle('Abas'),
          for (final i in visibleTabs)
            Padding(
              padding: const EdgeInsets.only(bottom: 7),
              child: tabButton(i),
            ),
        ],
      ),
    );
  }

  Widget mobileTabs(List<int> visibleTabs) {
    return SizedBox(
      height: 50,
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        itemCount: visibleTabs.length + 1,
        separatorBuilder: (_, __) => const SizedBox(width: 7),
        itemBuilder: (_, idx) {
          if (idx == 0) {
            return AppButton(sessionMode ? 'Sessão' : 'Edição', () => setState(() => sessionMode = !sessionMode), kind: sessionMode ? BadgeKind.green : BadgeKind.gold);
          }
          return tabButton(visibleTabs[idx - 1]);
        },
      ),
    );
  }

  Widget tabButton(int i) {
    final selected = tab == i;
    return OutlinedButton(
      onPressed: () => setState(() => tab = i),
      style: OutlinedButton.styleFrom(
        side: BorderSide(color: selected ? red : line),
        backgroundColor: selected ? const Color(0x55690912) : const Color(0xFF130808),
        foregroundColor: text,
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 12),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      ),
      child: Text(tabs[i].toUpperCase(), style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w900)),
    );
  }

  Widget mainContent() {
    return ListView(
      children: [
        header(),
        const SizedBox(height: 10),
        if (tab == 0) sessionScreen(),
        if (tab == 1) fichaScreen(),
        if (tab == 2) originClassScreen(),
        if (tab == 3) skillsScreen(),
        if (tab == 4) weaponsScreen(),
        if (tab == 5) ritualsScreen(),
        if (tab == 6) powersScreen(),
        if (tab == 7) inventoryScreen(),
        if (tab == 8) defenseScreen(),
        if (tab == 9) conditionsScreen(),
        if (tab == 10) injuriesMarksScreen(),
        if (tab == 11) investigationScreen(),
        if (tab == 12) restScreen(),
        if (tab == 13) evolutionScreen(),
        if (tab == 14) prepareCombosScreen(),
        if (tab == 15) validatorScreen(),
        if (tab == 16) backupsScreen(),
        if (tab == 17) importExportScreen(),
        if (tab == 18) configScreen(),
      ],
    );
  }

  Widget headerMini() {
    return Column(
      children: [
        CircleAvatar(
          radius: 34,
          backgroundColor: const Color(0xFF260A0D),
          child: Text(initials('${state.p['name']}'), style: const TextStyle(fontSize: 26, fontWeight: FontWeight.w900)),
        ),
        const SizedBox(height: 8),
        Text('${state.p['name']}'.toUpperCase(), textAlign: TextAlign.center, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w900)),
        Text('${state.p['class']} • ${state.p['trail']}', textAlign: TextAlign.center, style: const TextStyle(color: muted, fontSize: 12)),
      ],
    );
  }

  Widget header() {
    final s = derivedStats();
    return BloodPanel(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Wrap(
            spacing: 12,
            runSpacing: 10,
            crossAxisAlignment: WrapCrossAlignment.center,
            children: [
              CircleAvatar(
                radius: 38,
                backgroundColor: const Color(0xFF260A0D),
                child: Text(initials('${state.p['name']}'), style: const TextStyle(fontSize: 28, fontWeight: FontWeight.w900)),
              ),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const BadgeText('Central Definitiva V5'),
                  Text('${state.p['name']}'.toUpperCase(), style: const TextStyle(fontSize: 34, fontWeight: FontWeight.w900, height: 1)),
                  Wrap(
                    children: [
                      BadgeText('${state.p['class']} • ${state.p['trail']}', kind: BadgeKind.blue),
                      BadgeText('NEX ${state.p['nex']}% • Nível ${state.p['level']}', kind: BadgeKind.gold),
                      BadgeText(sessionMode ? 'Modo Sessão' : 'Modo Edição', kind: sessionMode ? BadgeKind.green : BadgeKind.purple),
                    ],
                  ),
                ],
              ),
              Wrap(
                spacing: 8,
                children: [
                  AppButton('Salvar', () => save(notify: true), kind: BadgeKind.green),
                  AppButton('d20', () => roll('1d20', 'Rolagem rápida'), kind: BadgeKind.blue),
                  AppButton('Resumo Mestre', copyMasterSummary, kind: BadgeKind.gold),
                ],
              )
            ],
          ),
          const SizedBox(height: 14),
          ResponsiveGrid(
            minItemWidth: 210,
            children: [
              StatCard('PV', toInt(s['pv']), toInt(s['pvMax']), onMinus: () => adjustStat('pv', -1), onPlus: () => adjustStat('pv', 1)),
              if (state.optional['semSanidade'] == true)
                StatCard('PD', toInt(s['pd']), toInt(s['pdMax']), kind: BadgeKind.blue, onMinus: () => adjustStat('pd', -1), onPlus: () => adjustStat('pd', 1))
              else ...[
                StatCard('PE', toInt(s['pe']), toInt(s['peMax']), kind: BadgeKind.blue, onMinus: () => adjustStat('pe', -1), onPlus: () => adjustStat('pe', 1)),
                StatCard('SAN', toInt(s['san']), toInt(s['sanMax']), kind: BadgeKind.green, onMinus: () => adjustStat('san', -1), onPlus: () => adjustStat('san', 1)),
              ],
              InfoCard('DEF/RD', '${s['def']}/${s['rd']}', 'DT ${s['dt']} • Mov. ${s['move']}m • PE/turno ${s['peTurn']}'),
            ],
          )
        ],
      ),
    );
  }

  void adjustStat(String key, int delta) {
    setState(() {
      state.stats[key] = max(0, toInt(state.stats[key]) + delta);
      final maxKey = '${key}Max';
      if (state.stats.containsKey(maxKey)) state.stats[key] = min(toInt(state.stats[key]), toInt(state.stats[maxKey]));
      log('Status', '$key ${delta > 0 ? '+' : ''}$delta');
    });
    save();
  }

  Widget sessionScreen() {
    return Column(
      children: [
        ResponsiveGrid(children: [
          BloodCard(
            title: 'Ações rápidas',
            child: Wrap(spacing: 8, runSpacing: 8, children: [
              AppButton('Rolar d20', () => roll('1d20', 'd20'), kind: BadgeKind.blue),
              AppButton('Preparar ação', () => setState(() => tab = 14), kind: BadgeKind.gold),
              AppButton('Nova rodada', nextRound, kind: BadgeKind.purple),
              AppButton('Salvar', () => save(notify: true), kind: BadgeKind.green),
            ]),
          ),
          BloodCard(
            title: 'Alertas',
            child: Wrap(spacing: 6, runSpacing: 6, children: validatorIssues().isEmpty ? [const BadgeText('Tudo limpo', kind: BadgeKind.green)] : validatorIssues().map((e) => BadgeText(e, kind: BadgeKind.gold)).toList(),
            ),
          ),
        ]),
        const SizedBox(height: 10),
        BloodCard(
          title: 'Favoritos',
          child: ResponsiveGrid(
            children: [
              ...state.weapons.where((w) => w['fav'] == true || w['equipped'] == true).map(weaponCard),
              ...state.rituals.where((r) => r['fav'] == true).map(ritualCard),
              ...state.powers.where((p) => p['fav'] == true).map(powerCard),
            ],
          ),
        ),
        const SizedBox(height: 10),
        BloodCard(
          title: 'Histórico recente',
          child: Column(children: state.logs.reversed.take(8).map((l) => LogLine(l)).toList()),
        ),
      ],
    );
  }

  Widget fichaScreen() {
    return ResponsiveGrid(children: [
      BloodCard(
        title: 'Identidade',
        child: Column(children: [
          field('Nome', state.p['name'], (v) => state.p['name'] = v),
          field('Classe', state.p['class'], (v) => state.p['class'] = v),
          field('Trilha', state.p['trail'], (v) => state.p['trail'] = v),
          field('Origem', state.p['origin'], (v) => state.p['origin'] = v),
          intField('NEX', state.p['nex'], (v) => state.p['nex'] = v),
          intField('Nível', state.p['level'], (v) => state.p['level'] = v),
          field('Afinidade', state.p['affinity'], (v) => state.p['affinity'] = v),
        ]),
      ),
      BloodCard(
        title: 'Status',
        child: Column(children: [
          for (final k in ['pv', 'pvMax', 'pe', 'peMax', 'pd', 'pdMax', 'san', 'sanMax', 'def', 'rd', 'dt', 'move', 'load', 'loadMax'])
            intField(k.toUpperCase(), state.stats[k], (v) => state.stats[k] = v),
        ]),
      ),
      BloodCard(
        title: 'Atributos',
        child: Column(children: [
          for (final a in attrs) intField(a, state.attrsMap[a], (v) => state.attrsMap[a] = v),
        ]),
      ),
    ]);
  }

  Widget originClassScreen() {
    return ResponsiveGrid(children: [
      BloodCard(
        title: 'Criação e Conceito',
        child: Column(children: [
          field('Conceito', state.profile['concept'], (v) => state.profile['concept'] = v, lines: 3),
          field('Aparência', state.profile['appearance'], (v) => state.profile['appearance'] = v, lines: 3),
          field('Personalidade', state.profile['personality'], (v) => state.profile['personality'] = v, lines: 3),
          field('Medo pessoal', state.profile['fear'], (v) => state.profile['fear'] = v),
          field('Objetivo', state.profile['objective'], (v) => state.profile['objective'] = v),
        ]),
      ),
      BloodCard(
        title: 'Origem',
        child: Column(children: [
          field('Origem', state.p['origin'], (v) => state.p['origin'] = v),
          field('Poder da origem', state.profile['originPower'], (v) => state.profile['originPower'] = v, lines: 4),
          field('Perícias da origem', state.profile['originSkills'], (v) => state.profile['originSkills'] = v, lines: 2),
        ]),
      ),
      BloodCard(
        title: 'Classe e Trilha',
        child: Column(children: [
          field('Classe', state.p['class'], (v) => state.p['class'] = v),
          field('Habilidade base da classe', state.profile['classAbility'], (v) => state.profile['classAbility'] = v, lines: 4),
          field('Trilha', state.p['trail'], (v) => state.p['trail'] = v),
          field('Habilidades da trilha', state.profile['trailAbilities'], (v) => state.profile['trailAbilities'] = v, lines: 5),
          field('Poderes escolhidos', state.profile['chosenPowers'], (v) => state.profile['chosenPowers'] = v, lines: 4),
          field('Notas da build', state.profile['buildNotes'], (v) => state.profile['buildNotes'] = v, lines: 4),
        ]),
      ),
    ]);
  }

  Widget skillsScreen() {
    return ResponsiveGrid(
      children: skillNames.map((name) {
        final sk = state.skills[name]!;
        final attr = '${sk['attr']}';
        final total = toInt(sk['train']) + toInt(sk['bonus']) + toInt(sk['temp']);
        final dice = max(1, toInt(state.attrsMap[attr]) + toInt(sk['extraDice']));
        return BloodCard(
          title: name,
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Wrap(children: [
              BadgeText(attr, kind: BadgeKind.blue),
              BadgeText('+$total', kind: BadgeKind.gold),
              BadgeText('${dice}d20', kind: BadgeKind.blue),
            ]),
            const SizedBox(height: 8),
            Text('Treino ${sk['train']} • Bônus ${sk['bonus']} • Temp ${sk['temp']} • Dados extras ${sk['extraDice']}', style: const TextStyle(color: muted)),
            const SizedBox(height: 8),
            Wrap(spacing: 8, runSpacing: 8, children: [
              AppButton('Rolar', () => roll('${dice}d20+$total', 'Teste de $name'), kind: BadgeKind.blue),
              AppButton('Editar', () => editSkill(name), kind: BadgeKind.gold),
            ]),
          ]),
        );
      }).toList(),
    );
  }

  Future<void> editSkill(String name) async {
    final sk = state.skills[name]!;
    final values = {
      'attr': '${sk['attr']}',
      'train': '${sk['train']}',
      'bonus': '${sk['bonus']}',
      'temp': '${sk['temp']}',
      'extraDice': '${sk['extraDice']}',
    };
    final result = await editMapDialog('Editar $name', values);
    if (result != null) {
      setState(() {
        state.skills[name] = {
          'attr': result['attr']!.trim().isEmpty ? defaultSkillAttr(name) : result['attr']!.trim(),
          'train': int.tryParse(result['train']!) ?? 0,
          'bonus': int.tryParse(result['bonus']!) ?? 0,
          'temp': int.tryParse(result['temp']!) ?? 0,
          'extraDice': int.tryParse(result['extraDice']!) ?? 0,
        };
      });
      save();
    }
  }

  Widget weaponsScreen() => listScreen(
        title: 'Armas Avançadas',
        addLabel: '+ Arma',
        list: state.weapons,
        create: () => {
          'id': newId('weapon'),
          'name': 'Nova Arma',
          'skill': 'Luta',
          'attr': 'Força',
          'test': '1d20+0',
          'damage': '1d6',
          'type': 'Impacto',
          'crit': '20/x2',
          'range': '',
          'category': '',
          'ammo': 0,
          'ammoMax': 0,
          'reload': '',
          'mods': '',
          'curses': '',
          'equipped': true,
          'fav': false,
          'notes': '',
        },
        card: weaponCard,
      );

  Widget weaponCard(Map<String, dynamic> w) {
    return BloodCard(
      title: '${w['name']}',
      actions: [IconButton(onPressed: () => removeItem(state.weapons, w), icon: const Icon(Icons.delete, color: red))],
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Wrap(children: [
          BadgeText('${w['test']}', kind: BadgeKind.blue),
          BadgeText('${w['damage']}', kind: BadgeKind.gold),
          BadgeText('${w['type']}'),
          if (w['fav'] == true) const BadgeText('Fav', kind: BadgeKind.green),
        ]),
        const SizedBox(height: 8),
        Text('Perícia ${w['skill']} • Atributo ${w['attr']} • Crítico ${w['crit']} • Munição ${w['ammo']}/${w['ammoMax']}', style: const TextStyle(color: muted)),
        const SizedBox(height: 8),
        Text('Modificações: ${w['mods']}\nMaldições: ${w['curses']}', style: const TextStyle(color: muted)),
        const SizedBox(height: 8),
        Wrap(spacing: 8, runSpacing: 8, children: [
          AppButton('Ataque', () => roll('${w['test']}', 'Ataque: ${w['name']}'), kind: BadgeKind.blue),
          AppButton('Dano', () => roll('${w['damage']}', 'Dano: ${w['name']}', damage: true), kind: BadgeKind.gold),
          AppButton('Mun -1', () {
            setState(() => w['ammo'] = max(0, toInt(w['ammo']) - 1));
            save();
          }),
          AppButton('Fav', () {
            setState(() => w['fav'] = w['fav'] != true);
            save();
          }, kind: BadgeKind.green),
          AppButton('Editar', () => editGeneric(w, ['name', 'skill', 'attr', 'test', 'damage', 'type', 'crit', 'range', 'category', 'ammo', 'ammoMax', 'reload', 'mods', 'curses', 'notes']), kind: BadgeKind.gold),
        ]),
      ]),
    );
  }

  Widget ritualsScreen() => listScreen(
        title: 'Rituais Avançados',
        addLabel: '+ Ritual',
        list: state.rituals,
        create: () => {
          'id': newId('rit'),
          'name': 'Novo Ritual',
          'element': 'Sangue',
          'circle': '1',
          'execution': '',
          'range': '',
          'target': '',
          'duration': '',
          'resistance': '',
          'cost': '1 PE',
          'discente': '',
          'verdadeiro': '',
          'sustainCost': '',
          'components': '',
          'damage': '',
          'desc': '',
          'fav': false,
          'sustain': false,
        },
        card: ritualCard,
      );

  Widget ritualCard(Map<String, dynamic> r) {
    return BloodCard(
      title: '${r['name']}',
      actions: [IconButton(onPressed: () => removeItem(state.rituals, r), icon: const Icon(Icons.delete, color: red))],
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Wrap(children: [
          BadgeText('${r['element']}', kind: BadgeKind.blue),
          BadgeText('${r['circle']}º círculo', kind: BadgeKind.gold),
          BadgeText('${r['cost']}'),
          if (r['sustain'] == true) const BadgeText('Sustentado', kind: BadgeKind.purple),
        ]),
        const SizedBox(height: 8),
        Text('Execução ${r['execution']} • Alcance ${r['range']} • Duração ${r['duration']} • Resistência ${r['resistance']}', style: const TextStyle(color: muted)),
        const SizedBox(height: 8),
        Text('${r['desc']}', style: const TextStyle(color: muted)),
        const SizedBox(height: 8),
        Wrap(spacing: 8, runSpacing: 8, children: [
          AppButton('Conjurar', () => toast('${r['name']} conjurado.'), kind: BadgeKind.blue),
          if ('${r['damage']}'.trim().isNotEmpty) AppButton('Dano', () => roll('${r['damage']}', 'Dano ritual: ${r['name']}', damage: true), kind: BadgeKind.gold),
          AppButton('Sustentar', () {
            setState(() => r['sustain'] = r['sustain'] != true);
            save();
          }, kind: BadgeKind.purple),
          AppButton('Fav', () {
            setState(() => r['fav'] = r['fav'] != true);
            save();
          }, kind: BadgeKind.green),
          AppButton('Editar', () => editGeneric(r, ['name', 'element', 'circle', 'execution', 'range', 'target', 'duration', 'resistance', 'cost', 'discente', 'verdadeiro', 'sustainCost', 'components', 'damage', 'desc']), kind: BadgeKind.gold),
        ]),
      ]),
    );
  }

  Widget powersScreen() => listScreen(
        title: 'Poderes e Habilidades',
        addLabel: '+ Poder',
        list: state.powers,
        create: () => {
          'id': newId('pow'),
          'name': 'Novo Poder',
          'type': 'Classe',
          'prereq': '',
          'cost': '',
          'action': '',
          'uses': '',
          'desc': '',
          'fav': false,
        },
        card: powerCard,
      );

  Widget powerCard(Map<String, dynamic> p) {
    return BloodCard(
      title: '${p['name']}',
      actions: [IconButton(onPressed: () => removeItem(state.powers, p), icon: const Icon(Icons.delete, color: red))],
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Wrap(children: [
          BadgeText('${p['type']}', kind: BadgeKind.blue),
          BadgeText('${p['cost']}', kind: BadgeKind.gold),
          BadgeText('${p['action']}'),
          if (p['fav'] == true) const BadgeText('Fav', kind: BadgeKind.green),
        ]),
        const SizedBox(height: 8),
        Text('Pré-requisito: ${p['prereq']} • Usos: ${p['uses']}', style: const TextStyle(color: muted)),
        const SizedBox(height: 8),
        Text('${p['desc']}', style: const TextStyle(color: muted)),
        const SizedBox(height: 8),
        Wrap(spacing: 8, runSpacing: 8, children: [
          AppButton('Usar', () => toast('${p['name']} usado.'), kind: BadgeKind.blue),
          AppButton('Fav', () {
            setState(() => p['fav'] = p['fav'] != true);
            save();
          }, kind: BadgeKind.green),
          AppButton('Editar', () => editGeneric(p, ['name', 'type', 'prereq', 'cost', 'action', 'uses', 'desc']), kind: BadgeKind.gold),
        ]),
      ]),
    );
  }

  Widget inventoryScreen() => listScreen(
        title: 'Inventário e Equipamentos',
        addLabel: '+ Item',
        list: state.inventory,
        create: () => {'id': newId('item'), 'name': 'Novo Item', 'type': 'Equipamento', 'qty': '1', 'load': '0', 'uses': '0', 'patent': '', 'desc': '', 'fav': false},
        card: itemCard,
      );

  Widget itemCard(Map<String, dynamic> item) {
    return BloodCard(
      title: '${item['name']}',
      actions: [IconButton(onPressed: () => removeItem(state.inventory, item), icon: const Icon(Icons.delete, color: red))],
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Wrap(children: [
          BadgeText('${item['type']}', kind: BadgeKind.blue),
          BadgeText('Qtd ${item['qty']}', kind: BadgeKind.gold),
          BadgeText('Usos ${item['uses']}'),
        ]),
        const SizedBox(height: 8),
        Text('Carga ${item['load']} • Patente ${item['patent']}', style: const TextStyle(color: muted)),
        const SizedBox(height: 8),
        Text('${item['desc']}', style: const TextStyle(color: muted)),
        const SizedBox(height: 8),
        Wrap(spacing: 8, runSpacing: 8, children: [
          AppButton('Usar', () {
            final uses = int.tryParse('${item['uses']}') ?? 0;
            if (uses <= 0) {
              toast('Esse item não tem usos disponíveis.');
              return;
            }
            setState(() => item['uses'] = '${uses - 1}');
            toast('${item['name']} usado.');
            save();
          }, kind: BadgeKind.blue),
          AppButton('Editar', () => editGeneric(item, ['name', 'type', 'qty', 'load', 'uses', 'patent', 'desc']), kind: BadgeKind.gold),
        ]),
      ]),
    );
  }

  Widget defenseScreen() {
    return Column(children: [
      listScreen(
        title: 'Proteções',
        addLabel: '+ Proteção',
        list: state.protections,
        create: () => {'id': newId('prot'), 'name': 'Proteção', 'def': '0', 'rd': '0', 'penalty': '', 'type': '', 'equipped': false, 'desc': ''},
        card: protectionCard,
      ),
      const SizedBox(height: 10),
      listScreen(
        title: 'Buffs de Defesa',
        addLabel: '+ Buff',
        list: state.buffs,
        create: () => {'id': newId('buff'), 'name': 'Buff', 'active': true, 'dur': '3', 'atkBonus': '0', 'atkDice': '0', 'dmgExtra': '', 'def': '0', 'rd': '0', 'dt': '0', 'skill': '', 'skillBonus': '0', 'desc': ''},
        card: buffCard,
      ),
    ]);
  }

  Widget protectionCard(Map<String, dynamic> p) {
    return BloodCard(
      title: '${p['name']}',
      actions: [IconButton(onPressed: () => removeItem(state.protections, p), icon: const Icon(Icons.delete, color: red))],
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Wrap(children: [
          BadgeText('Def +${p['def']}', kind: BadgeKind.blue),
          BadgeText('RD +${p['rd']}', kind: BadgeKind.gold),
          if (p['equipped'] == true) const BadgeText('Equipada', kind: BadgeKind.green),
        ]),
        const SizedBox(height: 8),
        Text('Tipo ${p['type']} • Penalidade ${p['penalty']}\n${p['desc']}', style: const TextStyle(color: muted)),
        const SizedBox(height: 8),
        Wrap(spacing: 8, runSpacing: 8, children: [
          AppButton(p['equipped'] == true ? 'Desequipar' : 'Equipar', () {
            setState(() => p['equipped'] = p['equipped'] != true);
            save();
          }, kind: BadgeKind.green),
          AppButton('Editar', () => editGeneric(p, ['name', 'def', 'rd', 'penalty', 'type', 'desc']), kind: BadgeKind.gold),
        ]),
      ]),
    );
  }

  Widget buffCard(Map<String, dynamic> b) {
    return BloodCard(
      title: '${b['name']}',
      actions: [IconButton(onPressed: () => removeItem(state.buffs, b), icon: const Icon(Icons.delete, color: red))],
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Wrap(children: [
          BadgeText(b['active'] == true ? 'Ativo' : 'Off', kind: b['active'] == true ? BadgeKind.green : BadgeKind.red),
          BadgeText('Def +${b['def']}', kind: BadgeKind.blue),
          BadgeText('RD +${b['rd']}', kind: BadgeKind.gold),
        ]),
        const SizedBox(height: 8),
        Text('Atk +${b['atkBonus']} • Dados +${b['atkDice']} • Dano extra ${b['dmgExtra']} • Duração ${b['dur']}', style: const TextStyle(color: muted)),
        const SizedBox(height: 8),
        Wrap(spacing: 8, runSpacing: 8, children: [
          AppButton(b['active'] == true ? 'Desativar' : 'Ativar', () {
            setState(() => b['active'] = b['active'] != true);
            save();
          }, kind: BadgeKind.green),
          AppButton('Editar', () => editGeneric(b, ['name', 'dur', 'atkBonus', 'atkDice', 'dmgExtra', 'def', 'rd', 'dt', 'skill', 'skillBonus', 'desc']), kind: BadgeKind.gold),
        ]),
      ]),
    );
  }

  Widget conditionsScreen() => listScreen(
        title: 'Condições Oficiais e Personalizadas',
        addLabel: '+ Condição',
        extraActions: [
          AppButton('Biblioteca', addConditionPreset, kind: BadgeKind.blue),
        ],
        list: state.conditions,
        create: () => {'id': newId('cond'), 'name': 'Sangrando', 'dur': '3', 'effect': 'Perde PV no início do turno.', 'def': '0', 'skill': '', 'skillMod': '0'},
        card: conditionCard,
      );

  void addConditionPreset() async {
    final presets = ['Morrendo', 'Enlouquecendo', 'Perturbado', 'Sangrando', 'Vulnerável', 'Desprevenido', 'Fraco', 'Debilitado', 'Cego', 'Surdo', 'Caído', 'Agarrado', 'Imóvel', 'Pasmo', 'Atordoado'];
    final choice = await chooseDialog('Adicionar condição', presets);
    if (choice == null) return;
    final effects = {
      'Morrendo': 'Está à beira da morte. Controle turnos e estabilização.',
      'Enlouquecendo': 'Perda crítica de controle mental. Controle turnos.',
      'Perturbado': 'Abalado mentalmente.',
      'Sangrando': 'Perde PV no início do turno.',
      'Vulnerável': 'Sofre penalidade defensiva.',
      'Desprevenido': 'Defesa reduzida contra ataques.',
      'Fraco': 'Penalidade em testes físicos.',
      'Debilitado': 'Penalidade severa em testes.',
      'Cego': 'Não enxerga.',
      'Surdo': 'Não escuta.',
      'Caído': 'Está no chão.',
      'Agarrado': 'Movimento limitado.',
      'Imóvel': 'Não pode se mover.',
      'Pasmo': 'Ação limitada.',
      'Atordoado': 'Ação severamente limitada.',
    };
    setState(() => state.conditions.add({'id': newId('cond'), 'name': choice, 'dur': '3', 'effect': effects[choice] ?? '', 'def': '0', 'skill': '', 'skillMod': '0'}));
    save();
  }

  Widget conditionCard(Map<String, dynamic> c) {
    return BloodCard(
      title: '${c['name']}',
      actions: [IconButton(onPressed: () => removeItem(state.conditions, c), icon: const Icon(Icons.delete, color: red))],
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        BadgeText('Duração ${c['dur']}', kind: BadgeKind.gold),
        const SizedBox(height: 8),
        Text('${c['effect']}', style: const TextStyle(color: muted)),
        const SizedBox(height: 8),
        Wrap(spacing: 8, runSpacing: 8, children: [
          AppButton('-1 rodada', () {
            final dur = int.tryParse('${c['dur']}') ?? 0;
            setState(() {
              c['dur'] = '${max(0, dur - 1)}';
              if (c['dur'] == '0') state.conditions.remove(c);
            });
            save();
          }),
          AppButton('Editar', () => editGeneric(c, ['name', 'dur', 'effect', 'def', 'skill', 'skillMod']), kind: BadgeKind.gold),
        ]),
      ]),
    );
  }

  Widget injuriesMarksScreen() {
    return Column(children: [
      listScreen(
        title: 'Ferimentos e Traumas',
        addLabel: '+ Ferimento',
        list: state.injuries,
        create: () => {'id': newId('inj'), 'name': 'Ferimento', 'type': 'Físico', 'penalty': '', 'treatment': '', 'session': '', 'desc': ''},
        card: (i) => simpleRecordCard(i, state.injuries, ['name', 'type', 'penalty', 'treatment', 'session', 'desc']),
      ),
      const SizedBox(height: 10),
      listScreen(
        title: 'Marcas da Sobrevivência',
        addLabel: '+ Marca',
        list: state.marks,
        create: () => {'id': newId('mark'), 'name': 'Marca', 'level': '', 'type': '', 'benefit': '', 'penalty': '', 'trigger': '', 'desc': ''},
        card: (m) => simpleRecordCard(m, state.marks, ['name', 'level', 'type', 'benefit', 'penalty', 'trigger', 'desc']),
      ),
      const SizedBox(height: 10),
      listScreen(
        title: 'Alterações de NEX',
        addLabel: '+ Alteração',
        list: state.nexChanges,
        create: () => {'id': newId('nex'), 'nex': '50', 'visual': '', 'mechanic': '', 'bonus': '', 'penalty': '', 'element': '', 'active': true},
        card: (m) => simpleRecordCard(m, state.nexChanges, ['nex', 'visual', 'mechanic', 'bonus', 'penalty', 'element']),
      ),
    ]);
  }

  Widget investigationScreen() {
    return ResponsiveGrid(children: [
      BloodCard(
        title: 'Missão Atual',
        child: Column(children: [
          field('Nome da missão', state.mission['name'], (v) => state.mission['name'] = v),
          field('Objetivo principal', state.mission['objective'], (v) => state.mission['objective'] = v, lines: 3),
          field('Objetivos secundários', state.mission['secondary'], (v) => state.mission['secondary'] = v, lines: 3),
          field('Local', state.mission['location'], (v) => state.mission['location'] = v),
          field('Ameaça principal', state.mission['threat'], (v) => state.mission['threat'] = v),
          field('Consequências', state.mission['consequences'], (v) => state.mission['consequences'] = v, lines: 3),
        ]),
      ),
      BloodCard(
        title: 'Investigação',
        child: Column(children: [
          field('Pistas', state.mission['clues'], (v) => state.mission['clues'] = v, lines: 5),
          field('Documentos', state.mission['documents'], (v) => state.mission['documents'] = v, lines: 4),
          field('Símbolos', state.mission['symbols'], (v) => state.mission['symbols'] = v, lines: 3),
          field('Suspeitos', state.mission['suspects'], (v) => state.mission['suspects'] = v, lines: 3),
          field('Perguntas sem resposta', state.mission['questions'], (v) => state.mission['questions'] = v, lines: 4),
          field('Teorias do grupo', state.mission['theories'], (v) => state.mission['theories'] = v, lines: 4),
          field('Linha do tempo', state.mission['timeline'], (v) => state.mission['timeline'] = v, lines: 5),
        ]),
      ),
      BloodCard(
        title: 'NPCs e Relações',
        child: Column(children: [
          field('NPCs importantes', state.mission['npcs'], (v) => state.mission['npcs'] = v, lines: 5),
          field('Relações, promessas e dívidas', state.mission['relations'], (v) => state.mission['relations'] = v, lines: 5),
        ]),
      ),
    ]);
  }

  Widget restScreen() {
    return ResponsiveGrid(children: [
      BloodCard(
        title: 'Descanso / Interlúdio',
        child: Column(children: [
          field('Último descanso', state.rest['lastRest'], (v) => state.rest['lastRest'] = v),
          field('Ações de interlúdio', state.rest['interludeActions'], (v) => state.rest['interludeActions'] = v, lines: 5),
          field('Tratamento de ferimentos', state.rest['treatment'], (v) => state.rest['treatment'] = v, lines: 3),
          field('Fabricação / manutenção', state.rest['crafting'], (v) => state.rest['crafting'] = v, lines: 3),
          field('Estudo de ritual', state.rest['study'], (v) => state.rest['study'] = v, lines: 3),
          field('Treino', state.rest['training'], (v) => state.rest['training'] = v, lines: 3),
          const SizedBox(height: 8),
          Wrap(spacing: 8, runSpacing: 8, children: [
            AppButton('Recuperar PV', () => setState(() => state.stats['pv'] = state.stats['pvMax']), kind: BadgeKind.green),
            AppButton('Recuperar PE', () => setState(() => state.stats['pe'] = state.stats['peMax']), kind: BadgeKind.blue),
            AppButton('Recuperar SAN', () => setState(() => state.stats['san'] = state.stats['sanMax']), kind: BadgeKind.gold),
          ]),
        ]),
      )
    ]);
  }

  Widget evolutionScreen() => listScreen(
        title: 'Evolução',
        addLabel: '+ Avanço',
        list: state.evolution,
        create: () => {'id': newId('evo'), 'from': '', 'to': '', 'level': '', 'power': '', 'attr': '', 'skills': '', 'ritual': '', 'nexChange': '', 'notes': ''},
        card: (e) => simpleRecordCard(e, state.evolution, ['from', 'to', 'level', 'power', 'attr', 'skills', 'ritual', 'nexChange', 'notes']),
      );

  Widget prepareCombosScreen() {
    return Column(children: [
      BloodCard(
        title: 'Preparar Ação 2.0',
        child: Column(children: [
          field('Título', state.prepare['title'], (v) => state.prepare['title'] = v),
          field('Ação principal', state.prepare['mainAction'], (v) => state.prepare['mainAction'] = v),
          field('Ação de movimento', state.prepare['moveAction'], (v) => state.prepare['moveAction'] = v),
          field('Ação livre', state.prepare['freeAction'], (v) => state.prepare['freeAction'] = v),
          field('Reação', state.prepare['reaction'], (v) => state.prepare['reaction'] = v),
          field('Vou usar', state.prepare['use'], (v) => state.prepare['use'] = v),
          field('Alvo', state.prepare['target'], (v) => state.prepare['target'] = v),
          intField('PE previsto', state.prepare['pe'], (v) => state.prepare['pe'] = v),
          intField('PD previsto', state.prepare['pd'], (v) => state.prepare['pd'] = v),
          intField('PV previsto', state.prepare['pv'], (v) => state.prepare['pv'] = v),
          intField('SAN prevista', state.prepare['san'], (v) => state.prepare['san'] = v),
          field('Testes separados por ;', state.prepare['tests'], (v) => state.prepare['tests'] = v),
          field('Dano previsto', state.prepare['damage'], (v) => state.prepare['damage'] = v),
          field('Condição que pretende aplicar', state.prepare['condition'], (v) => state.prepare['condition'] = v),
          field('Plano se falhar', state.prepare['failPlan'], (v) => state.prepare['failPlan'] = v, lines: 3),
          field('Observações', state.prepare['notes'], (v) => state.prepare['notes'] = v, lines: 4),
          const SizedBox(height: 8),
          Wrap(spacing: 8, runSpacing: 8, children: [
            AppButton('Executar tudo', executePrepared, kind: BadgeKind.green),
            AppButton('Copiar', copyPrepared, kind: BadgeKind.blue),
          ])
        ]),
      ),
      const SizedBox(height: 10),
      listScreen(
        title: 'Combos',
        addLabel: '+ Combo',
        list: state.combos,
        create: () => {'id': newId('combo'), 'name': 'Novo Combo', 'requirements': '', 'buffs': '', 'actions': '', 'cost': '', 'tests': '', 'damage': '', 'risk': '', 'notes': ''},
        card: (c) => simpleRecordCard(c, state.combos, ['name', 'requirements', 'buffs', 'actions', 'cost', 'tests', 'damage', 'risk', 'notes']),
      ),
    ]);
  }

  void executePrepared() {
    final pe = toInt(state.prepare['pe']);
    final pd = toInt(state.prepare['pd']);
    setState(() {
      state.stats['pe'] = max(0, toInt(state.stats['pe']) - pe);
      state.stats['pd'] = max(0, toInt(state.stats['pd']) - pd);
      state.turn['peSpent'] = toInt(state.turn['peSpent']) + pe;
      state.turn['pdSpent'] = toInt(state.turn['pdSpent']) + pd;
      log('Ação preparada', '${state.prepare['title']} executada.');
    });
    for (final t in '${state.prepare['tests']}'.split(';').map((e) => e.trim()).where((e) => e.isNotEmpty)) {
      roll(t, 'Teste preparado');
    }
    final dmg = '${state.prepare['damage']}'.trim();
    if (dmg.isNotEmpty) roll(dmg, 'Dano preparado', damage: true);
    save();
  }

  void copyPrepared() {
    final p = state.prepare;
    final txt = 'Plano: ${p['title']}\nAção principal: ${p['mainAction']}\nMovimento: ${p['moveAction']}\nLivre: ${p['freeAction']}\nReação: ${p['reaction']}\nUsar: ${p['use']}\nAlvo: ${p['target']}\nCusto: PE ${p['pe']} | PD ${p['pd']} | PV ${p['pv']} | SAN ${p['san']}\nTestes: ${p['tests']}\nDano: ${p['damage']}\nFalha: ${p['failPlan']}\nNotas: ${p['notes']}';
    Clipboard.setData(ClipboardData(text: txt));
    toast('Ação preparada copiada.');
  }

  Widget validatorScreen() {
    final issues = validatorIssues();
    return ResponsiveGrid(children: [
      BloodCard(
        title: 'Validador Avançado',
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          if (issues.isEmpty) const BadgeText('Nenhum problema encontrado', kind: BadgeKind.green),
          for (final issue in issues)
            Padding(
              padding: const EdgeInsets.only(bottom: 8),
              child: Text('• $issue', style: const TextStyle(color: muted)),
            ),
        ]),
      ),
      BloodCard(
        title: 'Resumo para o Mestre',
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          AppButton('Copiar resumo', copyMasterSummary, kind: BadgeKind.blue),
          const SizedBox(height: 10),
          Text(masterSummary(), style: const TextStyle(color: muted)),
        ]),
      ),
    ]);
  }

  List<String> validatorIssues() {
    final issues = <String>[];
    for (final k in ['pv', 'pe', 'pd', 'san']) {
      if (toInt(state.stats[k]) > toInt(state.stats['${k}Max'])) issues.add('${k.toUpperCase()} atual maior que o máximo.');
      if (toInt(state.stats[k]) < 0) issues.add('${k.toUpperCase()} negativo.');
    }
    if (state.optional['nexNivel'] == true && toInt(state.p['level']) != peLimit) issues.add('Nível incompatível com NEX & Nível.');
    if (state.optional['limiteCombinado'] == true) {
      if (toInt(state.turn['peSpent']) + toInt(state.turn['pdSpent']) > peLimit) issues.add('PE + PD passaram do limite por turno.');
    } else {
      if (toInt(state.turn['peSpent']) > peLimit) issues.add('PE passou do limite por turno.');
      if (toInt(state.turn['pdSpent']) > peLimit) issues.add('PD passou do limite por turno.');
    }
    for (final w in state.weapons) {
      if ('${w['damage']}'.trim().isEmpty) issues.add('Arma "${w['name']}" sem dano.');
      if (toInt(w['ammoMax']) > 0 && toInt(w['ammo']) > toInt(w['ammoMax'])) issues.add('Munição de "${w['name']}" acima do máximo.');
    }
    for (final r in state.rituals) {
      if ('${r['cost']}'.trim().isEmpty) issues.add('Ritual "${r['name']}" sem custo.');
    }
    for (final p in state.powers) {
      if ('${p['desc']}'.trim().isEmpty) issues.add('Poder "${p['name']}" sem descrição.');
    }
    for (final c in state.conditions) {
      if (toInt(c['dur']) == 0) issues.add('Condição "${c['name']}" vencida ainda presente.');
    }
    if (toInt(state.stats['load']) > toInt(state.stats['loadMax'])) issues.add('Carga acima do limite.');
    return issues;
  }

  void copyMasterSummary() {
    Clipboard.setData(ClipboardData(text: masterSummary()));
    toast('Resumo copiado.');
  }

  String masterSummary() {
    final s = derivedStats();
    final conds = state.conditions.map((c) => c['name']).join(', ');
    final sustained = state.rituals.where((r) => r['sustain'] == true).map((r) => r['name']).join(', ');
    final lowAmmo = state.weapons.where((w) => toInt(w['ammoMax']) > 0 && toInt(w['ammo']) <= 2).map((w) => '${w['name']} ${w['ammo']}/${w['ammoMax']}').join(', ');
    final injuries = state.injuries.map((i) => i['name']).join(', ');
    return '${state.p['name']}\nClasse/Trilha: ${state.p['class']} / ${state.p['trail']}\nNEX/Nível: ${state.p['nex']}% / ${state.p['level']}\nPV ${s['pv']}/${s['pvMax']} | PE ${s['pe']}/${s['peMax']} | PD ${s['pd']}/${s['pdMax']} | SAN ${s['san']}/${s['sanMax']}\nDefesa ${s['def']} | RD ${s['rd']} | DT ${s['dt']}\nCondições: ${conds.isEmpty ? 'nenhuma' : conds}\nRituais sustentados: ${sustained.isEmpty ? 'nenhum' : sustained}\nMunição baixa: ${lowAmmo.isEmpty ? 'nenhuma' : lowAmmo}\nFerimentos: ${injuries.isEmpty ? 'nenhum' : injuries}\nAção preparada: ${state.prepare['title']} — ${state.prepare['use']}';
  }

  Widget backupsScreen() {
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Wrap(spacing: 8, runSpacing: 8, children: [
        AppButton('Backup antes da sessão', () => createBackup('antes da sessão'), kind: BadgeKind.gold),
        AppButton('Backup antes do boss', () => createBackup('antes do boss'), kind: BadgeKind.gold),
        AppButton('Backup após descanso', () => createBackup('após descanso'), kind: BadgeKind.green),
      ]),
      const SizedBox(height: 10),
      ResponsiveGrid(children: state.backups.map(backupCard).toList()),
    ]);
  }

  void createBackup(String label) {
    setState(() {
      state.backups.add({'id': newId('backup'), 'label': label, 'time': DateTime.now().toString().substring(0, 19), 'data': state.exportJson()});
      if (state.backups.length > 20) state.backups.removeAt(0);
    });
    save();
    toast('Backup criado.');
  }

  Widget backupCard(Map<String, dynamic> b) {
    return BloodCard(
      title: '${b['label']}',
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text('${b['time']}', style: const TextStyle(color: muted)),
        const SizedBox(height: 8),
        Wrap(spacing: 8, runSpacing: 8, children: [
          AppButton('Restaurar', () {
            setState(() {
              final keepBackups = state.backups;
              state = AppState.fromJson(jsonDecode('${b['data']}') as Map<String, dynamic>);
              state.backups = keepBackups;
            });
            save();
          }, kind: BadgeKind.green),
          AppButton('Excluir', () => removeItem(state.backups, b), kind: BadgeKind.red),
        ]),
      ]),
    );
  }

  Widget importExportScreen() {
    return ResponsiveGrid(children: [
      BloodCard(
        title: 'Importar JSON',
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('Cole uma ficha JSON exportada por esta central ou por outro formato parecido. O importador tenta reconhecer nome, classe, trilha, origem, NEX, atributos, perícias, armas, rituais, poderes e itens.', style: TextStyle(color: muted)),
          const SizedBox(height: 10),
          Wrap(spacing: 8, runSpacing: 8, children: [
            AppButton('Colar JSON', importFromDialog, kind: BadgeKind.blue),
            AppButton('Importar da área de transferência', importFromClipboard, kind: BadgeKind.gold),
          ]),
        ]),
      ),
      BloodCard(
        title: 'Exportar JSON',
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          AppButton('Copiar JSON', () {
            Clipboard.setData(ClipboardData(text: state.exportJson()));
            toast('JSON copiado.');
          }, kind: BadgeKind.blue),
          const SizedBox(height: 8),
          AppButton('Copiar resumo do mestre', copyMasterSummary, kind: BadgeKind.gold),
        ]),
      ),
    ]);
  }

  Future<void> importFromClipboard() async {
    final data = await Clipboard.getData('text/plain');
    final text = data?.text ?? '';
    if (text.trim().isEmpty) {
      toast('Área de transferência vazia.');
      return;
    }
    importJsonText(text);
  }

  Future<void> importFromDialog() async {
    final ctrl = TextEditingController();
    final ok = await showDialog<bool>(
          context: context,
          builder: (_) => AlertDialog(
            backgroundColor: const Color(0xFF100707),
            title: const Text('Importar JSON'),
            content: SizedBox(
              width: min(MediaQuery.of(context).size.width - 40, 620.0),
              child: TextField(
                controller: ctrl,
                minLines: 10,
                maxLines: 18,
                decoration: bloodInput('Cole o JSON aqui'),
              ),
            ),
            actions: [
              TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Cancelar')),
              FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Importar')),
            ],
          ),
        ) ??
        false;
    if (ok) importJsonText(ctrl.text);
  }

  void importJsonText(String textValue) {
    try {
      final parsed = jsonDecode(textValue);
      if (parsed is! Map<String, dynamic>) throw const FormatException('O JSON precisa ser um objeto.');
      setState(() => state = AppState.smartImport(parsed));
      save();
      toast('Ficha importada com sucesso.');
    } catch (e) {
      toast('Erro ao importar JSON: $e');
    }
  }

  Widget configScreen() {
    return ResponsiveGrid(children: [
      BloodCard(
        title: 'Regras Opcionais',
        child: Column(children: [
          for (final entry in state.optional.entries)
            SwitchListTile(
              title: Text(optionalLabels[entry.key] ?? entry.key),
              subtitle: Text(optionalDescriptions[entry.key] ?? '', style: const TextStyle(color: muted)),
              value: entry.value,
              activeColor: red,
              onChanged: (v) {
                setState(() => state.optional[entry.key] = v);
                save();
              },
            ),
        ]),
      ),
      BloodCard(
        title: 'Sistema',
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          AppButton('Salvar agora', () => save(notify: true), kind: BadgeKind.green),
          const SizedBox(height: 8),
          AppButton('Limpar ficha', () {
            setState(() => state = AppState());
            save();
          }, kind: BadgeKind.red),
        ]),
      ),
    ]);
  }

  Widget listScreen({
    required String title,
    required String addLabel,
    required List<Map<String, dynamic>> list,
    required Map<String, dynamic> Function() create,
    required Widget Function(Map<String, dynamic>) card,
    List<Widget> extraActions = const [],
  }) {
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Wrap(spacing: 8, runSpacing: 8, children: [
        AppButton(addLabel, () {
          final item = create();
          setState(() => list.add(item));
          save();
        }, kind: BadgeKind.green),
        ...extraActions,
      ]),
      const SizedBox(height: 10),
      if (list.isEmpty) const EmptyText('Nenhum registro.'),
      ResponsiveGrid(children: list.map(card).toList()),
    ]);
  }

  Widget simpleRecordCard(Map<String, dynamic> item, List<Map<String, dynamic>> list, List<String> keys) {
    return BloodCard(
      title: '${item[keys.first] ?? 'Registro'}',
      actions: [IconButton(onPressed: () => removeItem(list, item), icon: const Icon(Icons.delete, color: red))],
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        for (final k in keys.skip(1).take(4))
          if ('${item[k] ?? ''}'.trim().isNotEmpty)
            Text('$k: ${item[k]}', style: const TextStyle(color: muted)),
        const SizedBox(height: 8),
        AppButton('Editar', () => editGeneric(item, keys), kind: BadgeKind.gold),
      ]),
    );
  }

  Future<void> editGeneric(Map<String, dynamic> item, List<String> keys) async {
    final values = {for (final k in keys) k: '${item[k] ?? ''}'};
    final result = await editMapDialog('Editar', values);
    if (result == null) return;
    setState(() {
      for (final k in keys) {
        final old = item[k];
        if (old is int) {
          item[k] = int.tryParse(result[k] ?? '') ?? 0;
        } else if (old is bool) {
          item[k] = (result[k] ?? '').toLowerCase() == 'true';
        } else {
          item[k] = result[k] ?? '';
        }
      }
    });
    save();
  }

  Future<Map<String, String>?> editMapDialog(String title, Map<String, String> values) async {
    final ctrls = {for (final e in values.entries) e.key: TextEditingController(text: e.value)};
    final ok = await showDialog<bool>(
          context: context,
          builder: (_) => AlertDialog(
            backgroundColor: const Color(0xFF100707),
            title: Text(title),
            content: SizedBox(
              width: min(MediaQuery.of(context).size.width - 40, 560.0),
              child: SingleChildScrollView(
                child: Column(
                  children: [
                    for (final e in ctrls.entries)
                      Padding(
                        padding: const EdgeInsets.only(bottom: 8),
                        child: TextField(controller: e.value, decoration: bloodInput(e.key)),
                      ),
                  ],
                ),
              ),
            ),
            actions: [
              TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Cancelar')),
              FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Salvar')),
            ],
          ),
        ) ??
        false;
    if (!ok) return null;
    return {for (final e in ctrls.entries) e.key: e.value.text};
  }

  Future<String?> chooseDialog(String title, List<String> values) async {
    return showDialog<String>(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: const Color(0xFF100707),
        title: Text(title),
        content: SizedBox(
          width: min(MediaQuery.of(context).size.width - 40, 360.0),
          child: SingleChildScrollView(
            child: Column(
              children: [
                for (final v in values)
                  ListTile(
                    title: Text(v),
                    onTap: () => Navigator.pop(context, v),
                  )
              ],
            ),
          ),
        ),
      ),
    );
  }

  void removeItem(List<Map<String, dynamic>> list, Map<String, dynamic> item) {
    setState(() => list.remove(item));
    save();
  }

  Widget field(String label, dynamic value, void Function(String) onChanged, {int lines = 1}) {
    final ctrl = TextEditingController(text: '$value');
    ctrl.selection = TextSelection.collapsed(offset: ctrl.text.length);
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: TextField(
        controller: ctrl,
        minLines: lines,
        maxLines: lines,
        decoration: bloodInput(label),
        onChanged: (v) {
          onChanged(v);
          save();
        },
      ),
    );
  }

  Widget intField(String label, dynamic value, void Function(int) onChanged) {
    return field(label, value, (v) => onChanged(int.tryParse(v) ?? 0));
  }

  void nextRound() {
    setState(() {
      state.turn['round'] = toInt(state.turn['round']) + 1;
      state.turn['peSpent'] = 0;
      state.turn['pdSpent'] = 0;
      for (final c in List<Map<String, dynamic>>.from(state.conditions)) {
        final dur = toInt(c['dur']);
        if (dur > 0) {
          c['dur'] = '${dur - 1}';
          if (c['dur'] == '0') state.conditions.remove(c);
        }
      }
      log('Rodada', 'Nova rodada iniciada.');
    });
    save();
  }
}
