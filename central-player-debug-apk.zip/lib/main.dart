
import 'dart:convert';
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

const saveKey = 'central_player_flutter_v4_2';
final rng = Random();

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const CentralPlayerApp());
}

class CentralPlayerApp extends StatelessWidget {
  const CentralPlayerApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Central do Player',
      debugShowCheckedModeBanner: false,
      theme: ThemeData.dark(useMaterial3: true).copyWith(
        scaffoldBackgroundColor: const Color(0xFF050202),
        colorScheme: const ColorScheme.dark(
          primary: Color(0xFFE43642),
          secondary: Color(0xFFD8A549),
          surface: Color(0xFF120706),
        ),
        snackBarTheme: const SnackBarThemeData(
          behavior: SnackBarBehavior.floating,
          backgroundColor: Color(0xFF160707),
          contentTextStyle: TextStyle(
            color: Color(0xFFFFF3EA),
            fontWeight: FontWeight.w800,
          ),
        ),
      ),
      home: const PlayerHome(),
    );
  }
}

class AppState {
  Map<String, dynamic> p = {
    'name': 'Agente Sem Nome',
    'class': 'Sobrevivente',
    'trail': '—',
    'origin': '—',
    'nex': 5,
    'level': 1,
    'theme': 'sangue',
  };

  Map<String, dynamic> stats = {
    'pv': 20,
    'pvMax': 20,
    'pe': 4,
    'peMax': 4,
    'pd': 0,
    'pdMax': 0,
    'san': 20,
    'sanMax': 20,
    'def': 10,
    'rd': 0,
    'dt': 10,
    'move': 9,
    'peTurn': 1,
  };

  Map<String, int> attrs = {
    'Força': 1,
    'Agilidade': 1,
    'Intelecto': 1,
    'Presença': 1,
    'Vigor': 1,
  };

  Map<String, Map<String, dynamic>> skills = {
    for (final s in skillNames)
      s: {
        'attr': defaultSkillAttr(s),
        'train': 0,
        'bonus': 0,
        'temp': 0,
        'extraDice': 0,
      }
  };

  List<Map<String, dynamic>> attacks = [
    {
      'id': 'atk0',
      'name': 'Ataque Improvisado',
      'test': '1d20+0',
      'damage': '1d6',
      'crit': '20/x2',
      'type': 'Impacto',
      'ammo': 0,
      'ammoMax': 0,
      'fav': true,
    }
  ];

  List<Map<String, dynamic>> rituals = [];
  List<Map<String, dynamic>> powers = [];
  List<Map<String, dynamic>> items = [];
  List<Map<String, dynamic>> conditions = [];
  List<Map<String, dynamic>> logs = [];
  Map<String, bool> optional = {
    'nexNivel': false,
    'semSanidade': false,
    'municao': true,
    'combateNarrativo': false,
    'conjuracaoComplexa': false,
    'alteracoesNex': false,
  };

  Map<String, dynamic> prepare = {
    'title': '',
    'use': '',
    'target': '',
    'tests': '',
    'damage': '',
    'pe': 0,
    'pd': 0,
    'notes': '',
  };

  Map<String, dynamic> toJson() => {
        'p': p,
        'stats': stats,
        'attrs': attrs,
        'skills': skills,
        'attacks': attacks,
        'rituals': rituals,
        'powers': powers,
        'items': items,
        'conditions': conditions,
        'logs': logs,
        'optional': optional,
        'prepare': prepare,
      };

  static AppState fromJson(Map<String, dynamic> data) {
    final s = AppState();
    s.p = {...s.p, ...Map<String, dynamic>.from(data['p'] ?? {})};
    s.stats = {...s.stats, ...Map<String, dynamic>.from(data['stats'] ?? {})};
    s.attrs = {
      ...s.attrs,
      ...Map<String, dynamic>.from(data['attrs'] ?? {})
          .map((k, v) => MapEntry(k, toInt(v)))
    };
    final loadedSkills = Map<String, dynamic>.from(data['skills'] ?? {});
    for (final name in skillNames) {
      if (loadedSkills[name] is Map) {
        s.skills[name] = {
          ...s.skills[name]!,
          ...Map<String, dynamic>.from(loadedSkills[name] as Map),
        };
      }
    }
    s.attacks = listOfMaps(data['attacks'], s.attacks);
    s.rituals = listOfMaps(data['rituals'], []);
    s.powers = listOfMaps(data['powers'], []);
    s.items = listOfMaps(data['items'], []);
    s.conditions = listOfMaps(data['conditions'], []);
    s.logs = listOfMaps(data['logs'], []);
    s.optional = {
      ...s.optional,
      ...Map<String, dynamic>.from(data['optional'] ?? {})
          .map((k, v) => MapEntry(k, v == true)),
    };
    s.prepare = {
      ...s.prepare,
      ...Map<String, dynamic>.from(data['prepare'] ?? {}),
    };
    return s;
  }
}

List<Map<String, dynamic>> listOfMaps(dynamic value, List<Map<String, dynamic>> fallback) {
  if (value is! List) return List<Map<String, dynamic>>.from(fallback);
  return value.whereType<Map>().map((e) => Map<String, dynamic>.from(e)).toList();
}

int toInt(dynamic v) => v is int ? v : int.tryParse('$v') ?? 0;

String initials(String value) {
  final clean = value.trim();
  if (clean.isEmpty) return 'A';
  final parts = clean.split(RegExp(r'\s+')).where((p) => p.isNotEmpty).toList();
  final letters = parts.map((p) => p.characters.first).join();
  if (letters.isEmpty) return 'A';
  return letters.length >= 2 ? letters.substring(0, 2).toUpperCase() : letters.toUpperCase();
}


const skillNames = [
  'Acrobacia',
  'Adestramento',
  'Artes',
  'Atletismo',
  'Atualidades',
  'Ciências',
  'Crime',
  'Diplomacia',
  'Enganação',
  'Fortitude',
  'Furtividade',
  'Iniciativa',
  'Intimidação',
  'Intuição',
  'Investigação',
  'Luta',
  'Medicina',
  'Ocultismo',
  'Percepção',
  'Pilotagem',
  'Pontaria',
  'Profissão',
  'Reflexos',
  'Religião',
  'Sobrevivência',
  'Tática',
  'Tecnologia',
  'Vontade',
];

const attrs = ['Força', 'Agilidade', 'Intelecto', 'Presença', 'Vigor'];

String defaultSkillAttr(String s) {
  const agi = ['Acrobacia', 'Crime', 'Furtividade', 'Iniciativa', 'Pilotagem', 'Pontaria', 'Reflexos'];
  const forca = ['Atletismo', 'Luta'];
  const vigor = ['Fortitude'];
  const pres = ['Adestramento', 'Artes', 'Diplomacia', 'Enganação', 'Intimidação', 'Intuição', 'Percepção', 'Vontade'];
  if (agi.contains(s)) return 'Agilidade';
  if (forca.contains(s)) return 'Força';
  if (vigor.contains(s)) return 'Vigor';
  if (pres.contains(s)) return 'Presença';
  return 'Intelecto';
}

class RollResult {
  RollResult({
    required this.total,
    required this.detail,
    required this.rolls,
    required this.mode,
  });

  final int total;
  final String detail;
  final List<int> rolls;
  final String mode;
}

class DiceService {
  static RollResult rollTest(String expression) {
    return _roll(expression, ordemTest: true);
  }

  static RollResult rollDamage(String expression) {
    return _roll(expression, ordemTest: false);
  }

  static RollResult _roll(String expression, {required bool ordemTest}) {
    final clean = expression.toLowerCase().replaceAll(' ', '').replaceAll('−', '-');
    final parts = RegExp(r'[+-]?[^+-]+').allMatches(clean).map((m) => m.group(0)!).toList();
    var total = 0;
    final details = <String>[];
    final allRolls = <int>[];

    for (var part in parts) {
      var sign = 1;
      if (part.startsWith('+')) part = part.substring(1);
      if (part.startsWith('-')) {
        sign = -1;
        part = part.substring(1);
      }

      final dm = RegExp(r'^(\d*)d(\d+)$').firstMatch(part);
      if (dm != null) {
        final qty = int.tryParse(dm.group(1)!.isEmpty ? '1' : dm.group(1)!) ?? 1;
        final faces = int.tryParse(dm.group(2)!) ?? 20;
        final rolls = List<int>.generate(qty, (_) => rng.nextInt(faces) + 1);
        allRolls.addAll(rolls);
        final used = ordemTest && faces == 20 ? rolls.reduce(max) : rolls.fold<int>(0, (a, b) => a + b);
        total += sign * used;
        final chosen = ordemTest && faces == 20 ? ' maior ${rolls.reduce(max)}' : '';
        details.add('${sign < 0 ? '-' : ''}${qty}d$faces[${rolls.join(', ')}]$chosen');
      } else {
        final value = int.tryParse(part) ?? 0;
        total += sign * value;
        details.add('${sign < 0 ? '-' : ''}$value');
      }
    }

    return RollResult(
      total: total,
      detail: details.join(' + ').replaceAll('+ -', '- '),
      rolls: allRolls,
      mode: ordemTest ? 'Teste OP: usa o maior d20' : 'Dano: soma todos os dados',
    );
  }
}

class PlayerHome extends StatefulWidget {
  const PlayerHome({super.key});

  @override
  State<PlayerHome> createState() => _PlayerHomeState();
}

class _PlayerHomeState extends State<PlayerHome> {
  AppState state = AppState();
  int tab = 0;

  final tabs = const [
    'Painel',
    'Ficha',
    'Perícias',
    'Ataques',
    'Rituais',
    'Poderes',
    'Inventário',
    'Condições',
    'Preparar',
    'Notas',
    'Config',
  ];

  @override
  void initState() {
    super.initState();
    load();
  }

  Future<void> save({bool notify = false}) async {
    final sp = await SharedPreferences.getInstance();
    await sp.setString(saveKey, jsonEncode(state.toJson()));
    if (notify) toast('Ficha salva.');
  }

  Future<void> load() async {
    final sp = await SharedPreferences.getInstance();
    final raw = sp.getString(saveKey);
    if (raw != null) {
      try {
        setState(() => state = AppState.fromJson(jsonDecode(raw)));
      } catch (_) {
        toast('Não consegui carregar o save antigo.');
      }
    }
  }

  void log(String title, String text) {
    state.logs.add({
      'title': title,
      'text': text,
      'time': DateTime.now().toString().substring(0, 19),
    });
    if (state.logs.length > 100) state.logs.removeAt(0);
  }

  void toast(String msg) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).clearSnackBars();
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg)));
  }

  void roll(String exp, String title, {bool damage = false}) {
    final r = damage ? DiceService.rollDamage(exp) : DiceService.rollTest(exp);
    setState(() {
      log(title, '$exp = ${r.total} — ${r.detail}');
    });
    showRollDialog(title, exp, r);
    toast('$title: ${r.total}');
    save();
  }

  Future<void> showRollDialog(String title, String exp, RollResult r) async {
    if (!mounted) return;
    await showGeneralDialog(
      context: context,
      barrierDismissible: true,
      barrierLabel: 'Rolagem',
      transitionDuration: const Duration(milliseconds: 170),
      pageBuilder: (_, __, ___) => Align(
        alignment: Alignment.topCenter,
        child: Material(
          color: Colors.transparent,
          child: Container(
            width: min(MediaQuery.of(context).size.width - 24, 520.0),
            margin: const EdgeInsets.only(top: 28),
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: const Color(0xFF100707),
              borderRadius: BorderRadius.circular(18),
              border: Border.all(color: const Color(0xFFE43642)),
              boxShadow: const [BoxShadow(blurRadius: 32, color: Colors.black87)],
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title.toUpperCase(), style: const TextStyle(fontWeight: FontWeight.w900, letterSpacing: 1.2)),
                const SizedBox(height: 8),
                Text('${r.total}', style: const TextStyle(fontSize: 48, color: Color(0xFFD8A549), fontWeight: FontWeight.w900)),
                Text('$exp • ${r.mode}', style: const TextStyle(color: Color(0xFFBDA69D))),
                const SizedBox(height: 8),
                Text(r.detail, style: const TextStyle(color: Color(0xFFFFF3EA))),
                const SizedBox(height: 12),
                Align(
                  alignment: Alignment.centerRight,
                  child: FilledButton(onPressed: () => Navigator.pop(context), child: const Text('Fechar')),
                )
              ],
            ),
          ),
        ),
      ),
    );
  }

  int get peLimit => max(1, ((toInt(state.p['nex']) + 4) / 5).floor());

  void applyOptionalRules() {
    if (state.optional['nexNivel'] == true) {
      state.p['level'] = peLimit;
      state.stats['peTurn'] = peLimit;
    }
  }

  @override
  Widget build(BuildContext context) {
    applyOptionalRules();
    final wide = MediaQuery.of(context).size.width > 900;
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: RadialGradient(
            center: Alignment(-0.8, -1),
            radius: 1.2,
            colors: [Color(0x55361113), Color(0xFF050202)],
          ),
        ),
        child: SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(10),
            child: wide
                ? Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      SizedBox(width: 286, child: sideBar()),
                      const SizedBox(width: 10),
                      Expanded(child: mainContent()),
                    ],
                  )
                : Column(
                    children: [
                      mobileTabs(),
                      const SizedBox(height: 8),
                      Expanded(child: mainContent()),
                    ],
                  ),
          ),
        ),
      ),
    );
  }

  Widget sideBar() {
    return BloodPanel(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          headerMini(),
          const SizedBox(height: 14),
          const SectionTitle('Abas'),
          for (var i = 0; i < tabs.length; i++)
            Padding(
              padding: const EdgeInsets.only(bottom: 7),
              child: tabButton(i),
            ),
        ],
      ),
    );
  }

  Widget mobileTabs() {
    return SizedBox(
      height: 48,
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        itemCount: tabs.length,
        separatorBuilder: (_, __) => const SizedBox(width: 7),
        itemBuilder: (_, i) => tabButton(i),
      ),
    );
  }

  Widget tabButton(int i) {
    final selected = tab == i;
    return OutlinedButton(
      onPressed: () => setState(() => tab = i),
      style: OutlinedButton.styleFrom(
        side: BorderSide(color: selected ? const Color(0xFFE43642) : const Color(0xFF4C2728)),
        backgroundColor: selected ? const Color(0x55690912) : const Color(0xFF130808),
        foregroundColor: const Color(0xFFFFF3EA),
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 12),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      ),
      child: Text(tabs[i].toUpperCase(), style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w900)),
    );
  }

  Widget mainContent() {
    return ListView(
      children: [
        header(),
        const SizedBox(height: 10),
        if (tab == 0) painel(),
        if (tab == 1) ficha(),
        if (tab == 2) pericias(),
        if (tab == 3) ataques(),
        if (tab == 4) rituais(),
        if (tab == 5) poderes(),
        if (tab == 6) inventario(),
        if (tab == 7) condicoes(),
        if (tab == 8) preparar(),
        if (tab == 9) notas(),
        if (tab == 10) config(),
      ],
    );
  }

  Widget headerMini() {
    return Column(
      children: [
        CircleAvatar(
          radius: 34,
          backgroundColor: const Color(0xFF260A0D),
          child: Text(initials('${state.p['name']}'), style: const TextStyle(fontSize: 26, fontWeight: FontWeight.w900)),
        ),
        const SizedBox(height: 8),
        Text('${state.p['name']}'.toUpperCase(), textAlign: TextAlign.center, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w900)),
        Text('${state.p['class']} • ${state.p['trail']}', style: const TextStyle(color: Color(0xFFBDA69D), fontSize: 12)),
      ],
    );
  }

  Widget header() {
    final s = Map<String, dynamic>.from(state.stats);
    return BloodPanel(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Wrap(
            spacing: 12,
            runSpacing: 10,
            crossAxisAlignment: WrapCrossAlignment.center,
            children: [
              CircleAvatar(
                radius: 38,
                backgroundColor: const Color(0xFF260A0D),
                child: Text(initials('${state.p['name']}'), style: const TextStyle(fontSize: 28, fontWeight: FontWeight.w900)),
              ),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const BadgeText('VERSÃO FLUTTER V4.2'),
                  Text('${state.p['name']}'.toUpperCase(), style: const TextStyle(fontSize: 34, fontWeight: FontWeight.w900, height: 1)),
                  Wrap(
                    spacing: 6,
                    children: [
                      BadgeText('${state.p['class']} • ${state.p['trail']}', blue: true),
                      BadgeText('NEX ${state.p['nex']}% • Nível ${state.p['level']}', gold: true),
                    ],
                  ),
                ],
              ),
              Wrap(
                spacing: 8,
                children: [
                  smallButton('Salvar', () => save(notify: true), green: true),
                  smallButton('d20', () => roll('1d20', 'Rolagem rápida'), blue: true),
                ],
              )
            ],
          ),
          const SizedBox(height: 14),
          ResponsiveWrap(
            minItemWidth: 210,
            children: [
              StatCard('PV', toInt(s['pv']), toInt(s['pvMax']), onMinus: () => adjustStat('pv', -1), onPlus: () => adjustStat('pv', 1)),
              if (state.optional['semSanidade'] == true)
                StatCard('PD', toInt(s['pd']), toInt(s['pdMax']), blue: true, onMinus: () => adjustStat('pd', -1), onPlus: () => adjustStat('pd', 1))
              else ...[
                StatCard('PE', toInt(s['pe']), toInt(s['peMax']), blue: true, onMinus: () => adjustStat('pe', -1), onPlus: () => adjustStat('pe', 1)),
                StatCard('SAN', toInt(s['san']), toInt(s['sanMax']), green: true, onMinus: () => adjustStat('san', -1), onPlus: () => adjustStat('san', 1)),
              ],
              InfoCard('DEF/RD', '${s['def']}/${s['rd']}', 'DT ${s['dt']} • Mov. ${s['move']}m'),
            ],
          )
        ],
      ),
    );
  }

  void adjustStat(String k, int delta) {
    setState(() {
      state.stats[k] = max(0, toInt(state.stats[k]) + delta);
      final maxKey = '${k}Max';
      if (state.stats.containsKey(maxKey)) {
        state.stats[k] = min(toInt(state.stats[k]), toInt(state.stats[maxKey]));
      }
      log('Status', '$k ${delta > 0 ? '+' : ''}$delta');
    });
    save();
  }

  Widget painel() {
    return Column(
      children: [
        GridWrap(children: [
          BloodCard(
            title: 'Ações rápidas',
            child: Wrap(
              spacing: 8,
              runSpacing: 8,
              children: [
                smallButton('Rolar d20', () => roll('1d20', 'd20'), blue: true),
                smallButton('Início do turno', () => toast('Turno iniciado.')),
                smallButton('Preparar ação', () => setState(() => tab = 8), gold: true),
                smallButton('Salvar', () => save(notify: true), green: true),
              ],
            ),
          ),
          BloodCard(
            title: 'Alertas',
            child: Wrap(
              spacing: 6,
              children: [
                if (toInt(state.stats['pv']) <= 0) const BadgeText('PV zerado'),
                if (toInt(state.stats['pv']) <= toInt(state.stats['pvMax']) / 2) const BadgeText('PV baixo', gold: true),
                if (state.optional['semSanidade'] != true && toInt(state.stats['san']) <= toInt(state.stats['sanMax']) / 3) const BadgeText('SAN crítica'),
                if (state.attacks.any((a) => toInt(a['ammoMax']) > 0 && toInt(a['ammo']) <= 2)) const BadgeText('Munição baixa', gold: true),
                const BadgeText('Notificações ativas', blue: true),
              ],
            ),
          ),
        ]),
        const SizedBox(height: 10),
        BloodCard(
          title: 'Histórico recente',
          child: Column(
            children: state.logs.reversed.take(6).map((l) => LogLine(l)).toList(),
          ),
        ),
      ],
    );
  }

  Widget ficha() {
    return Column(
      children: [
        GridWrap(children: [
          BloodCard(
            title: 'Identidade',
            child: Column(
              children: [
                textEdit('Nome', state.p['name'], (v) => state.p['name'] = v),
                textEdit('Classe', state.p['class'], (v) => state.p['class'] = v),
                textEdit('Trilha', state.p['trail'], (v) => state.p['trail'] = v),
                textEdit('Origem', state.p['origin'], (v) => state.p['origin'] = v),
                numEdit('NEX', state.p['nex'], (v) => state.p['nex'] = v),
                numEdit('Nível', state.p['level'], (v) => state.p['level'] = v),
              ],
            ),
          ),
          BloodCard(
            title: 'Status',
            child: Column(
              children: [
                for (final k in ['pv', 'pvMax', 'pe', 'peMax', 'pd', 'pdMax', 'san', 'sanMax', 'def', 'rd', 'dt', 'move'])
                  numEdit(k.toUpperCase(), state.stats[k], (v) => state.stats[k] = v),
              ],
            ),
          ),
          BloodCard(
            title: 'Atributos',
            child: Column(
              children: [
                for (final a in attrs) numEdit(a, state.attrs[a], (v) => state.attrs[a] = v),
              ],
            ),
          ),
        ])
      ],
    );
  }

  Widget pericias() {
    return GridWrap(
      children: [
        for (final name in skillNames)
          BloodCard(
            title: name,
            child: Builder(builder: (_) {
              final sk = state.skills[name]!;
              final attr = '${sk['attr']}';
              final total = toInt(sk['train']) + toInt(sk['bonus']) + toInt(sk['temp']);
              final dice = max(1, toInt(state.attrs[attr]) + toInt(sk['extraDice']));
              return Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Wrap(spacing: 6, children: [
                    BadgeText(attr, blue: true),
                    BadgeText('+$total', gold: true),
                    BadgeText('${dice}d20', blue: true),
                  ]),
                  const SizedBox(height: 8),
                  Text('Treino ${sk['train']} • Bônus ${sk['bonus']} • Temp ${sk['temp']}', style: const TextStyle(color: Color(0xFFBDA69D))),
                  const SizedBox(height: 8),
                  Wrap(spacing: 8, runSpacing: 8, children: [
                    smallButton('Rolar', () => roll('${dice}d20+$total', 'Teste de $name'), blue: true),
                    smallButton('Editar', () => editSkill(name), gold: true),
                  ]),
                ],
              );
            }),
          ),
      ],
    );
  }

  Future<void> editSkill(String name) async {
    final current = Map<String, dynamic>.from(state.skills[name]!);
    final attrCtrl = TextEditingController(text: '${current['attr']}');
    final trainCtrl = TextEditingController(text: '${current['train']}');
    final bonusCtrl = TextEditingController(text: '${current['bonus']}');
    final tempCtrl = TextEditingController(text: '${current['temp']}');
    final diceCtrl = TextEditingController(text: '${current['extraDice']}');

    final ok = await editDialog(
      title: 'Editar $name',
      fields: [
        dialogField('Atributo', attrCtrl),
        dialogField('Treino', trainCtrl, number: true),
        dialogField('Bônus', bonusCtrl, number: true),
        dialogField('Temporário', tempCtrl, number: true),
        dialogField('Dados extras', diceCtrl, number: true),
      ],
    );

    if (ok) {
      setState(() {
        state.skills[name] = {
          'attr': attrCtrl.text.trim().isEmpty ? defaultSkillAttr(name) : attrCtrl.text.trim(),
          'train': int.tryParse(trainCtrl.text) ?? 0,
          'bonus': int.tryParse(bonusCtrl.text) ?? 0,
          'temp': int.tryParse(tempCtrl.text) ?? 0,
          'extraDice': int.tryParse(diceCtrl.text) ?? 0,
        };
      });
      toast('$name editada.');
      save();
    }
  }

  Widget ataques() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        smallButton('+ Ataque', addAttack, green: true),
        const SizedBox(height: 10),
        GridWrap(
          children: state.attacks.map((a) {
            return BloodCard(
              title: '${a['name']}',
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Wrap(spacing: 6, children: [
                    BadgeText('${a['test']}', blue: true),
                    BadgeText('${a['damage']}', gold: true),
                    BadgeText('${a['type']}'),
                  ]),
                  const SizedBox(height: 10),
                  Text('Crítico ${a['crit']} • Munição ${a['ammo']}/${a['ammoMax']}', style: const TextStyle(color: Color(0xFFBDA69D))),
                  const SizedBox(height: 10),
                  Wrap(spacing: 8, runSpacing: 8, children: [
                    smallButton('Ataque', () => roll('${a['test']}', 'Ataque: ${a['name']}'), blue: true),
                    smallButton('Dano', () => roll('${a['damage']}', 'Dano: ${a['name']}', damage: true), gold: true),
                    smallButton('Editar', () => editAttack(a), gold: true),
                    smallButton('Munição -1', () {
                      setState(() => a['ammo'] = max(0, toInt(a['ammo']) - 1));
                      save();
                    }),
                  ]),
                ],
              ),
            );
          }).toList(),
        )
      ],
    );
  }

  void addAttack() {
    final a = {
      'id': 'atk${DateTime.now().millisecondsSinceEpoch}',
      'name': 'Novo Ataque',
      'test': '1d20+0',
      'damage': '1d6',
      'crit': '20/x2',
      'type': 'Impacto',
      'ammo': 0,
      'ammoMax': 0,
      'fav': false,
    };
    state.attacks.add(a);
    editAttack(a);
  }

  Future<void> editAttack(Map<String, dynamic> a) async {
    final name = TextEditingController(text: '${a['name']}');
    final test = TextEditingController(text: '${a['test']}');
    final damage = TextEditingController(text: '${a['damage']}');
    final crit = TextEditingController(text: '${a['crit']}');
    final type = TextEditingController(text: '${a['type']}');
    final ammo = TextEditingController(text: '${a['ammo']}');
    final ammoMax = TextEditingController(text: '${a['ammoMax']}');
    final ok = await editDialog(title: 'Editar ataque', fields: [
      dialogField('Nome', name),
      dialogField('Teste', test),
      dialogField('Dano', damage),
      dialogField('Crítico', crit),
      dialogField('Tipo', type),
      dialogField('Munição atual', ammo, number: true),
      dialogField('Munição máxima', ammoMax, number: true),
    ]);
    if (ok) {
      setState(() {
        a['name'] = name.text;
        a['test'] = test.text;
        a['damage'] = damage.text;
        a['crit'] = crit.text;
        a['type'] = type.text;
        a['ammo'] = int.tryParse(ammo.text) ?? 0;
        a['ammoMax'] = int.tryParse(ammoMax.text) ?? 0;
      });
      save();
    }
  }

  Widget rituais() => listManager(
        title: 'Rituais',
        button: '+ Ritual',
        list: state.rituals,
        empty: 'Nenhum ritual.',
        create: () => {'name': 'Novo Ritual', 'element': 'Sangue', 'circle': '1', 'cost': '1 PE', 'damage': '', 'desc': ''},
        card: (r) => BloodCard(
          title: '${r['name']}',
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Wrap(spacing: 6, children: [BadgeText('${r['element']}', blue: true), BadgeText('${r['circle']}º círculo', gold: true), BadgeText('${r['cost']}')]),
            const SizedBox(height: 8),
            Text('${r['desc']}', style: const TextStyle(color: Color(0xFFBDA69D))),
            const SizedBox(height: 8),
            Wrap(spacing: 8, children: [
              smallButton('Conjurar', () => toast('${r['name']} conjurado.')),
              if ('${r['damage']}'.isNotEmpty) smallButton('Dano', () => roll('${r['damage']}', 'Dano ritual: ${r['name']}', damage: true), gold: true),
              smallButton('Editar', () => editSimple(r, ['name', 'element', 'circle', 'cost', 'damage', 'desc'])),
            ])
          ]),
        ),
      );

  Widget poderes() => listManager(
        title: 'Poderes e Habilidades',
        button: '+ Poder',
        list: state.powers,
        empty: 'Nenhum poder.',
        create: () => {'name': 'Novo Poder', 'type': 'Classe', 'cost': '0 PE', 'action': 'Livre', 'desc': ''},
        card: (p) => BloodCard(
          title: '${p['name']}',
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Wrap(spacing: 6, children: [BadgeText('${p['type']}', blue: true), BadgeText('${p['cost']}', gold: true), BadgeText('${p['action']}')]),
            const SizedBox(height: 8),
            Text('${p['desc']}', style: const TextStyle(color: Color(0xFFBDA69D))),
            const SizedBox(height: 8),
            Wrap(spacing: 8, children: [
              smallButton('Usar', () => toast('${p['name']} usado.')),
              smallButton('Editar', () => editSimple(p, ['name', 'type', 'cost', 'action', 'desc'])),
            ])
          ]),
        ),
      );

  Widget inventario() => listManager(
        title: 'Inventário',
        button: '+ Item',
        list: state.items,
        empty: 'Nenhum item.',
        create: () => {'name': 'Novo Item', 'cat': 'Equipamento', 'qty': '1', 'uses': '0', 'desc': ''},
        card: (i) => BloodCard(
          title: '${i['name']}',
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Wrap(spacing: 6, children: [BadgeText('${i['cat']}', blue: true), BadgeText('Qtd ${i['qty']}', gold: true), BadgeText('Usos ${i['uses']}')]),
            const SizedBox(height: 8),
            Text('${i['desc']}', style: const TextStyle(color: Color(0xFFBDA69D))),
            const SizedBox(height: 8),
            Wrap(spacing: 8, children: [
              smallButton('Usar', () {
                final uses = int.tryParse('${i['uses']}') ?? 0;
                if (uses <= 0) {
                  toast('Esse item não tem usos disponíveis.');
                  return;
                }
                setState(() => i['uses'] = '${uses - 1}');
                toast('${i['name']} usado.');
                save();
              }),
              smallButton('Editar', () => editSimple(i, ['name', 'cat', 'qty', 'uses', 'desc'])),
            ])
          ]),
        ),
      );

  Widget condicoes() => listManager(
        title: 'Condições',
        button: '+ Condição',
        list: state.conditions,
        empty: 'Sem condições.',
        create: () => {'name': 'Sangrando', 'dur': '3', 'effect': 'Perde PV no início do turno.'},
        card: (c) => BloodCard(
          title: '${c['name']}',
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            BadgeText('Duração ${c['dur']}', gold: true),
            const SizedBox(height: 8),
            Text('${c['effect']}', style: const TextStyle(color: Color(0xFFBDA69D))),
            const SizedBox(height: 8),
            Wrap(spacing: 8, children: [
              smallButton('-1 rodada', () {
                final dur = int.tryParse('${c['dur']}') ?? 0;
                setState(() {
                  c['dur'] = '${max(0, dur - 1)}';
                  if (c['dur'] == '0') state.conditions.remove(c);
                });
                save();
              }),
              smallButton('Editar', () => editSimple(c, ['name', 'dur', 'effect'])),
            ])
          ]),
        ),
      );

  Widget preparar() {
    return BloodCard(
      title: 'Preparar Ação',
      child: Column(children: [
        textEdit('Título', state.prepare['title'], (v) => state.prepare['title'] = v),
        textEdit('Vou usar', state.prepare['use'], (v) => state.prepare['use'] = v),
        textEdit('Alvo', state.prepare['target'], (v) => state.prepare['target'] = v),
        textEdit('Testes separados por ;', state.prepare['tests'], (v) => state.prepare['tests'] = v),
        textEdit('Dano', state.prepare['damage'], (v) => state.prepare['damage'] = v),
        numEdit('PE previsto', state.prepare['pe'], (v) => state.prepare['pe'] = v),
        numEdit('PD previsto', state.prepare['pd'], (v) => state.prepare['pd'] = v),
        textEdit('Notas', state.prepare['notes'], (v) => state.prepare['notes'] = v, lines: 4),
        const SizedBox(height: 8),
        Wrap(spacing: 8, children: [
          smallButton('Executar', executePrepared, green: true),
          smallButton('Limpar', () {
            setState(() => state.prepare = AppState().prepare);
            save();
          }, danger: true),
        ])
      ]),
    );
  }

  void executePrepared() {
    final tests = '${state.prepare['tests']}'.split(';').map((e) => e.trim()).where((e) => e.isNotEmpty);
    for (final t in tests) {
      roll(t, 'Teste preparado');
    }
    final dmg = '${state.prepare['damage']}';
    if (dmg.trim().isNotEmpty) roll(dmg, 'Dano preparado', damage: true);
    toast('Ação preparada executada.');
  }

  Widget notas() {
    return BloodCard(
      title: 'Notas de Investigação',
      child: Column(children: [
        textEdit('Ordem de ação', state.prepare['order'] ?? '', (v) => state.prepare['order'] = v, lines: 3),
        textEdit('Pistas', state.prepare['clues'] ?? '', (v) => state.prepare['clues'] = v, lines: 5),
        textEdit('Teorias', state.prepare['theories'] ?? '', (v) => state.prepare['theories'] = v, lines: 5),
      ]),
    );
  }

  Widget config() {
    return Column(children: [
      BloodCard(
        title: 'Regras Opcionais',
        child: Column(children: [
          for (final e in state.optional.entries)
            SwitchListTile(
              title: Text(labelForOptional(e.key)),
              subtitle: Text(descForOptional(e.key), style: const TextStyle(color: Color(0xFFBDA69D))),
              value: e.value,
              activeColor: const Color(0xFFE43642),
              onChanged: (v) {
                setState(() => state.optional[e.key] = v);
                save();
              },
            )
        ]),
      ),
      const SizedBox(height: 10),
      BloodCard(
        title: 'Dados da ficha',
        child: Column(children: [
          smallButton('Salvar agora', () => save(notify: true), green: true),
          const SizedBox(height: 8),
          smallButton('Limpar ficha', () async {
            setState(() => state = AppState());
            save(notify: true);
          }, danger: true),
        ]),
      )
    ]);
  }

  String labelForOptional(String k) {
    return {
          'nexNivel': 'NEX & Nível',
          'semSanidade': 'Jogando sem Sanidade',
          'municao': 'Contador de Munição',
          'combateNarrativo': 'Combate Narrativo',
          'conjuracaoComplexa': 'Conjuração Complexa',
          'alteracoesNex': 'Alterações de NEX',
        }[k] ??
        k;
  }

  String descForOptional(String k) {
    return {
          'nexNivel': 'Calcula nível a partir do NEX e ajusta PE por turno.',
          'semSanidade': 'Prioriza PD e oculta SAN do painel principal.',
          'municao': 'Mostra munição nos ataques e alerta munição baixa.',
          'combateNarrativo': 'Ajuda a registrar intenção e consequência.',
          'conjuracaoComplexa': 'Usa Preparar Ação para etapas e componentes.',
          'alteracoesNex': 'Base pronta para alterações futuras.',
        }[k] ??
        '';
  }

  Widget listManager({
    required String title,
    required String button,
    required List<Map<String, dynamic>> list,
    required String empty,
    required Map<String, dynamic> Function() create,
    required Widget Function(Map<String, dynamic>) card,
  }) {
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      smallButton(button, () {
        final item = create();
        setState(() => list.add(item));
        editSimple(item, item.keys.toList());
      }, green: true),
      const SizedBox(height: 10),
      if (list.isEmpty) Text(empty, style: const TextStyle(color: Color(0xFFBDA69D))),
      GridWrap(children: list.map(card).toList()),
    ]);
  }

  Future<void> editSimple(Map<String, dynamic> item, List<String> keys) async {
    final ctrls = {for (final k in keys) k: TextEditingController(text: '${item[k] ?? ''}')};
    final ok = await editDialog(
      title: 'Editar',
      fields: keys.map((k) => dialogField(k, ctrls[k]!)).toList(),
    );
    if (ok) {
      setState(() {
        for (final k in keys) {
          item[k] = ctrls[k]!.text;
        }
      });
      save();
    }
  }

  Widget textEdit(String label, dynamic value, void Function(String) onChanged, {int lines = 1}) {
    final controller = TextEditingController(text: '$value');
    controller.selection = TextSelection.collapsed(offset: controller.text.length);
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: TextField(
        controller: controller,
        maxLines: lines,
        decoration: input(label),
        onSubmitted: (v) {
          setState(() => onChanged(v));
          save();
        },
        onChanged: (v) {
          onChanged(v);
          save();
        },
      ),
    );
  }

  Widget numEdit(String label, dynamic value, void Function(int) onChanged) {
    return textEdit(label, value, (v) => onChanged(int.tryParse(v) ?? 0));
  }

  InputDecoration input(String label) {
    return InputDecoration(
      labelText: label,
      labelStyle: const TextStyle(color: Color(0xFFBDA69D), fontWeight: FontWeight.w800),
      filled: true,
      fillColor: const Color(0xFF0D0606),
      enabledBorder: OutlineInputBorder(borderSide: const BorderSide(color: Color(0xFF4B2C2C)), borderRadius: BorderRadius.circular(12)),
      focusedBorder: OutlineInputBorder(borderSide: const BorderSide(color: Color(0xFFE43642)), borderRadius: BorderRadius.circular(12)),
    );
  }

  Widget dialogField(String label, TextEditingController c, {bool number = false}) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: TextField(
        controller: c,
        keyboardType: number ? TextInputType.number : TextInputType.text,
        decoration: input(label),
      ),
    );
  }

  Future<bool> editDialog({required String title, required List<Widget> fields}) async {
    return await showDialog<bool>(
          context: context,
          builder: (_) => AlertDialog(
            backgroundColor: const Color(0xFF100707),
            title: Text(title),
            content: SizedBox(width: min(MediaQuery.of(context).size.width - 40, 520.0), child: SingleChildScrollView(child: Column(mainAxisSize: MainAxisSize.min, children: fields))),
            actions: [
              TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Cancelar')),
              FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Salvar')),
            ],
          ),
        ) ??
        false;
  }
}

class BloodPanel extends StatelessWidget {
  const BloodPanel({super.key, required this.child});
  final Widget child;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [Color(0xEE1C0D0E), Color(0xF2080404)],
        ),
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: const Color(0xFF522629)),
        boxShadow: const [BoxShadow(color: Colors.black54, blurRadius: 28, offset: Offset(0, 12))],
      ),
      child: child,
    );
  }
}

class BloodCard extends StatelessWidget {
  const BloodCard({super.key, required this.title, required this.child});
  final String title;
  final Widget child;

  @override
  Widget build(BuildContext context) {
    return BloodPanel(
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        SectionTitle(title),
        child,
      ]),
    );
  }
}

class SectionTitle extends StatelessWidget {
  const SectionTitle(this.text, {super.key});
  final String text;

  @override
  Widget build(BuildContext context) {
    return Row(children: [
      Container(width: 26, height: 3, color: const Color(0xFFE43642)),
      const SizedBox(width: 8),
      Expanded(child: Text(text.toUpperCase(), style: const TextStyle(fontWeight: FontWeight.w900, letterSpacing: 1.2, fontSize: 16))),
    ]);
  }
}

class BadgeText extends StatelessWidget {
  const BadgeText(this.text, {super.key, this.gold = false, this.blue = false});
  final String text;
  final bool gold;
  final bool blue;

  @override
  Widget build(BuildContext context) {
    final color = gold ? const Color(0xFFD8A549) : blue ? const Color(0xFF83BAFF) : const Color(0xFFE43642);
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 5),
      decoration: BoxDecoration(
        color: Colors.black26,
        border: Border.all(color: color.withOpacity(.65)),
        borderRadius: BorderRadius.circular(999),
      ),
      child: Text(text.toUpperCase(), style: TextStyle(color: color, fontWeight: FontWeight.w900, fontSize: 11)),
    );
  }
}

class StatCard extends StatelessWidget {
  const StatCard(this.name, this.value, this.maxValue, {super.key, this.blue = false, this.green = false, required this.onMinus, required this.onPlus});
  final String name;
  final int value;
  final int maxValue;
  final bool blue;
  final bool green;
  final VoidCallback onMinus;
  final VoidCallback onPlus;

  @override
  Widget build(BuildContext context) {
    final pct = maxValue <= 0 ? 0.0 : (value / maxValue).clamp(0.0, 1.0);
    final color = green ? const Color(0xFF88D26D) : blue ? const Color(0xFF83BAFF) : const Color(0xFFE43642);
    return BloodPanel(
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
          Text(name, style: const TextStyle(fontWeight: FontWeight.w900)),
          Text('$value/$maxValue', style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 20)),
        ]),
        const SizedBox(height: 8),
        LinearProgressIndicator(value: pct, minHeight: 8, color: color, backgroundColor: Colors.black45),
        const SizedBox(height: 8),
        Wrap(
          spacing: 6,
          runSpacing: 6,
          children: [
            SizedBox(width: 74, child: OutlinedButton(onPressed: onMinus, child: const Text('-1'))),
            SizedBox(width: 74, child: OutlinedButton(onPressed: onPlus, child: const Text('+1'))),
          ],
        )
      ]),
    );
  }
}

class InfoCard extends StatelessWidget {
  const InfoCard(this.name, this.value, this.sub, {super.key});
  final String name;
  final String value;
  final String sub;

  @override
  Widget build(BuildContext context) {
    return BloodPanel(
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(name, style: const TextStyle(fontWeight: FontWeight.w900)),
        Text(value, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 28)),
        Text(sub, style: const TextStyle(color: Color(0xFFBDA69D))),
      ]),
    );
  }
}

class GridWrap extends StatelessWidget {
  const GridWrap({super.key, required this.children});
  final List<Widget> children;

  @override
  Widget build(BuildContext context) {
    return ResponsiveWrap(
      minItemWidth: 390,
      children: children,
    );
  }
}

class ResponsiveWrap extends StatelessWidget {
  const ResponsiveWrap({
    super.key,
    required this.children,
    this.minItemWidth = 360,
    this.spacing = 10,
    this.runSpacing = 10,
  });

  final List<Widget> children;
  final double minItemWidth;
  final double spacing;
  final double runSpacing;

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, constraints) {
        final width = constraints.maxWidth.isFinite
            ? constraints.maxWidth
            : MediaQuery.of(context).size.width;
        final columns = width >= (minItemWidth * 2 + spacing) ? 2 : 1;
        final itemWidth = columns == 1 ? width : (width - spacing) / 2;

        return Wrap(
          spacing: spacing,
          runSpacing: runSpacing,
          children: [
            for (final child in children)
              SizedBox(
                width: itemWidth,
                child: child,
              ),
          ],
        );
      },
    );
  }
}

class LogLine extends StatelessWidget {
  const LogLine(this.log, {super.key});
  final Map<String, dynamic> log;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      margin: const EdgeInsets.only(bottom: 8),
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(
        color: Colors.black26,
        border: const Border(left: BorderSide(color: Color(0xFFE43642), width: 3)),
        borderRadius: BorderRadius.circular(10),
      ),
      child: Text('${log['title']}: ${log['text']}\n${log['time']}', style: const TextStyle(color: Color(0xFFBDA69D))),
    );
  }
}

Widget smallButton(String text, VoidCallback onTap, {bool green = false, bool blue = false, bool gold = false, bool danger = false}) {
  final color = danger
      ? const Color(0xFFE43642)
      : green
          ? const Color(0xFF88D26D)
          : blue
              ? const Color(0xFF83BAFF)
              : gold
                  ? const Color(0xFFD8A549)
                  : const Color(0xFF7C3438);
  return OutlinedButton(
    onPressed: onTap,
    style: OutlinedButton.styleFrom(
      side: BorderSide(color: color.withOpacity(.75)),
      foregroundColor: const Color(0xFFFFF3EA),
      backgroundColor: danger ? const Color(0xFF690912) : const Color(0xFF130808),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 12),
    ),
    child: Text(text.toUpperCase(), style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w900)),
  );
}
