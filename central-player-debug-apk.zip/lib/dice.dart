
import 'dart:math';

final _rng = Random();

class RollResult {
  RollResult({
    required this.total,
    required this.detail,
    required this.mode,
    required this.rolls,
  });

  final int total;
  final String detail;
  final String mode;
  final List<int> rolls;
}

class DiceService {
  static RollResult test(String expression) => _roll(expression, ordemTest: true);
  static RollResult damage(String expression) => _roll(expression, ordemTest: false);

  static RollResult _roll(String expression, {required bool ordemTest}) {
    final clean = expression.toLowerCase().replaceAll(' ', '').replaceAll('−', '-').replaceAll('ó', '6');
    final parts = RegExp(r'[+-]?[^+-]+').allMatches(clean).map((m) => m.group(0)!).toList();

    var total = 0;
    final details = <String>[];
    final allRolls = <int>[];

    for (var part in parts.isEmpty ? ['0'] : parts) {
      var sign = 1;
      if (part.startsWith('+')) {
        part = part.substring(1);
      } else if (part.startsWith('-')) {
        sign = -1;
        part = part.substring(1);
      }

      final dice = RegExp(r'^(\d*)d(\d+)$').firstMatch(part);
      if (dice != null) {
        final qty = int.tryParse(dice.group(1)!.isEmpty ? '1' : dice.group(1)!) ?? 1;
        final faces = int.tryParse(dice.group(2)!) ?? 20;
        final rolls = List<int>.generate(qty, (_) => _rng.nextInt(faces) + 1);
        allRolls.addAll(rolls);

        final used = ordemTest && faces == 20
            ? rolls.reduce(max)
            : rolls.fold<int>(0, (sum, value) => sum + value);

        total += sign * used;
        final chosen = ordemTest && faces == 20 ? ' maior $used' : '';
        details.add('${sign < 0 ? '-' : ''}${qty}d$faces[${rolls.join(', ')}]$chosen');
      } else {
        final value = int.tryParse(part) ?? 0;
        total += sign * value;
        details.add('${sign < 0 ? '-' : ''}$value');
      }
    }

    return RollResult(
      total: total,
      detail: details.join(' + ').replaceAll('+ -', '- '),
      mode: ordemTest ? 'Teste OP: usa o maior d20' : 'Dano: soma todos os dados',
      rolls: allRolls,
    );
  }
}

String detectDice(String text) {
  final match = RegExp(r'\d+d\d+(?:[+\-]\d+)?', caseSensitive: false).firstMatch(text.replaceAll('ó', '6'));
  return match == null ? '' : match.group(0)!;
}
