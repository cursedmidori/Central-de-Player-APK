
import 'dart:math';
import 'package:flutter/material.dart';

import 'utils.dart';

const bg = Color(0xFF050202);
const panel = Color(0xFF120706);
const panel2 = Color(0xFF080404);
const line = Color(0xFF522629);
const line2 = Color(0xFF843940);
const text = Color(0xFFFFF3EA);
const muted = Color(0xFFBDA69D);
const red = Color(0xFFE43642);
const blood = Color(0xFF690912);
const gold = Color(0xFFD8A549);
const green = Color(0xFF88D26D);
const blue = Color(0xFF83BAFF);
const purple = Color(0xFFC997FF);

class BloodPanel extends StatelessWidget {
  const BloodPanel({super.key, required this.child, this.padding = 14});
  final Widget child;
  final double padding;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.all(padding),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [Color(0xEE1C0D0E), Color(0xF2080404)],
        ),
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: line),
        boxShadow: const [BoxShadow(color: Colors.black54, blurRadius: 28, offset: Offset(0, 12))],
      ),
      child: child,
    );
  }
}

class BloodCard extends StatelessWidget {
  const BloodCard({super.key, required this.title, required this.child, this.actions});
  final String title;
  final Widget child;
  final List<Widget>? actions;

  @override
  Widget build(BuildContext context) {
    return BloodPanel(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SectionTitle(title, actions: actions),
          const SizedBox(height: 10),
          child,
        ],
      ),
    );
  }
}

class SectionTitle extends StatelessWidget {
  const SectionTitle(this.textValue, {super.key, this.actions});
  final String textValue;
  final List<Widget>? actions;

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Container(width: 26, height: 3, color: red),
        const SizedBox(width: 8),
        Expanded(
          child: Text(
            textValue.toUpperCase(),
            style: const TextStyle(fontWeight: FontWeight.w900, letterSpacing: 1.2, fontSize: 16),
          ),
        ),
        if (actions != null) ...actions!,
      ],
    );
  }
}

class BadgeText extends StatelessWidget {
  const BadgeText(this.value, {super.key, this.kind = BadgeKind.red});
  final String value;
  final BadgeKind kind;

  Color get color {
    switch (kind) {
      case BadgeKind.red:
        return red;
      case BadgeKind.gold:
        return gold;
      case BadgeKind.blue:
        return blue;
      case BadgeKind.green:
        return green;
      case BadgeKind.purple:
        return purple;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(right: 5, bottom: 5),
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 5),
      decoration: BoxDecoration(
        color: Colors.black26,
        border: Border.all(color: color.withOpacity(.7)),
        borderRadius: BorderRadius.circular(999),
      ),
      child: Text(
        value.toUpperCase(),
        style: TextStyle(color: color, fontWeight: FontWeight.w900, fontSize: 11),
      ),
    );
  }
}

enum BadgeKind { red, gold, blue, green, purple }

class AppButton extends StatelessWidget {
  const AppButton(this.label, this.onTap, {super.key, this.kind = BadgeKind.red});
  final String label;
  final VoidCallback onTap;
  final BadgeKind kind;

  Color get color {
    switch (kind) {
      case BadgeKind.red:
        return red;
      case BadgeKind.gold:
        return gold;
      case BadgeKind.blue:
        return blue;
      case BadgeKind.green:
        return green;
      case BadgeKind.purple:
        return purple;
    }
  }

  @override
  Widget build(BuildContext context) {
    return OutlinedButton(
      onPressed: onTap,
      style: OutlinedButton.styleFrom(
        side: BorderSide(color: color.withOpacity(.75)),
        foregroundColor: text,
        backgroundColor: kind == BadgeKind.red ? blood : const Color(0xFF130808),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 12),
      ),
      child: Text(label.toUpperCase(), style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w900)),
    );
  }
}

class ResponsiveGrid extends StatelessWidget {
  const ResponsiveGrid({
    super.key,
    required this.children,
    this.minItemWidth = 390,
    this.spacing = 10,
    this.runSpacing = 10,
  });

  final List<Widget> children;
  final double minItemWidth;
  final double spacing;
  final double runSpacing;

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, constraints) {
        final width = constraints.maxWidth.isFinite ? constraints.maxWidth : MediaQuery.of(context).size.width;
        final columns = width >= (minItemWidth * 2 + spacing) ? 2 : 1;
        final itemWidth = columns == 1 ? width : (width - spacing) / 2;
        return Wrap(
          spacing: spacing,
          runSpacing: runSpacing,
          children: [
            for (final child in children)
              SizedBox(width: itemWidth, child: child),
          ],
        );
      },
    );
  }
}

class StatCard extends StatelessWidget {
  const StatCard(
    this.name,
    this.value,
    this.maxValue, {
    super.key,
    this.kind = BadgeKind.red,
    required this.onMinus,
    required this.onPlus,
  });

  final String name;
  final int value;
  final int maxValue;
  final BadgeKind kind;
  final VoidCallback onMinus;
  final VoidCallback onPlus;

  Color get color {
    switch (kind) {
      case BadgeKind.red:
        return red;
      case BadgeKind.gold:
        return gold;
      case BadgeKind.blue:
        return blue;
      case BadgeKind.green:
        return green;
      case BadgeKind.purple:
        return purple;
    }
  }

  @override
  Widget build(BuildContext context) {
    final pct = maxValue <= 0 ? 0.0 : (value / maxValue).clamp(0.0, 1.0);
    return BloodPanel(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
            Text(name, style: const TextStyle(fontWeight: FontWeight.w900)),
            Text('$value/$maxValue', style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 22)),
          ]),
          const SizedBox(height: 8),
          LinearProgressIndicator(value: pct, minHeight: 8, color: color, backgroundColor: Colors.black45),
          const SizedBox(height: 8),
          Wrap(spacing: 6, runSpacing: 6, children: [
            SizedBox(width: 74, child: OutlinedButton(onPressed: onMinus, child: const Text('-1'))),
            SizedBox(width: 74, child: OutlinedButton(onPressed: onPlus, child: const Text('+1'))),
          ]),
        ],
      ),
    );
  }
}

class InfoCard extends StatelessWidget {
  const InfoCard(this.name, this.value, this.sub, {super.key});
  final String name;
  final String value;
  final String sub;

  @override
  Widget build(BuildContext context) {
    return BloodPanel(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(name, style: const TextStyle(fontWeight: FontWeight.w900)),
          Text(value, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 28)),
          Text(sub, style: const TextStyle(color: muted)),
        ],
      ),
    );
  }
}

class LogLine extends StatelessWidget {
  const LogLine(this.log, {super.key});
  final Map<String, dynamic> log;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      margin: const EdgeInsets.only(bottom: 8),
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(
        color: Colors.black26,
        border: const Border(left: BorderSide(color: red, width: 3)),
        borderRadius: BorderRadius.circular(10),
      ),
      child: Text('${log['title']}: ${log['text']}\n${log['time']}', style: const TextStyle(color: muted)),
    );
  }
}

InputDecoration bloodInput(String label) {
  return InputDecoration(
    labelText: label,
    labelStyle: const TextStyle(color: muted, fontWeight: FontWeight.w800),
    filled: true,
    fillColor: const Color(0xFF0D0606),
    enabledBorder: OutlineInputBorder(borderSide: const BorderSide(color: Color(0xFF4B2C2C)), borderRadius: BorderRadius.circular(12)),
    focusedBorder: OutlineInputBorder(borderSide: const BorderSide(color: red), borderRadius: BorderRadius.circular(12)),
  );
}

class EmptyText extends StatelessWidget {
  const EmptyText(this.value, {super.key});
  final String value;
  @override
  Widget build(BuildContext context) => Text(value, style: const TextStyle(color: muted));
}
