
const attrs = ['Força', 'Agilidade', 'Intelecto', 'Presença', 'Vigor'];

const skillNames = [
  'Acrobacia',
  'Adestramento',
  'Artes',
  'Atletismo',
  'Atualidades',
  'Ciências',
  'Crime',
  'Diplomacia',
  'Enganação',
  'Fortitude',
  'Furtividade',
  'Iniciativa',
  'Intimidação',
  'Intuição',
  'Investigação',
  'Luta',
  'Medicina',
  'Ocultismo',
  'Percepção',
  'Pilotagem',
  'Pontaria',
  'Profissão',
  'Reflexos',
  'Religião',
  'Sobrevivência',
  'Tática',
  'Tecnologia',
  'Vontade',
];

const damageTypes = [
  'Balístico',
  'Corte',
  'Impacto',
  'Perfuração',
  'Fogo',
  'Frio',
  'Químico',
  'Sangue',
  'Morte',
  'Conhecimento',
  'Energia',
  'Medo',
];

String defaultSkillAttr(String s) {
  const agi = ['Acrobacia', 'Crime', 'Furtividade', 'Iniciativa', 'Pilotagem', 'Pontaria', 'Reflexos'];
  const forca = ['Atletismo', 'Luta'];
  const vigor = ['Fortitude'];
  const pres = ['Adestramento', 'Artes', 'Diplomacia', 'Enganação', 'Intimidação', 'Intuição', 'Percepção', 'Vontade'];
  if (agi.contains(s)) return 'Agilidade';
  if (forca.contains(s)) return 'Força';
  if (vigor.contains(s)) return 'Vigor';
  if (pres.contains(s)) return 'Presença';
  return 'Intelecto';
}

const optionalLabels = {
  'nexNivel': 'NEX & Nível',
  'semSanidade': 'Jogando sem Sanidade',
  'municao': 'Contador de Munição',
  'combateNarrativo': 'Combate Narrativo',
  'conjuracaoComplexa': 'Conjuração Complexa',
  'alteracoesNex': 'Alterações de NEX',
  'limiteCombinado': 'Limite PE + PD combinado',
};

const optionalDescriptions = {
  'nexNivel': 'Calcula nível a partir do NEX e ajusta PE por turno.',
  'semSanidade': 'Prioriza PD e oculta Sanidade do painel de sessão.',
  'municao': 'Mostra munição nas armas e alerta quando estiver baixa.',
  'combateNarrativo': 'Adiciona campos de intenção, posição e consequência narrativa.',
  'conjuracaoComplexa': 'Usa preparação com componentes, etapas, DT e falha.',
  'alteracoesNex': 'Ativa a aba de alterações visuais e mecânicas de NEX.',
  'limiteCombinado': 'Considera PE e PD juntos no limite por turno.',
};
