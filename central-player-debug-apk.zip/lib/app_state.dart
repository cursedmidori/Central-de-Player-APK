
import 'dart:convert';

import 'data.dart';
import 'utils.dart';
import 'dice.dart';

class AppState {
  Map<String, dynamic> p = {
    'name': 'Agente Sem Nome',
    'class': 'Sobrevivente',
    'trail': '—',
    'origin': '—',
    'nex': 5,
    'level': 1,
    'affinity': '',
    'image': '',
    'theme': 'sangue',
  };

  Map<String, dynamic> stats = {
    'pv': 20,
    'pvMax': 20,
    'pe': 4,
    'peMax': 4,
    'pd': 0,
    'pdMax': 0,
    'san': 20,
    'sanMax': 20,
    'def': 10,
    'rd': 0,
    'dt': 10,
    'move': 9,
    'peTurn': 1,
    'load': 0,
    'loadMax': 10,
  };

  Map<String, int> attrsMap = {
    for (final a in attrs) a: 1,
  };

  Map<String, Map<String, dynamic>> skills = {
    for (final s in skillNames)
      s: {
        'attr': defaultSkillAttr(s),
        'train': 0,
        'bonus': 0,
        'temp': 0,
        'extraDice': 0,
      }
  };

  Map<String, bool> optional = {
    'nexNivel': false,
    'semSanidade': false,
    'municao': true,
    'combateNarrativo': false,
    'conjuracaoComplexa': false,
    'alteracoesNex': false,
    'limiteCombinado': false,
  };

  Map<String, dynamic> profile = {
    'concept': '',
    'originPower': '',
    'originSkills': '',
    'classAbility': '',
    'trailAbilities': '',
    'chosenPowers': '',
    'buildNotes': '',
    'appearance': '',
    'personality': '',
    'fear': '',
    'objective': '',
  };

  List<Map<String, dynamic>> weapons = [
    {
      'id': 'weapon0',
      'name': 'Ataque Improvisado',
      'skill': 'Luta',
      'attr': 'Força',
      'test': '1d20+0',
      'damage': '1d6',
      'type': 'Impacto',
      'crit': '20/x2',
      'range': 'Corpo a corpo',
      'category': 'I',
      'ammo': 0,
      'ammoMax': 0,
      'reload': '',
      'mods': '',
      'curses': '',
      'equipped': true,
      'fav': true,
      'notes': '',
    }
  ];

  List<Map<String, dynamic>> rituals = [];
  List<Map<String, dynamic>> powers = [];
  List<Map<String, dynamic>> inventory = [];
  List<Map<String, dynamic>> protections = [];
  List<Map<String, dynamic>> conditions = [];
  List<Map<String, dynamic>> buffs = [];
  List<Map<String, dynamic>> injuries = [];
  List<Map<String, dynamic>> marks = [];
  List<Map<String, dynamic>> nexChanges = [];
  List<Map<String, dynamic>> combos = [];
  List<Map<String, dynamic>> backups = [];
  List<Map<String, dynamic>> logs = [];

  Map<String, dynamic> prepare = {
    'title': '',
    'mainAction': '',
    'moveAction': '',
    'freeAction': '',
    'reaction': '',
    'use': '',
    'target': '',
    'pe': 0,
    'pd': 0,
    'pv': 0,
    'san': 0,
    'tests': '',
    'damage': '',
    'condition': '',
    'failPlan': '',
    'notes': '',
  };

  Map<String, dynamic> mission = {
    'name': '',
    'objective': '',
    'secondary': '',
    'location': '',
    'threat': '',
    'npcs': '',
    'clues': '',
    'documents': '',
    'symbols': '',
    'suspects': '',
    'questions': '',
    'theories': '',
    'timeline': '',
    'relations': '',
    'consequences': '',
  };

  Map<String, dynamic> rest = {
    'lastRest': '',
    'interludeActions': '',
    'treatment': '',
    'crafting': '',
    'study': '',
    'training': '',
  };

  List<Map<String, dynamic>> evolution = [];

  Map<String, dynamic> turn = {
    'scene': 1,
    'round': 1,
    'peSpent': 0,
    'pdSpent': 0,
  };

  Map<String, dynamic> toJson() => {
        'version': 5,
        'p': p,
        'stats': stats,
        'attrs': attrsMap,
        'skills': skills,
        'optional': optional,
        'profile': profile,
        'weapons': weapons,
        'attacks': weapons,
        'rituals': rituals,
        'powers': powers,
        'inventory': inventory,
        'items': inventory,
        'protections': protections,
        'conditions': conditions,
        'buffs': buffs,
        'injuries': injuries,
        'marks': marks,
        'nexChanges': nexChanges,
        'combos': combos,
        'backups': backups,
        'logs': logs,
        'prepare': prepare,
        'mission': mission,
        'rest': rest,
        'evolution': evolution,
        'turn': turn,
      };

  String exportJson() => const JsonEncoder.withIndent('  ').convert(toJson());

  static AppState fromJson(Map<String, dynamic> data) {
    final s = AppState();

    s.p = {...s.p, ...asMap(data['p'])};
    s.stats = {...s.stats, ...asMap(data['stats'] ?? data['s'])};
    s.profile = {...s.profile, ...asMap(data['profile'])};
    s.prepare = {...s.prepare, ...asMap(data['prepare'])};
    s.mission = {...s.mission, ...asMap(data['mission'])};
    s.rest = {...s.rest, ...asMap(data['rest'])};
    s.turn = {...s.turn, ...asMap(data['turn'])};

    final loadedAttrs = asMap(data['attrs'] ?? data['atributos']);
    for (final a in attrs) {
      if (loadedAttrs.containsKey(a)) s.attrsMap[a] = toInt(loadedAttrs[a]);
    }

    final loadedSkills = asMap(data['skills'] ?? data['pericias']);
    for (final skill in skillNames) {
      if (loadedSkills[skill] is Map) {
        s.skills[skill] = {
          ...s.skills[skill]!,
          ...asMap(loadedSkills[skill]),
        };
      } else if (loadedSkills[skill] != null) {
        s.skills[skill] = {
          ...s.skills[skill]!,
          'train': toInt(loadedSkills[skill]),
        };
      }
    }

    final opt = asMap(data['optional'] ?? data['opcionais']);
    for (final key in s.optional.keys) {
      if (opt.containsKey(key)) s.optional[key] = opt[key] == true;
    }

    s.weapons = _normalizeWeapons(data['weapons'] ?? data['attacks'] ?? data['ataques'] ?? data['armas']);
    if (s.weapons.isEmpty) s.weapons = AppState().weapons;

    s.rituals = _normalizeRituals(data['rituals'] ?? data['rituais'] ?? data['rit']);
    s.powers = _normalizePowers(data['powers'] ?? data['poderes'] ?? data['habilidades'] ?? data['hab']);
    s.inventory = _normalizeInventory(data['inventory'] ?? data['items'] ?? data['itens'] ?? data['inventario'] ?? data['inv']);
    s.protections = asListOfMaps(data['protections'] ?? data['protecoes'] ?? data['defenses']);
    s.conditions = asListOfMaps(data['conditions'] ?? data['condicoes'] ?? data['conds']);
    s.buffs = asListOfMaps(data['buffs']);
    s.injuries = asListOfMaps(data['injuries'] ?? data['ferimentos']);
    s.marks = asListOfMaps(data['marks'] ?? data['marcas']);
    s.nexChanges = asListOfMaps(data['nexChanges'] ?? data['alteracoesNex']);
    s.combos = asListOfMaps(data['combos']);
    s.backups = asListOfMaps(data['backups']);
    s.logs = asListOfMaps(data['logs'] ?? data['rolls'] ?? data['historico']);
    s.evolution = asListOfMaps(data['evolution'] ?? data['evolucao']);

    return s;
  }

  static AppState smartImport(Map<String, dynamic> src) {
    if (src.containsKey('p') || src.containsKey('stats') || src.containsKey('s')) {
      return fromJson(src);
    }

    final s = AppState();

    s.p['name'] = firstValue(src, ['nome', 'name', 'personagem', 'character'], '${s.p['name']}');
    s.p['class'] = firstValue(src, ['classe', 'class'], '${s.p['class']}');
    s.p['trail'] = firstValue(src, ['trilha', 'trail'], '${s.p['trail']}');
    s.p['origin'] = firstValue(src, ['origem', 'origin'], '${s.p['origin']}');
    s.p['nex'] = firstInt(src, ['nex', 'NEX'], toInt(s.p['nex']));
    s.p['level'] = firstInt(src, ['nivel', 'nível', 'level'], ((toInt(s.p['nex']) + 4) / 5).floor());
    s.p['affinity'] = firstValue(src, ['afinidade', 'affinity'], '');

    final status = asMap(src['status'] ?? src['stats'] ?? src['s']);
    s.stats['pv'] = firstInt(status, ['pvAtual', 'pvA', 'pv', 'vida'], toInt(s.stats['pv']));
    s.stats['pvMax'] = firstInt(status, ['pvMax', 'pvM', 'vidaMax'], toInt(s.stats['pvMax']));
    s.stats['pe'] = firstInt(status, ['peAtual', 'peA', 'pe'], toInt(s.stats['pe']));
    s.stats['peMax'] = firstInt(status, ['peMax', 'peM'], toInt(s.stats['peMax']));
    s.stats['pd'] = firstInt(status, ['pdAtual', 'pdA', 'pd'], toInt(s.stats['pd']));
    s.stats['pdMax'] = firstInt(status, ['pdMax', 'pdM'], toInt(s.stats['pdMax']));
    s.stats['san'] = firstInt(status, ['sanAtual', 'sanA', 'san', 'sanidade'], toInt(s.stats['san']));
    s.stats['sanMax'] = firstInt(status, ['sanMax', 'sanM', 'sanidadeMax'], toInt(s.stats['sanMax']));
    s.stats['def'] = firstInt(status, ['def', 'defesa'], toInt(s.stats['def']));
    s.stats['rd'] = firstInt(status, ['rd', 'resistencia'], toInt(s.stats['rd']));
    s.stats['dt'] = firstInt(status, ['dt', 'dtRitual'], toInt(s.stats['dt']));

    final atributos = asMap(src['atributos'] ?? src['attrs']);
    for (final a in attrs) {
      if (atributos[a] != null) s.attrsMap[a] = toInt(atributos[a]);
    }

    final pericias = asMap(src['pericias'] ?? src['skills']);
    for (final skill in skillNames) {
      final val = pericias[skill];
      if (val is Map) {
        s.skills[skill] = {...s.skills[skill]!, ...asMap(val)};
      } else if (val != null) {
        s.skills[skill] = {...s.skills[skill]!, 'train': toInt(val)};
      }
    }

    s.weapons = _normalizeWeapons(src['armas'] ?? src['ataques'] ?? src['attacks'] ?? src['weapons']);
    if (s.weapons.isEmpty) s.weapons = AppState().weapons;
    s.rituals = _normalizeRituals(src['rituais'] ?? src['rituals'] ?? src['rit']);
    s.powers = _normalizePowers(src['poderes'] ?? src['habilidades'] ?? src['powers'] ?? src['hab']);
    s.inventory = _normalizeInventory(src['inventario'] ?? src['itens'] ?? src['items'] ?? src['inv']);

    return s;
  }

  static List<Map<String, dynamic>> _normalizeWeapons(dynamic value) {
    final list = asListOfMaps(value);
    return list.map((w) {
      return {
        'id': cleanText(w['id']).isEmpty ? newId('weapon') : w['id'],
        'name': firstValue(w, ['name', 'nome', 'n'], 'Arma'),
        'skill': firstValue(w, ['skill', 'pericia'], 'Luta'),
        'attr': firstValue(w, ['attr', 'atributo'], 'Força'),
        'test': firstValue(w, ['test', 'teste', 'atk', 'ataque'], '1d20+0'),
        'damage': firstValue(w, ['damage', 'dano', 'dmg'], '1d6'),
        'type': firstValue(w, ['type', 'tipo'], 'Impacto'),
        'crit': firstValue(w, ['crit', 'critico', 'crítico'], '20/x2'),
        'range': firstValue(w, ['range', 'alcance'], ''),
        'category': firstValue(w, ['category', 'categoria'], ''),
        'ammo': firstInt(w, ['ammo', 'municao', 'munição'], 0),
        'ammoMax': firstInt(w, ['ammoMax', 'municaoMax', 'muniçãoMax'], 0),
        'reload': firstValue(w, ['reload', 'recarga'], ''),
        'mods': firstValue(w, ['mods', 'modificacoes', 'modificações'], ''),
        'curses': firstValue(w, ['curses', 'maldicoes', 'maldições'], ''),
        'equipped': w['equipped'] == true || w['equipado'] == true,
        'fav': w['fav'] == true,
        'notes': firstValue(w, ['notes', 'obs', 'notas'], ''),
      };
    }).toList();
  }

  static List<Map<String, dynamic>> _normalizeRituals(dynamic value) {
    final list = asListOfMaps(value);
    return list.map((r) {
      final desc = firstValue(r, ['desc', 'descricao', 'descrição', 'd'], '');
      return {
        'id': cleanText(r['id']).isEmpty ? newId('rit') : r['id'],
        'name': firstValue(r, ['name', 'nome', 'n'], 'Ritual'),
        'element': firstValue(r, ['element', 'elemento', 'el'], ''),
        'circle': firstValue(r, ['circle', 'circulo', 'círculo', 'c'], ''),
        'execution': firstValue(r, ['execution', 'execucao', 'execução'], ''),
        'range': firstValue(r, ['range', 'alcance'], ''),
        'target': firstValue(r, ['target', 'alvo', 'area', 'área'], ''),
        'duration': firstValue(r, ['duration', 'duracao', 'duração'], ''),
        'resistance': firstValue(r, ['resistance', 'resistencia', 'resistência'], ''),
        'cost': firstValue(r, ['cost', 'custo', 'pe'], ''),
        'discente': firstValue(r, ['discente'], ''),
        'verdadeiro': firstValue(r, ['verdadeiro'], ''),
        'sustainCost': firstValue(r, ['sustainCost', 'sustentado'], ''),
        'components': firstValue(r, ['components', 'componentes'], ''),
        'damage': firstValue(r, ['damage', 'dano', 'dmg'], detectDice(desc)),
        'desc': desc,
        'fav': r['fav'] == true,
        'sustain': r['sustain'] == true || r['sustentado'] == true,
      };
    }).toList();
  }

  static List<Map<String, dynamic>> _normalizePowers(dynamic value) {
    final list = asListOfMaps(value);
    return list.map((p) {
      return {
        'id': cleanText(p['id']).isEmpty ? newId('pow') : p['id'],
        'name': firstValue(p, ['name', 'nome', 'n'], 'Poder'),
        'type': firstValue(p, ['type', 'tipo'], 'Classe'),
        'prereq': firstValue(p, ['prereq', 'preRequisito', 'pré-requisito'], ''),
        'cost': firstValue(p, ['cost', 'custo'], ''),
        'action': firstValue(p, ['action', 'acao', 'ação'], ''),
        'uses': firstValue(p, ['uses', 'usos'], ''),
        'desc': firstValue(p, ['desc', 'descricao', 'descrição', 'effect', 'efeito', 'd'], ''),
        'fav': p['fav'] == true,
      };
    }).toList();
  }

  static List<Map<String, dynamic>> _normalizeInventory(dynamic value) {
    final list = asListOfMaps(value);
    return list.map((i) {
      return {
        'id': cleanText(i['id']).isEmpty ? newId('item') : i['id'],
        'name': firstValue(i, ['name', 'nome', 'n'], 'Item'),
        'type': firstValue(i, ['type', 'tipo', 'categoria', 'cat'], 'Equipamento'),
        'qty': firstValue(i, ['qty', 'qtd', 'quantidade'], '1'),
        'load': firstValue(i, ['load', 'carga', 'espacos', 'espaços'], '0'),
        'uses': firstValue(i, ['uses', 'usos'], '0'),
        'patent': firstValue(i, ['patent', 'patente'], ''),
        'desc': firstValue(i, ['desc', 'descricao', 'descrição', 'd'], ''),
        'fav': i['fav'] == true,
      };
    }).toList();
  }
}
