# Central Player Flutter V4 Corrigida

Esta versão corrige os problemas relatados:

- Botões de rolagem agora chamam a função `roll()` corretamente.
- Testes de Ordem Paranormal usam o maior d20 quando a rolagem é `2d20`, `3d20` etc.
- Dano soma todos os dados normalmente.
- Perícias agora têm botão `Editar` funcional com janela de edição.
- Notificações de rolagem aparecem em duas formas: popup grande e snackbar.
- Interface refeita para ficar mais próxima da versão HTML: fundo escuro, vermelho, cards, badges, sombras e navegação por abas.

## Como gerar APK

Envie todos os arquivos para o GitHub e rode:

Actions > Gerar APK Flutter > Run workflow

O APK sai no artefato `central-player-v4-debug-apk`.
