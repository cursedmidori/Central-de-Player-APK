package com.orueu.central_player

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.OutputStreamWriter

class MainActivity : FlutterActivity() {
    private val channelName = "central_player/json_files"
    private var pendingResult: MethodChannel.Result? = null
    private var pendingContent: String? = null

    companion object {
        private const val REQUEST_OPEN_JSON = 4101
        private const val REQUEST_SAVE_JSON = 4102
    }

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)

        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, channelName).setMethodCallHandler { call, result ->
            if (pendingResult != null) {
                result.error("BUSY", "Já existe uma operação de arquivo em andamento.", null)
                return@setMethodCallHandler
            }

            when (call.method) {
                "openJson" -> {
                    pendingResult = result
                    val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                        addCategory(Intent.CATEGORY_OPENABLE)
                        type = "application/json"
                        putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("application/json", "text/json", "text/plain", "*/*"))
                    }
                    try {
                        startActivityForResult(intent, REQUEST_OPEN_JSON)
                    } catch (e: Exception) {
                        pendingResult = null
                        result.error("OPEN_FAILED", e.message, null)
                    }
                }

                "saveJson" -> {
                    val fileName = call.argument<String>("fileName") ?: "ficha_central_player.json"
                    pendingContent = call.argument<String>("content") ?: ""
                    pendingResult = result

                    val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
                        addCategory(Intent.CATEGORY_OPENABLE)
                        type = "application/json"
                        putExtra(Intent.EXTRA_TITLE, fileName)
                    }
                    try {
                        startActivityForResult(intent, REQUEST_SAVE_JSON)
                    } catch (e: Exception) {
                        pendingContent = null
                        pendingResult = null
                        result.error("SAVE_FAILED", e.message, null)
                    }
                }

                else -> result.notImplemented()
            }
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        val result = pendingResult ?: return
        pendingResult = null

        if (resultCode != Activity.RESULT_OK || data?.data == null) {
            pendingContent = null
            result.success(null)
            return
        }

        val uri: Uri = data.data!!

        try {
            when (requestCode) {
                REQUEST_OPEN_JSON -> {
                    val input = contentResolver.openInputStream(uri)
                    val text = BufferedReader(InputStreamReader(input, Charsets.UTF_8)).use { it.readText() }
                    result.success(text)
                }

                REQUEST_SAVE_JSON -> {
                    val content = pendingContent ?: ""
                    pendingContent = null
                    val output = contentResolver.openOutputStream(uri)
                    OutputStreamWriter(output, Charsets.UTF_8).use { it.write(content) }
                    result.success(true)
                }

                else -> result.success(null)
            }
        } catch (e: Exception) {
            pendingContent = null
            result.error("FILE_ERROR", e.message, null)
        }
    }
}
